! ------ Xiaomi Mi flora plant sensor (Flower mate) -------
dev$ = "C4:7C:8D:62:6A:EE"
service$ = "00001204-0000-1000-8000-00805f9b34fb"
chauth$ = "00001a00-0000-1000-8000-00805f9b34fb"
chdata$ = "00001a01-0000-1000-8000-00805f9b34fb"
authdata$ = chr$(hex("A0"))+chr$(hex("1F"))

cls
ble.open
ble.scan 1

scan:
cls
print "Scanning..."
ble.devices dl$[]
array.length len,dl$[]
for i=1 to len
  ble.rssi dl$[i], rssi
  ble.name dl$[i], name$
  if dl$[i] <> ""
    print dl$[i] ; " rssi=" ; rssi ; "\n" ; name$
  endif
next i
pause 1000
goto scan

onconsoletouch:
console.line.touched line
dev$ = dl$[line-1]
ble.scan 0

loop:
do
  ble.status st$
  if st$ <> last$
    last$ = st$
    print st$
  endif
  if  st$ = "Disconnected"
    ble.connect dev$
  endif
  pause 200
until st$ = "Connected"

pause 1000
BLE.WRITE chauth$, authdata$
pause 500
BLE.READ.REQUEST chdata$
pause 1000
BLE.READ data$
if data$ <> ""
  ! ------ parse data -------
  temp =  (ASCII(data$, 2) * 256 + ASCII(data$, 1)) / 10
  moisture = ASCII(data$, 8)
  light = ASCII(data$, 5) * 256 + ASCII(data$, 4)
  conductivity = ASCII(data$, 10) * 256 + ASCII(data$, 9)
  PRINT "temp=" ; temp ; " C moisture=" ; moisture ; "% light=" ; light ; "lux conductivity=" ; conductivity ; "us/cm"
endif
pause 10000
goto loop

