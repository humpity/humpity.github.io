! ------ Heart rate sensor (BLE) -------
dev$ = "7D:FE:E1:5A:4D:16"
chdata$ = "00002a37-0000-1000-8000-00805f9b34fb"

cls
ble.open
ble.scan 1

scan:
cls
print "Scanning..."
ble.devices dl$[]
array.length len,dl$[]
for i=1 to len
  ble.rssi dl$[i], rssi
  ble.name dl$[i], name$
  if dl$[i] <> ""
    print dl$[i] ; " rssi=" ; rssi ; "\n" ; name$
  endif
next i
pause 1000
goto scan

onconsoletouch:
console.line.touched line
dev$ = dl$[line-1]
ble.scan 0

do
  ble.status st$
  if st$ <> last$
    last$ = st$
    print st$
  endif
  if  st$ = "Disconnected"
    ble.connect dev$
  endif
  pause 200
until st$ = "Connected"

pause 1000
BLE.notify chdata$, 1

loop:
pause 1000
BLE.READ data$
if data$ <> ""
  ! ------ parse data -------
  rate = ascii(data$, 2)
  PRINT "data=" ; rate
endif
goto loop

