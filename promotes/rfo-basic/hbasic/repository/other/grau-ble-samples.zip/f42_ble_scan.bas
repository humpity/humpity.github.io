! --- BLE scanner

cls
ble.open
ble.scan 1

scan:
cls
print "Scanning..."
ble.devices dl$[]
array.length len,dl$[]
for i=1 to len
  ble.rssi dl$[i], rssi
  ble.name dl$[i], name$
  if dl$[i] <> ""
    print dl$[i] ; " rssi=" ; rssi ; "\n" ; name$
  endif
next i
pause 1000
goto scan

onconsoletouch:
console.line.touched line
dev$ = dl$[line-1]
ble.scan 0

do
  ble.status st$
  if st$ <> last$
    last$ = st$
    print st$
  endif
  if  st$ = "Disconnected"
    ble.connect dev$
  endif
  pause 200
until st$ = "Connected"

BLE.services sv$[]
array.length svlen,sv$[]
for i=1 to svlen
  print "sv " ; sv$[i]
  BLE.characteristics sv$[i], ch$[]
  array.length chlen,ch$[]
  for j=1 to chlen
    print "   ch " ; ch$[j]
  next j
next i

