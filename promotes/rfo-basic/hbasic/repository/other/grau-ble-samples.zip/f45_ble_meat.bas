! ---- ONE Concept Meatmaster Bluetooth grill thermometer (thermsmart-sensor) ---
dev$ = "F4:B8:5E:AF:2A:A0"
service$             = "0000fff0-0000-1000-8000-00805f9b34fb"
chauth$              = "0000fff3-0000-1000-8000-00805f9b34fb"
chdata$              = "0000fff4-0000-1000-8000-00805f9b34fb"
reqdata$ = chr$(hex("D5"))
authdata$ = chr$(hex("D2"))

cls
ble.open
ble.scan 1

scan:
cls
print "Scanning..."
ble.devices dl$[]
array.length len,dl$[]
for i=1 to len
  ble.rssi dl$[i], rssi
  ble.name dl$[i], name$
  if dl$[i] <> ""
    print dl$[i] ; " rssi=" ; rssi ; "\n" ; name$
  endif
next i
pause 1000
goto scan

onconsoletouch:
console.line.touched line
dev$ = dl$[line-1]
ble.scan 0

loop:
do
  ble.status st$
  if st$ <> last$
    last$ = st$
    print st$
  endif
  if  st$ = "Disconnected"
    ble.connect dev$
  endif
  pause 200
until st$ = "Connected"

pause 2000
ble.notify chdata$, 1
pause 1000
BLE.WRITE chauth$, authdata$
pause 2000
BLE.READ data$
if data$ <> ""
  ! ------ parse data -------
  temp= ((ascii(data$, 14)-48) * 256 + ascii(data$, 13)) /20
  print "--------> " ; temp ; " degC"
endif
pause 10000
goto loop

