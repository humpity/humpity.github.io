!!
  font-fam demo
    upgraded from demo0328.
    for hBasic v5.68+

	v2.0 - centered title
!!
menu.set ""			% hide menu

GOSUB init

CONSOLE.TITLE "Font Families Demo",,,,2
CONSOLE.SET "SPACING 3, DIVIDERS OFF"
CONSOLE.SET "TEXTSIZE 22"
.cs "VOIDCOLOR black"
.cs "TEXTCOLOR black, BACKCOLOR black.0"
PRINT "Default"

READ.DATA~
"casual",~
"cursive",~
"monospace",~
"sans-serif",~
"sans-serif-black",~
"sans-serif-condensed",~
"sans-serif-condensed-light",~
"sans-serif-light",~
"sans-serif-medium",~
"sans-serif-smallcaps",~
"sans-serif-thin",~
"serif",~
"serif-monospace",~
"END"

DO
 READ.NEXT fam$
 IF fam$ = "END" THEN D_U.BREAK
 CONSOLE.SET "FONT "+fam$
 PRINT fam$
UNTIL 0

fade_inOut ("white")   % black >white >black
fade_inOut ("aqua")
fade_inOut ("pink")
fade_inOut ("green")


% IF ##$ = "FONTLOAD" THEN RUN "font-load.bas"
RUN "font-load.bas"
END

init:
	fn.def fade_in(c$)
		for i=0 to 255 step 15
		 .cs "VOIDCOLOR "+c$+"."+int$(i)
		 pause 50
		next
	fn.end
	fn.def fade_Out(c$)
		for i=255 to 0 step -15
		 .cs "VOIDCOLOR "+c$+"."+int$(i)
		 pause 50
		next
	fn.end
	fn.def fade_inOut(c$)
		fade_in(c$)
		pause 1000
		fade_Out(c$)
	fn.end
return
