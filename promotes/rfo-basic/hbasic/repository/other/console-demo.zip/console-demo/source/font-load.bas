!!
  font-load demo
    upgraded from demo0328.
    for hBasic v5.68+

	v2.1 - fixed fptr value
	v2.2 - centered title
!!
menu.set ""			% hide menu
					% load a font for title
FONT.LOAD f_ibm, "../source/boxblue.ttf"
IF f_ibm < 0 THEN GOTO LOAD_ERROR
CONSOLE.TITLE "Font Load Demo","lightGreen",,~
		int$(f_ibm),2

reset$ = "FONT -1, TEXTSIZE 18," +~
        " BACKCOLOR white," +~
        " SPACING -1" 		% (-1 defaults to 5dp)
console.set reset$
					% load a font for console
? "Loading Font: ";
FONT.LOAD f_lcd, "../source/lcd.ttf"
? int$(f_lcd)
IF f_lcd < 0 THEN GOTO LOAD_ERROR

.cs "WRAP off, DIVIDERS off, spacing 0"
.cs "TEXTSIZE 30, SPACING 0"

?:?					% two empty lines
.cs "FONT "+ int$(f_lcd)
.cs "BACKCOLOR lightgreen"
?.AT -2,4;"L C D Mono font"		% overwrite
?.AT -1,4;"               "		% with green

	% keep printing on last line
s$="0123456789" %_+-=!@#$%^&*{}/"
FOR C=1 to 2
 FOR i=1 TO 10
  PRINT.AT -1,16-i; left$(s$,i)+" "
  PAUSE 150
 NEXT
 IF c = 2 THEN F_N.BREAK
 FOR i=1 TO 10
  PRINT.AT -1,6; right$(s$,-i)+" "
  PAUSE 150
 NEXT
NEXT
.cs reset$
?
? "Loading Font: ";
FONT.LOAD f_zx, "../source/zx81.ttf"
? int$(f_zx)
IF f_zx = -1 THEN GOTO LOAD_ERROR

.cs "FONT "+ int$(f_zx)
.cs "TEXTSIZE 20, WRAP ON"
.cs "BACKCOLOR yellow"
? "  sinclair zx81"
.cs "BACKCOLOR white"

FOR i=33 TO ascii("]")
 ?CHR$(i);
NEXT
?
FOR i=hex("2580") TO hex("259F")
 ?CHR$(i);
NEXT
?
			% finish with IBM font
.cs "FONT "+ int$(f_ibm)~
	,"textColor lightGreen"~
	,"backColor black"~
	,"voidColor black"
?
?" - End Of Demo -"
.cs reset$
CONSOLE.GOTO 1
GOTO FIN
LOAD_ERROR:
? "Could not load font."
? getError$()
FIN:
