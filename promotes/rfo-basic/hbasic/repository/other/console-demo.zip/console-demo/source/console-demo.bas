!!
  console-demo
    upgraded from demo0328.
    for hBasic v5.68+

	v2.1 - fixed font loading ptrs
!!
menu.set ""			% hide menu
console.title "","black","black"

CONSOLE.SET~
	"wrap off",~
	"SPACING 1",~
	"DIVIDERS Off",~
	"TEXTCOLOR LIGHTGREY",~
	"BACKCOLOR black",~
	"VOIDCOLOR black"
GOSUB init

PAUSE 2000
for i=3 to 6			% zoom on
 .cs "TEXTSIZE "+int$(i*3)
 print.at i,6;"From"
 pause 100
next
.cs "TEXTSIZE 20"
print.at 7,7;"From"
for i=3 to 6			% zoom off
 .cs "TEXTSIZE "+int$(i*3)
 print.at i,6;"    "
 pause 100
next
.cs "TEXTSIZE 20"
blink_ (7,11,5)

.cs "TEXTSIZE 20"
slideprint (7,12,"The Depths")
slideprint (8,12,"of Space..")
blink_ (8,22,4)

wipeline (7,8)
pause 2000
cls
.cs "FONT "+bitwise$
.cs "TEXTSIZE 24"
?.at 4,1;""			% need pre-black lines
.cs "textcolor black, backCOLOR NeonGreen"
slowprint (3,6, "HmpSoft", 200)
blink (3,13,"NeonGreen","black",4)

.cs "BACKCOLOR ORANGE, TEXTCOLOR BLACK"
.cs "TEXTSIZE 24"
slowprint (3,15, "Presents", 200)
blink (3,23,"ORANGE","black",4)
pause 1000
.cs "BACKCOLOR BLACK"
.cs "TEXTCOLOR white.50"
.cs "TEXTSIZE 38"
for i=1 to 255 step 15		% fade
	.cs "TEXTCOLOR white."+int$(i)
	.cs "FONT "+glam$
	print.at  5,8; "hBasic"
	.cs "FONT "+ghost$+".italic"
	.cs "TEXTCOLOR gold."+int$(i)
	print.at  5,15; "demo"
	pause 100
next
pause 1000
.cs "TEXTSIZE 22"
.cs "TEXTCOLOR cyan"
.cs "FONT casual"
slideWord (6,9,"for v05.68+")
pause 2000
!----------------------------------------
warp:

.cs "TEXTSIZE 20"
.cs "FONT "+army$
print "";	% go into append mode for busy
.cs "TEXTCOLOR white, BACKCOLOR black"
slowprint (9,4,"Warping ", 50)
.cs "FONT monospace"
print.at -1,-1;" .."

 FOR i = 5 TO 1 step -1
  PRINT "."+int$(i)
  PAUSE 1000
  BACKSPACE
 NEXT

.cs "TEXTSIZE 20, TEXTCOLOR white, BACKCOLOR black"
.cs "FONT "+box$	% use IBM box font
.cs "SPACING 0, DIVIDERS off"
cls
call WarpOut()

skip:
RUN "font-fam.bas", "FONTLOAD"
! should not return to here
goto fin
!----------------------------------------
init:
fn.def slowprint (y,x, s$, delay)
 x--
 l = len (s$)
 for i = 1 to l
  c$ = chr$(ascii(s$,i))
  PRINT.AT y,x+i; c$
  pause delay
 next
fn.end
%--------------
fn.def slidePrint (y,x,s$)
 x--
 delay = 10
 scr_end = 30
 l = len (s$)
 for i = 1 to l
  c$ = chr$(ascii(s$,i)) + " "
  if c$="  " then f_n.continue
  for j = scr_end to x+i step -1
   PRINT.AT y,j; c$
   pause delay
  next j
  delay++
 next i
fn.end
%--------------
fn.def slideWord (y,x,s$)
 delay = 100
 b$ = chr$(hex("3000"))
 for i = 1 to x-1
   PRINT.AT y,i; b$+s$		
   pause delay
 next i
 for i=1 to 3
  PRINT.AT y,x; b$+s$		% overshoot
  pause 30
  PRINT.AT y,x;  s$+b$		% correct overshoot
  pause 30
  PRINT.AT y,x-1;s$+b$		% undershoot
  pause 30
  PRINT.AT y,x-1;  b$+s$	% correct undershoot
  pause 30
 next i
fn.end
%--------------
fn.def wipeline (f,t)
	for i=1 to 30
	 for j=f to t
		print.at j,i;" "
	 next j
	pause 10
	next
fn.end
%--------------
fn.def blink_ (y,x, n)

	for i=1 to n
		print.at y,x;"_"
		pause 200
		print.at y,x;" "
		pause 200
	next
fn.end
%--------------
fn.def blink(y,x,on$,off$,n)
	
	for i=1 to n*2
		.cs "textcolor "+off$+", backcolor "+on$
		print.at y,x;" "
		swap on$,off$
		pause 200
	next
fn.end
%--------------
fn.def drawFrame(l,t,r,b)

	if l>=r | t>=b-1  then fn.rtn t
	tl$="┌" : tr$="┐" : bl$="└": br$="┘"
	hl$="─" : vc$="│"
	?.at t,l;tl$		% corners
	?.at t,r;tr$
	?.at b,l;bl$
	?.at b,r;br$
	for i=l+1 to r-1	% horizontals
		?.at t,i;hl$
		?.at b,i;hl$
	next
	for i=t+1 to b-1	% verticals
		?.at i,l;vc$
		?.at i,r;vc$
	next
	fn.rtn 0
fn.end
%--------------
fn.def WarpOut()
	CONSOLE.SCREEN sw,sh
	sh--
	l=1 : t=2 : r=int(sw) : b=int(sh)
	delay=50

	for i=1 to sh/2
		drawFrame(l++,t++,r--,b--)
		pause delay
	next
	.cs "TEXTCOLOR BLACK"
	l=1 : t=2 : r=int(sw) : b=int(sh)
	for i=1 to sh/2
		drawFrame(l++,t++,r--,b--)
		pause delay
	next
	cls
	.cs "TEXTCOLOR white"
	for i=8 to 1 step -1
		?.at sh/2+1,sw/2+1;  chr$(hex("2580")+i)
		pause 100
	next
	?.at sh/2+1,sw/2+1;  " "
	pause 1000
 	cls
fn.end
%--------------
FONT.LOAD fptr, "../source/bitwise.ttf"
	if fptr<0 then goto abort
	bitwise$ = int$(fptr)
FONT.LOAD fptr, "../source/ghost.ttf"
	if fptr<0 then goto abort
	ghost$   = int$(fptr)
FONT.LOAD fptr, "../source/army.ttf"
	if fptr<0 then goto abort
	army$   = int$(fptr)
FONT.LOAD fptr, "../source/sg.ttf"
	if fptr<0 then goto abort
	glam$   = int$(fptr)

FONT.LOAD fptr, "../source/boxblue.ttf"
	if fptr<0 then goto abort
	box$   = int$(fptr)
!---------------------------------------------
RETURN %_init
abort:
.cs	"wrap on"
?"Aborted> ";getError$(): END
