
package com.rfo.hbasic;

import java.util.ArrayList;
import java.util.Iterator;

import android.os.Build;
import android.graphics.Canvas;
import android.graphics.RectF;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.Region;
import android.graphics.Bitmap;

// ********************* BASIC! Drawable Object class *********************
// Objects go on the Display List. Not related to Android's Drawable class.

public class BDraw {
	public enum VISIBLE { SHOW, HIDE, TOGGLE; }

	private final Type mType;
	private static String mErrorMsg="";

	private int mBitmap;							// index into the BitmapList
	private int mPaint;								// index into the PaintList
	private float mAlpha;
	private float mSpeed=0;
	private float mVx=1.0f;
	private float mVy=0.0f;
	private Sprite mSprite;							// for Type.Sprite
	private Tween mTween;

	private boolean mVisible;
	private String mText;							// for Type.Text
	private int mClipOpIndex;						// for getValue
	private Region.Op mClipOp;						// for Type.Clip
	private int mListIndex;
	private Var.ArrayDef mArray;					// for Type.SetPixels
	private int mArrayStart;						// position in array to start pixel array
	private int mArraySublength;					// length of array segment to use as pixel array
	private float mRadius;							// for Type.Circle
	private float mAngle_1;							// for Type.Rotate, Arc (not used for motion)
	private float mAngle_2;							// for Type.Arc
	private int mFillMode;							// for getValue
	private boolean mUseCenter;						// for Type.Arc

	private float mLeft;							// left, x, or x1
	private float mRight;							// right or x2
	private float mTop;								// top, y, or y1
	private float mBottom;							// bottom or y2

	public BDraw(Type type) {
		mType = type;
		mVisible = true;
//			mErrorMsg = "";
	}

	public void init (int paintIndex, int alpha) { mPaint = paintIndex; mAlpha = alpha; }

	// setters
	// For now, range checking for bitmap, paint, and list must be done in Run.
	public void bitmap(int bitmap) { mBitmap = bitmap; }	// index into the BitmapList
	public void paint(int paint) { mPaint = paint; }		// index into the PaintList
	public void speed(float speed) { mSpeed = speed; }
	public void dir(float vx, float vy)	{ mVx = vx; mVy = vy; }
	public void dir(float dir)
	{
		mVx = (float) (Math.cos(Math.toRadians(dir)));
		mVy=  (float) (Math.sin(Math.toRadians(dir)));
	}
	public void alpha(float alpha)
	{
		if (alpha > 255.0f) alpha=255.0f;
		if (alpha <0.0f) alpha=0.0f;
		mAlpha = alpha;;
	}
	public void xy (double[] xy)
	{
		mLeft =  (float) xy[0]; mTop =  (float) xy[1];
		mRight = mLeft+1.0f; mBottom =mTop+1.0f;
	}

	public void ltrb (double[] ltrb)
		{	mLeft  = (float)ltrb[0]; mTop =   (float)ltrb[1];
			mRight = (float)ltrb[2]; mBottom =(float)ltrb[3]; }
	public void radius (double radius) { mRadius = (float) radius; }
	public void text (String text) { mText = text; }
	public void array (Var.ArrayDef array, int start, int sublength) {
		mArray = array;
		mArrayStart = start;
		mArraySublength = sublength;
	}
	public void angle(float angle) { mAngle_1 = angle; }

	public void show(VISIBLE show) {
		switch (show) {
			case SHOW: mVisible = true; break;
			case HIDE: mVisible = false; break;
			case TOGGLE: mVisible = !mVisible; break;
		}
	}

	public void clipOp(int opIndex) {
		Region.Op[] ops = {
			Region.Op.INTERSECT, Region.Op.DIFFERENCE			// -humpty 0261 only entertain these two OPs
		};
		mClipOpIndex = opIndex;
		mClipOp = ops[opIndex];
	}

	public void listPtr (int index) {
		mListIndex = index;
	}

	public void useCenter(int fillMode) {
		mFillMode = fillMode;
		mUseCenter = (fillMode != 0);
	}

	public void arc(double[] lrtb, double[] angles, int fillMode)
	{
		ltrb (lrtb);
		mAngle_1 = (float) angles[0];		// startAngle
		mAngle_2 = (float) angles[1];		// sweepAngle
		useCenter(fillMode);
	}

	public void circle(double[] xy, double radius) {
		xy(xy);					// (x, y) in mTop and mLeft marks the CENTER of the circle
		mRadius = (float) radius;
	}

	// universal getters
	public Type type()			{ return mType; }
	public String errorMsg()	{ return mErrorMsg; }
	public int bitmap()			{ return mBitmap; }	// index into the BitmapList
	public int paint()			{ return mPaint; }	// index into the PaintList
	public float alpha()		{ return mAlpha; }
	public float speed()		{ return mSpeed; }
	public float dir()			{ return((float)((Math.toDegrees(Math.atan2(mVy,mVx)) + 360.0d)%360.0d));}
	public float vx()			{ return mVx; }
	public float vy()			{ return mVy; }

	public boolean isHidden()	{ return !mVisible; }
	public boolean isVisible()	{ return mVisible; }

	// type-specific getters
	public Sprite sprite()		{ return mSprite; }
	public String text()		{ return mText; }
	public Region.Op clipOp()	{ return mClipOp; }
	public ArrayList<Double> list()
	{
	 ArrayList<ArrayList> lists = Run.mInterpreter.theLists;
	 if (lists==null || mListIndex <1 || mListIndex > lists.size())
		 return (new ArrayList<Double>()); // (can't happen)
	 return lists.get(mListIndex);
	}
	public Var.ArrayDef array()	{ return mArray; }
	public int arrayStart()		{ return mArrayStart; }
	public int arraySublength()	{ return mArraySublength; }
	public int radius()			{ return (int) mRadius; }
	public float angle()		{ return mAngle_1; }
	public float arcStart()		{ return mAngle_1; }
	public float arcSweep()		{ return mAngle_2; }
	public boolean useCenter()	{ return mUseCenter; }

	// coordinate getters
	public int x()				{ return (int) mLeft; }
	public int x1()				{ return (int) mLeft; }
	public int left()			{ return (int) mLeft; }
	public int y()				{ return (int) mTop; }
	public int y1()				{ return (int) mTop; }
	public int top()			{ return (int) mTop; }
	public int x2() 			{ return (int) mRight; }
	public int right()			{ return (int) mRight; }
	public int y2()				{ return (int) mBottom; }
	public int bottom()			{ return (int) mBottom; }
	public int width()
	{
		if (mType==Type.Sprite || mType==Type.Bitmap)
		{
			Bitmap bmp = GR.getBitMap(mBitmap);
			if (bmp == null) return 0;
			return bmp.getWidth();
		}
		return (int) (int)mRight-(int)mLeft;
	}
	public int height()
	{
		if (mType==Type.Sprite || mType==Type.Bitmap)
		{
			Bitmap bmp = GR.getBitMap(mBitmap);
			if (bmp == null) return 0;
			return bmp.getHeight();
		}
		return (int) (int)mBottom-(int)mTop;
	}
	// movement
	public void move(float dx, float dy)
	{
		mLeft += dx; mRight  += dx;
		mTop  += dy; mBottom += dy;
	}
	public void motion ()
	{
		if (mType==Type.Group) return;	// Groups are ignored
		if (mSpeed != 0.0f)
		{
			float dx = mVx * mSpeed * (float)(GR.deltaTime) / 1000.0f;
			float dy = mVy * mSpeed * (float)(GR.deltaTime) / 1000.0f;
			mLeft += dx; mRight  += dx;
			mTop  += dy; mBottom += dy;
		}

		if (mType!=Type.Sprite) return;
		if (mSprite.aniPtr <= 0) return;// no animation
		if (mSprite.aRate == 0) return;	// freeze frame
										// else do animation
		Bitmap[] farray = GR.getAnim(mSprite.aniPtr);
		if (farray==null) return;		// bad animation
		int length = farray.length; if (length<1) return;
		float frame = mSprite.aFrame;
//			if (frame<0 || frame >= length) frame=0;	// illegal frame
		float dFrames = mSprite.aRate * (float)GR.deltaTime / 1000.0f;
		frame = frame + dFrames;

		if (mSprite.aLoop)				// if looping
		{								// force legal value
			frame = frame % length;
			if (frame < 0) frame += length;
		}
		if (frame >= length) frame = length-1;	// if over shot
		if (frame < 0) frame = 0;				// if under shot
		mSprite.aFrame = frame;	// update frame
	}//_motion

	public boolean tween_one (Tween t)	// do tween, return expiry
	{
		int dt = GR.deltaTime;

		if (t.delay < 0) t.delay=0;	// -ve not allowed
		if (t.delay > 0)
		{
			t.delay -= GR.deltaTime;	// update delay
			if (t.delay < 0) t.delay=0;
			return false;				// skip delay delta
		}//_delay

//		if (t.dur == 0) dt = 1000;		// instantaneous
		if (t.dur == 0) return true;	// expired (can't happen)
		if (t.dur > 0)
		{
			if (t.dur > dt) t.dur -= dt;	// update duration
			else
			{
				dt=t.dur;				// do last duration
				t.dur = 0;
			}
		}//_normal duration
								// -ve duration => compulsory
		if (t.parm.equals("push"))
		{								// apply delta
			float dVX = t.aVx * t.rate * dt/1000.0f;
			float dVY = t.aVy * t.rate * dt/1000.0f;
										// to existing vector
			float rVX = vx() * speed() + dVX;
			float rVY = vy() * speed() + dVY;
			float rSpeed = (float) Math.sqrt(rVX*rVX + rVY*rVY);
										// update
			mSpeed = rSpeed;		// always +ve
			if (rSpeed!=0) dir( rVX/rSpeed, rVY/rSpeed ); // else stop
			return (t.dur == 0);			// expired ?
		}//_if push
		if (t.goal)	// rate is a goal ?
		{
			if (t.dur <= 0)		// expired. ensure goal met.
			{									
				modify ( t.parm, (int)t.rate, t.rate, "");
				return true;
			}
			float val = (float) getValue(t.parm);	// get value
			float dif = t.rate - val;			// difference
			float tim = t.dur + dt;				// add back dt
			if (tim == 0) return true;			// (can't happen)
			float drate = dif/tim;				// dynamic rate (ms)
			val += drate * (float)(dt);
			modify ( t.parm, (int)val, val, "");	// update parm
		}
		else
		{			//_normal tween
			float val = (float) getValue(t.parm);	// get value
			val += t.rate * (float)(dt) / 1000.0f;
			modify ( t.parm, (int)val, val, "");	// update parm
		}//_not a push

		return (t.dur == 0);			// expired ?
	}//_tween_one

	public void tween ()		// do tweens for this object
	{
		Tween t = mTween;
		Tween hold = t;
		while (t!=null)
		{
			boolean expired = tween_one (t);
			if (expired)		 		// expired ?
			{
				if (t==mTween)			// if head tween
				{
					mTween = t.next;	// remove head
					t.next=null; t.dur=0;
					t = hold = mTween;
					continue;
				}
				hold.next = t.next;		// unlink
				t.next = null; t.dur=0;
				t = hold.next;
				continue;
			}//_expired
			hold = t;
			t = t.next;
		}//_while
	}//_tween

	// For GR_Tweens()
	public int tween_count (String p)	// count tween(s)
	{									// p="*" is wildcard
		int count=0;
		Tween t = mTween;
		Tween hold = t;
		while (t!=null)
		{
			if (p.equals("*") || t.parm.equals(p)) count++;
			hold = t;
			t = t.next;
		}//_while
		return count;
	}//_tween_count

	// For GR_Tween commands

	public Tween tween_add (String p, float rate, int dur, int delay)
	{								// add a tween
		Tween t = mTween;
		Tween hold = t;
		while (t!=null)
		{
			if (t.parm.equals(p))	// already exists
			{
				t.rate = rate;		// replace
				t.dur  = dur;
				return t;			// done
			}
			hold = t;
			t = t.next;
		}//_while
						// not found, add tween
		t = new Tween(p,rate,dur,delay);
		if (hold == null) mTween = t;	// head
		else hold.next = t;				// tail
		return t;		// done
	}//_tween_add

	public void tween_push (float dir, float acc, int dur, int delay)
	{								// add a push tween
		float avx = (float) (Math.cos(Math.toRadians(dir)));
		float avy = (float) (Math.sin(Math.toRadians(dir)));

		Tween t = tween_get ("push");
		if (t!=null) t.replace (avx, avy, acc, dur, delay);	// replace
		else
		{							// new tween
			Tween nt = new Tween(avx, avy, acc, dur, delay);
			t = mTween;
			Tween hold = t;
			while (t!=null) { hold = t; t = t.next; }
			if (hold == null) mTween = nt;	// head
			else hold.next = nt;			// tail
		}
	}//_tween_push

	public void tween_remove (String p) // remove tween(s)
	{									// p="*" is wildcard
		Tween t = mTween;
		Tween hold = t;
		while (t!=null)
		{
			if (p.equals("*") || t.parm.equals(p))
			{
				if (t==mTween)			// if head tween
				{
					mTween = t.next;	// remove head
					t.next = null; t.dur=0;
					t = hold = mTween;
					continue;
				}
				hold.next = t.next;		// unlink
				t.next = null; t.dur=0;
				t = hold.next;
				continue;
			}//_if match
			hold = t;
			t = t.next;					// next tween
		}//_while
	}//_tween_remove

	public Tween tween_get (String p)	// get tween with parm
	{									// null if not found
		Tween t = mTween;				// p "*" is wildcard
		while (t!=null)
		{
			if (p.equals("*") || t.parm.equals(p)) return t;
			t = t.next;
		}//_while
		return null;					// not found
	}//_tween_count

	// For GR.Get.Value
	public double get_ltrb (String parm)
	{
		switch (parm)
		{
			case "left": return mLeft;
			case "top":  return mTop;
			case "right": return mRight;
			case "bottom":return mBottom;
		}//_switch
		return 0.0;
	}//_get_ltrb

	public double get_x2y2 (String parm)
	{
		switch (parm)
		{
			case "x1": return mLeft;
			case "y1": return mTop;
			case "x2": return mRight;
			case "y2": return mBottom;
		}//_switch
		return 0.0;
	}//_get_x2y2

	public double getValue(String p)
	{						// For now, Text:"text" must be handled by Run
		switch (p)			// G_COMMON
		{
		case "x":	return mLeft;
		case "y":	return mTop;
		case "paint": return mPaint;
		case "alpha": return mAlpha;
		case "speed": return mSpeed;
		case "dir"	: return dir();
		}//_switch
							// specific parms
		return mType.mGetVal.getval(this,p);
	} //_getValue

	// For GR.Modify
	private boolean mod_x2y2(String p, float val) {
		if (p.equals("x1"))		{ mLeft   = val; return true; }
		if (p.equals("y1"))		{ mTop    = val; return true; }
		if (p.equals("x2"))		{ mRight  = val; return true; }
		if (p.equals("y2"))		{ mBottom = val; return true; }
		return false;
	}
	private boolean mod_ltrb(String p, float val) {
		if (p.equals("left"))	{ mLeft   = val; return true; }
		if (p.equals("top"))	{ mTop    = val; return true; }
		if (p.equals("right"))	{ mRight  = val; return true; }
		if (p.equals("bottom"))	{ mBottom = val; return true; }
		return false;
	}
	public boolean modify (String p, int iVal, float fVal, String text)
	{
						// -humpty 0303 Group objects are still handled in Run.
						// 	All below are still single objects
		mErrorMsg = "";
										// common parms
		if (Type.Common.mModify.modify(this, p, iVal, fVal, text)) return true;
		if (!mErrorMsg.equals("")) return false;
										// specific parms
		mErrorMsg = "Object does not contain: " + p;	// assume not found
		if (!mType.mModify.modify(this, p, iVal, fVal, text)) return false;
		mErrorMsg ="No error";
		return true;
	} //_modify

	// ************************** helper classes *****************************

	public static class Rfunc 								// execute a render
		{public void render(BDraw b, Canvas c, Paint p) {};}
	public static class Mfunc 								// execute a modify
		{public boolean modify(BDraw b, String p, int iVal, float fVal, String text) {return false;};}
	public static class Gfunc 								// execute a getter
		{public double getval(BDraw b, String p) {return 0.0;};}
	// ************************** object renderers *****************************

	public static Rfunc R_NO_OP = new Rfunc(){public void render(BDraw b, Canvas c, Paint p)
						{return;
						}};
	public static Rfunc R_OPEN = new Rfunc(){public void render(BDraw b, Canvas c, Paint p)
						{GR.Running = true;			// flag for GR.Open
						}};
	public static Rfunc R_CLOSE = new Rfunc(){public void render(BDraw b, Canvas c, Paint p)
						{GR.Running = false;		// flag for GR.Open
						}};
	public static Rfunc R_POINT = new Rfunc(){public void render(BDraw b, Canvas c, Paint p)
						{c.drawPoint (b.mLeft,b.mTop, p);
						}};
	public static Rfunc R_LINE = new Rfunc(){public void render(BDraw b, Canvas c, Paint p)
						{c.drawLine (b.mLeft, b.mTop, b.mRight, b.mBottom, p);
						}};
	public static Rfunc R_CIRCLE = new Rfunc(){public void render(BDraw b, Canvas c, Paint p)
						{c.drawCircle (b.mLeft, b.mTop, b.mRadius, p);
						}};
	public static Rfunc R_RECT = new Rfunc(){public void render(BDraw b, Canvas c, Paint p)
						{c.drawRect (b.mLeft, b.mTop, b.mRight, b.mBottom, p);
						}};
	public static Rfunc R_TEXT = new Rfunc(){public void render(BDraw b, Canvas c, Paint p)
						{c.drawText (b.text(), b.mLeft, b.mTop, p);
						}};
	public static Rfunc R_OVAL = new Rfunc(){public void render(BDraw b, Canvas c, Paint p)
						{ RectF rectf = new RectF(b.mLeft, b.mTop, b.mRight, b.mBottom);
						c.drawOval(rectf, p);
						}};
	public static Rfunc R_ARC = new Rfunc(){public void render(BDraw b, Canvas c, Paint p)
						{ RectF rectf = new RectF(b.mLeft, b.mTop, b.mRight, b.mBottom);
						c.drawArc(rectf, b.mAngle_1, b.mAngle_2, b.mUseCenter, p);
						}};
	public static Rfunc R_ROTSTART = new Rfunc(){public void render(BDraw b, Canvas c, Paint p)
						{c.save();				// -humpty 0261
						c.rotate(b.mAngle_1, b.mLeft, b.mTop);
						}};
	public static Rfunc R_ROTEND = new Rfunc(){public void render(BDraw b, Canvas c, Paint p)
						{c.restore();			// -humpty 0261
						}};
	public static Rfunc R_CLIPSTART = new Rfunc(){public void render(BDraw b, Canvas c, Paint p)
						{c.save();				// -humpty 0261
						if (Build.VERSION.SDK_INT < 26)
							{c.clipRect(b.mLeft, b.mTop, b.mRight, b.mBottom, b.mClipOp); return;}
						// Api 26+
						if (b.mClipOp == Region.Op.INTERSECT)
							c.clipRect(b.mLeft, b.mTop, b.mRight, b.mBottom);
						else c.clipOutRect(b.mLeft, b.mTop, b.mRight, b.mBottom);
						}};//_R_CLIPSTART
	public static Rfunc R_CLIPEND = new Rfunc(){public void render(BDraw b, Canvas c, Paint p)
						{c.restore();			// -humpty 0261
						}};
	public static Rfunc R_BITMAP = new Rfunc(){public void render(BDraw b, Canvas c, Paint p)
						{
						int bitmapIndex = b.bitmap();
						Bitmap theBitmap = Run.BitmapList.get(bitmapIndex);
						if (theBitmap != null)
						{
							if (!theBitmap.isRecycled())
								c.drawBitmap(theBitmap, b.mLeft, b.mTop, p);
							else
							{
								Run.BitmapList.set(bitmapIndex, null);
								theBitmap = null;
								GR.NullBitMap = true;
							}
						}
						else GR.NullBitMap = true;
						}};//_R_BITMAP
	public static Rfunc R_SPRITE = new Rfunc(){public void render(BDraw b, Canvas c, Paint p)
						{
						Bitmap bmp = null;
						int aPtr = b.mSprite.aniPtr;
						if (aPtr>0)						// has animation
						{
							Bitmap[] farray = GR.getAnim(aPtr);
							if (farray==null) return;	// bad animation
							int length = farray.length; if (length<1) return;
							float frame = b.mSprite.aFrame;
							if (frame<0 || frame >= length)	// illegal frame
							{
								if (b.mSprite.aLoop)			// if looping
								{								// force legal value
									frame = frame % length;
									if (frame < 0) frame += length;
								}
								if (frame >= length) frame = length-1;	// if over shot
								if (frame < 0) frame = 0;				// if under shot
								b.mSprite.aFrame = frame;	// force legal frame
							}
							bmp = farray[(int)frame];	// get bmp
						}
						else	// (aPtr<=0)			// standing bitmap
						{
							int bPtr = b.mBitmap;
							bmp = GR.getBitMap(bPtr);
						}
						if (bmp == null) return;
						c.drawBitmap(bmp, b.mLeft, b.mTop, p);
						}};//_R_SPRITE
	public static Rfunc R_POLY = new Rfunc(){public void render(BDraw b, Canvas c, Paint p)
						{
						ArrayList<Double> thisList = b.list();
						// User may have changed the list. If it has
						// an odd number of coordinates, ignore the last.
						int points = thisList.size() / 2;
						if (points < 2) return;	// do nothing if only one point
						float fx1 = b.mLeft;
						float fy1 = b.mTop;
						Path path = new Path();
						Iterator<Double> listIt = thisList.iterator();
						float firstX = listIt.next().floatValue() + fx1;
						float firstY = listIt.next().floatValue() + fy1;
						path.moveTo(firstX, firstY);
						for (int i = 1; i < points; ++i) {
							float x = listIt.next().floatValue() + fx1;
							float y = listIt.next().floatValue() + fy1;
							path.lineTo(x, y);
						}
						path.lineTo(firstX, firstY);
						path.close();
						c.drawPath(path, p);
						}};//_R_POLY
	public static Rfunc R_SETPIX = new Rfunc(){public void render(BDraw b, Canvas c, Paint p)
						{
						float fx1 = b.mLeft;
						float fy1 = b.mTop;
						Var.ArrayDef array = b.array();
						int pBase = b.arrayStart();
						int pLength = b.arraySublength();
						float[] pixels = new float[pLength];
						for (int j = 0; j < pLength; ++j) {
							pixels[j] = (float)array.nval(pBase + j) + fx1;
							++j;
							pixels[j] = (float)array.nval(pBase + j) + fy1;
						}
						c.drawPoints(pixels, p);
						}};//R_SETPIX
	// ************************** object modifiers *****************************

	public static Mfunc M_NO_OP = new Mfunc()
		{public boolean modify(BDraw b, String p, int iVal, float fVal, String text)
		{
			return true;
		}};

	public static Mfunc M_COMMON = new Mfunc()
		{public boolean modify(BDraw b, String p, int iVal, float fVal, String text)
		{
		switch (p)
		{
		case "x":
					b.mRight  += (fVal-b.mLeft); b.mLeft= fVal; return true;
		case "y":
					b.mBottom += (fVal-b.mTop);  b.mTop = fVal; return true;
		case "paint":					// paint range check is now done here
					if ((iVal < 1) || (iVal >= Run.PaintList.size()))
					{ b.mErrorMsg = "Invalid Paint object number" + iVal; return false; }
					b.paint (iVal); return true;
		case "alpha":
					b.alpha(fVal); return true;
		case "dir":
					b.dir (fVal); return true;
		case "speed":
					b.speed (fVal); return true;
		}//_switch
		return false;
		}};//_M_COMMON
	public static Mfunc M_GROUP = new Mfunc()
		{public boolean modify(BDraw b, String p, int iVal, float fVal, String text)
		{
			if (!p.equals("list")) return false;

			ArrayList<ArrayList> lists = Run.mInterpreter.theLists;
			ArrayList<Var.Type>  types = Run.mInterpreter.theListsType;

			if (types.get(iVal) != Var.Type.NUM)
			{ b.mErrorMsg = "List must be numeric"; return false; }

			if ((iVal < 1) || (iVal >= lists.size()))
			{ b.mErrorMsg = "Invalid list ptr "+iVal; return false; }

			b.listPtr(iVal);
			return true;
		}};
	public static Mfunc M_CIRCLE = new Mfunc()
		{public boolean modify(BDraw b, String p, int iVal, float fVal, String text)
		{
			if (!p.equals("radius")) return false;
			b.mRadius = fVal;
			return true;
		}};
	public static Mfunc M_BITMAP = new Mfunc()
		{public boolean modify(BDraw b, String p, int iVal, float fVal, String text)
		{
		switch (p)
		{
		case "bitmap":
			if ((iVal < 0) || (iVal >= Run.BitmapList.size()))
			{
				b.mErrorMsg = "Bitmap: bad bitmap ptr "+iVal;
				return false;
			}
			b.mBitmap=iVal;
			return true;
		case "width":
		case "height":	b.mErrorMsg = "cannot modify> "+p+" is read only";
						return false;
		}//_switch
		return false;
		}};//_M_BITMAP

	public static Mfunc M_SPRITE = new Mfunc()
		{public boolean modify(BDraw b, String p, int iVal, float fVal, String text)
		{
		switch (p)
		{
		case "bitmap":
			if ((iVal < 0) || (iVal >= Run.BitmapList.size()))
			{
				b.mErrorMsg = "Sprite: bad bitmap ptr "+iVal;
				return false;
			}
			b.mBitmap=iVal;
			return true;
		case "anim":
				if  (	(iVal < 0)
					||  (iVal >= Run.AnimList.size())
					||	(iVal > 0 && (Run.AnimList.get(iVal) == null))
					)
				{
					b.mErrorMsg = "Sprite: bad animation ptr "+iVal;
					return false;
				}
//				if (iVal == 0) b.mSprite.aFrame = 0;	// reset frame
				b.mSprite.aniPtr=iVal;
				return true;
		case "aframe":
				b.mSprite.aFrame=fVal;		// allow out of range
				return true;
		case "arate":	b.mSprite.aRate=fVal;
						return true;
		case "aloop":	b.mSprite.aLoop=(iVal!=0);
						return true;
		case "width":
		case "height":	b.mErrorMsg = "cannot modify> "+p+" is read only";
						return false;
		}//_switch
		return false;
		}};//_M_SPRITE
	public static Mfunc M_POINT = new Mfunc()
		{public boolean modify(BDraw b, String p, int iVal, float fVal, String text)
		{
			return true;
		}};
	public static Mfunc M_POLY = new Mfunc()
		{public boolean modify(BDraw b, String p, int iVal, float fVal, String text)
		{
			if (!p.equals("list")) return false;
			ArrayList<ArrayList> lists = Run.mInterpreter.theLists;
			ArrayList<Var.Type>  types = Run.mInterpreter.theListsType;

			if ((iVal < 1) || (iVal >= lists.size()))
				{ b.mErrorMsg = "Invalid list pointer"; return false; }

			if (types.get(iVal) != Var.Type.NUM)
				{ b.mErrorMsg = "List must be numeric"; return false; }

			int size = lists.get(iVal).size();
			if (size < 4)
				{ b.mErrorMsg = "List must have at least two points"; return false; }
			if ((size % 2) != 0)
				{ b.mErrorMsg = "List needs even number of elements"; return false; }

			b.listPtr(iVal);
			return true;
		}};
	public static Mfunc M_SETPIX = new Mfunc()
		{public boolean modify(BDraw b, String p, int iVal, float fVal, String text)
		{
			return true;
		}};
	public static Mfunc M_LINE = new Mfunc()
		{public boolean modify(BDraw b, String p, int iVal, float fVal, String text)
		{
			return (b.mod_x2y2(p, fVal));
		}};
	public static Mfunc M_CLIPSTART = new Mfunc()
		{public boolean modify(BDraw b, String p, int iVal, float fVal, String text)
		{
			if (p.equals("RO"))		{ b.clipOp(iVal); return true; }
			return (b.mod_x2y2(p, fVal));
		}};
	public static Mfunc M_OVAL = new Mfunc()
		{public boolean modify(BDraw b, String p, int iVal, float fVal, String text)
		{
			return (b.mod_ltrb(p, fVal));
		}};
	public static Mfunc M_RECT = new Mfunc()
		{public boolean modify(BDraw b, String p, int iVal, float fVal, String text)
		{
			return (b.mod_ltrb(p, fVal));
		}};
	public static Mfunc M_ARC = new Mfunc()
		{public boolean modify(BDraw b, String p, int iVal, float fVal, String text)
		{
			if (p.equals("start_angle"))	{ b.mAngle_1 = fVal; return true; }
			if (p.equals("sweep_angle"))	{ b.mAngle_2 = fVal; return true; }
			if (p.equals("fill_mode"))		{ b.useCenter(iVal); return true; }
			return (b.mod_ltrb(p, fVal));
		}};
	public static Mfunc M_ROTSTART = new Mfunc()
		{public boolean modify(BDraw b, String p, int iVal, float fVal, String text)
		{
			if (!p.equals("angle"))	return false;
			b.mAngle_1 = fVal;
			return true;
		}};
	public static Mfunc M_TEXT = new Mfunc()
		{public boolean modify(BDraw b, String p, int iVal, float fVal, String text)
		{
			if (!p.equals("text")) return false;
			b.mText = text;
			return true;
		}};
	// ************************** object getters *****************************

	public static Gfunc G_NO_OP = new Gfunc()
		{public double getval(BDraw b, String p) { return 0.0;}};
		
	public static Gfunc G_GROUP = new Gfunc()
		{public double getval(BDraw b, String p)
		{
			if (p.equals("list")) return b.mListIndex;
			return 0.0;
		}};
	public static Gfunc G_CIRCLE = new Gfunc()
		{public double getval(BDraw b, String p)
		{
			if (p.equals("radius")) return b.mRadius;
			return 0.0;
		}};
	public static Gfunc G_BITMAP = new Gfunc()
		{public double getval(BDraw b, String p)
		{
		switch (p)
		{
			case "bitmap":	return b.mBitmap;
			case "width":	return b.width();
			case "height":	return b.height();
		}//_switch
		return 0.0;
		}};//_G_BITMAP
	public static Gfunc G_SPRITE = new Gfunc()
		{public double getval(BDraw b, String p)
		{
		switch (p)
		{
			case "bitmap":	return b.mBitmap;
			case "anim":	return b.mSprite.aniPtr;
			case "aframe":	return b.mSprite.aFrame;
			case "arate":	return b.mSprite.aRate;
			case "aloop":	return b.mSprite.aLoop ? 1.0 : 0.0;
			case "width":	return b.width();
			case "height":	return b.height();
		}//_switch
		return 0.0;
		}};//_G_SPRITE

	public static Gfunc G_POINT = new Gfunc()		// can't happen
		{public double getval(BDraw b, String p) { return 0.0;}};

	public static Gfunc G_POLY = new Gfunc()
		{public double getval(BDraw b, String p)
		{
			if (p.equals("list")) return b.mListIndex;
			return 0.0;
		}};
	public static Gfunc G_SETPIX = new Gfunc()		// can't happen
		{public double getval(BDraw b, String p) { return 0.0;}};

	public static Gfunc G_LINE = new Gfunc()
		{public double getval(BDraw b, String p) { return b.get_x2y2(p);}};

	public static Gfunc G_CLIPSTART = new Gfunc()
		{public double getval(BDraw b, String p)
		{
			if (p.equals("RO")) return b.mClipOpIndex;
			return b.get_x2y2(p);
		}};
	public static Gfunc G_OVAL = new Gfunc()
		{public double getval(BDraw b, String p) { return b.get_ltrb(p);}};

	public static Gfunc G_RECT = new Gfunc()
		{public double getval(BDraw b, String p) { return b.get_ltrb(p);}};

	public static Gfunc G_ARC = new Gfunc()
		{public double getval(BDraw b, String p)
		{
		switch (p)
		{
			case "start_angle":	return b.mAngle_1;
			case "sweep_angle":	return b.mAngle_2;
			case "fill_mode":	return b.mFillMode;
		}
		return b.get_ltrb(p);
		}};
	public static Gfunc G_ROTSTART = new Gfunc()
		{public double getval(BDraw b, String p)
		{
			if (p.equals("angle")) return b.mAngle_1;
			return 0.0;
		}};
	// ************* enumeration of BASIC! Drawable Object types **************

	public enum Type {
		Common ("",		new String[]{"x","y","paint","alpha","speed","dir"},R_NO_OP, M_COMMON, G_NO_OP),
		Null("null", 	new String[0], R_NO_OP, M_NO_OP, G_NO_OP),
		Point("point",	new String[]{}, R_POINT, M_POINT, G_POINT),
		Line("line",	new String[]{"x1", "y1", "x2", "y2" }, R_LINE, M_LINE, G_LINE),
		Rect("rect",	new String[]{"left","right","top","bottom"}, R_RECT, M_RECT, G_RECT),
		Circle("circle",new String[]{"radius" } , R_CIRCLE, M_CIRCLE, G_CIRCLE),
		Oval("oval",	new String[]{"left","right","top","bottom"} ,R_OVAL, M_OVAL, G_OVAL),
		Arc("arc",		new String[]{"left", "right", "top", "bottom",
							"start_angle", "sweep_angle", "fill_mode"}, R_ARC, M_ARC, G_ARC),
		Poly("poly",	new String[]{"list" }, R_POLY, M_POLY, G_POLY),
		Bitmap("bitmap",new String[]{"bitmap","width","height"}, R_BITMAP, M_BITMAP, G_BITMAP),
		Sprite("sprite",new String[]{"bitmap","anim","arate","aframe","aloop","width","height"}, R_SPRITE, M_SPRITE, G_SPRITE),
		SetPixels(
		"set.pixels",	new String[]{} , R_SETPIX, M_SETPIX, G_SETPIX),
		Text("text",	new String[]{"text" }, R_TEXT, M_TEXT, G_NO_OP),
		Group("group",	new String[]{"list" }, R_NO_OP, M_GROUP, G_GROUP),
		RotateStart(
		"rotate.start",	new String[]{"angle" }, R_ROTSTART, M_ROTSTART, G_ROTSTART),
		RotateEnd(
		"rotate.end",	new String[0], R_ROTEND, M_NO_OP, G_NO_OP),
		ClipStart(
		"clip.start",	new String[]{"left","right","top","bottom","RO"}, R_CLIPSTART, M_CLIPSTART, G_CLIPSTART),
		ClipEnd(
		"clip.end",		new String[0], R_CLIPEND, M_NO_OP,G_NO_OP),		// -humpty 0261
		Open("open",	new String[0], R_OPEN, M_NO_OP, G_NO_OP),
		Close("close",	new String[0], R_CLOSE, M_NO_OP, G_NO_OP);

		private final String mType;
		private final String[] mParameters;	// all parameters except common
		public final Rfunc mRender;
		public final Mfunc mModify;
		public final Gfunc mGetVal;

		Type(String type, String[] parameters, Rfunc render, Mfunc modify, Gfunc getval)
		{
			mType = type;
			mParameters = parameters;
			mRender = render;
			mModify = modify;
			mGetVal = getval;
		}
		public String type()			{ return mType; }
		public String[] parameters()	{ return mParameters; }

		public boolean hasParameter (String parameter) {
			for (String p : mParameters) {
				if (p.equals (parameter)) { return true; }
			}
			return isCommon(parameter);
		}
		public boolean isCommon (String parameter) {
			for (String p : Type.Common.parameters()) {
				if (p.equals (parameter)) { return true; }
			}
			return false;
		}
	}//_Type

	public static class Sprite
	{
		private int aniPtr = 0;			// animation ptr
		private float aRate = 10.0f;	// animation rate = frames per sec
		private boolean aLoop = true;	// animation loop
		public	float aFrame=0.0f;		// animation frame

		public Sprite(BDraw d, float x, float y,int b, int a)
		{
			d.mBitmap = b;	aniPtr = a;
			d.mLeft = x; d.mTop = y;
			d.mSprite = this;			// attach it
		}
	}//_Sprite

	public static class Tween
	{
		public String parm = "";	// parameter
		private	float rate=0.0f;	// rate of change or goal
		private boolean goal=false;	// is rate a goal ?
		private	int dur=0;			// duration (ms)
		private float aVx=0;		// for a push
		private float aVy=0;
		private int delay=0;		// delay exec
		private Tween next = null;	// next tween

		public Tween(String p, float r, int d, int del)
		{
			parm=p; rate=r; dur=d; delay=del;
		}
		public Tween(float vx, float vy, float acc, int d, int del)
		{
			parm = "push";
			aVx=vx; aVy=vy; rate=acc; dur=d; delay=del;
		}
		public void replace (float r, int d, int del)
		{								// replace existing tween
			rate = r; dur=d; delay=del;
		}
		public void replace (float vx,float vy,float acc,int d,int del)
		{								// replace push
			aVx=vx; aVy=vy; rate=acc; dur=d; delay=del;
		}
		public void setGoal(float total) { rate=total; goal=true;}
	}//_Tween
} // BDraw class
