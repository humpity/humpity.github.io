document.write ('Your speech goes here');
