/****************************************************************************************************

BASIC! is an implementation of the Basic programming language for
Android devices.

Copyright (C) 2010 - 2015 Paul Laughton

This file is part of BASIC! for Android

    BASIC! is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    BASIC! is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with BASIC!.  If not, see <http://www.gnu.org/licenses/>.

    You may contact the author or current maintainers at http://rfobasic.freeforums.org

*************************************************************************************************/

package com.rfo.hbasic;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;

import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

import android.text.Spanned;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.app.ActionBar;

public class TextInput extends Activity {
	private Button okButton;				// finished button
	private EditText et;					// The EditText TextView

//	private boolean lockReleased;			// safety valve so interpreter doesn't get hung if this
											// instance is destroyed without first releasing the LOCK

	@Override
	public boolean onKeyUp(int keyCode, KeyEvent event)  {
		// if BACK key leave original text unchanged
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			releaseLock();
			return true;
		}
		return super.onKeyUp(keyCode, event);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		Intent intent = getIntent();
		String title = intent.getStringExtra("title");

//		lockReleased = false;

		if (title==null) title = getResources().getString(R.string.textinput_name);

		Astyle.setStyling (this, title);
		Astyle.setSystemBars(this);

		setContentView(R.layout.text_input);	// Layout xmls exist for both landscape and portrait modes

		okButton = (Button) findViewById(R.id.ok_button);		// The buttons

		et = (EditText) findViewById(R.id.the_text);				// The text display area
		et.setText(Run.TextInputString);							// The Editor's display text
		et.setTypeface(Typeface.MONOSPACE);
		et.setSelection(Run.TextInputString.length());

		Basic.TextStyle style = Basic.defaultTextStyle;
		if (Astyle.textFG != null) et.setTextColor(Astyle.textFG);
		else et.setTextColor(style.mTextColor);
		if (Astyle.textBG != null) et.setBackgroundColor(Astyle.textBG);
		else et.setBackgroundColor(style.mBackgroundColor);

		et.setTextSize(1, Settings.getFont(this));

		okButton.setOnClickListener(new OnClickListener() {			// **** Done Button ****

			public void onClick(View v) {
				Run.TextInputString = et.getText().toString();		// Grab the text that the user is seeing
				Run.TextInputUpdated = true;
				releaseLock();
				return;
			}
		});

	}//_onCreate

	@Override
	protected void onResume()
	{
		Run.setDIALOG = false;
		super.onResume();
	}

	public void releaseLock() {
//		if (lockReleased) return;

//		synchronized (Run.LOCK) {
//			Run.mWaitForLock = false;
//			lockReleased = true;
//			Run.LOCK.notify();								// release the lock that Run is waiting for
//		}
		finish();
	}

	@Override
	public void onDestroy() {
		releaseLock();										// if not already released, release the lock that Run is waiting for
		super.onDestroy();
	}

}
