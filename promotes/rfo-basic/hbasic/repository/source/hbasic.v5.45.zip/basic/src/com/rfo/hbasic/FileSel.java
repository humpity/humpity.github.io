
package com.rfo.hbasic;

import java.io.File;
import java.io.IOException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;

import com.rfo.hbasic.Basic.ColoredTextAdapter;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;

import android.os.Build;
import android.os.Bundle;
import android.os.Handler;

import android.text.Editable;

import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;

import android.widget.Button;
import android.widget.EditText;
import android.widget.AdapterView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import android.graphics.drawable.ColorDrawable;

import android.content.ClipData;
import android.content.ClipboardManager;

import static com.rfo.hbasic.Editor.GO_UP;
import static com.rfo.hbasic.Editor.addDirMark;
import static com.rfo.hbasic.Editor.isMarkedDir;
import static com.rfo.hbasic.Editor.stripDirMark;
import static com.rfo.hbasic.Editor.getDisplayPath;
import static com.rfo.hbasic.Editor.goUp;
import static com.rfo.hbasic.Editor.quote;

// Selects a file or dir. Returns a path.
// Similar to LoadFile but called from a basic command

public class FileSel extends Activity
{
	private EditText et;					// filename
	private Button okButton;				// done button

	private Basic.ColoredTextAdapter mAdapter;
	private Basic.mOutputArray<String> FL = new Basic.mOutputArray<String>();
	private Toast mToast = null;

	private String mDirPath;			// current absolute path
										// working vars
	private String path = "";			// path displayed
	private String fileName = "";
	private boolean absMode = false;
	private View lastView = null;

	public static String Path;			// path-in, path-out
	public static String EndFilter;		// filter for end of filename
	public static boolean DirMode;		// only select directories
	public static boolean DirLock;		// prohibit dir traversal
	public static boolean Editable;		// allow new filename or dirname
	public static boolean MultiMode;			// multi selection
	public static ArrayList<String> selectList;	// multi filenames
	public static String Title;
	public static int RetCode;

	public static void initVars()
	{
		Path = "";
		EndFilter = "";
		DirMode = false;
		DirLock = false;
		Editable = false;
		MultiMode = false;
		Title = "Select File";
		RetCode = -1;		// default is cancelled
		selectList = null;
	}//_initVars

	@Override
	public boolean onKeyUp(int keyCode, KeyEvent event)
	{
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0)
		{
			RetCode = -1;	// cancelled
			Toast_Kill();
			finish();
			return true;
		}
		return super.onKeyUp(keyCode, event);
	}//_onKeyUp

	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
//		setRequestedOrientation(Settings.getScreenOrientation(this));
		Intent intent = getIntent();

		if (selectList == null) selectList = new ArrayList<String>();	// sanity check

		Astyle.setStyling (this, Title);
		Astyle.setSystemBars(this);
		if (Build.VERSION.SDK_INT > 27)
		{
			ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
			clipboard.clearPrimaryClip();
		}
//-----
		File file;
		path = Path;
		int sep = 0;
		int len = path.length();
		if ( len>1 && path.charAt(len-1)==File.separatorChar )
		{										// is a directory
			path = path.substring(0,len-1);		// cut off the last '/'
		}
		else									// is a filename
		{
			sep = path.lastIndexOf(File.separatorChar);
			fileName = path.substring (sep+1);
			if (sep>0)	path = path.substring (0,sep);	// get path
			else if (sep<0)	path = "";					// no sep is relative to data
			else path = File.separator;				// one sep is absolute
		}
		if (path.startsWith(File.separator))	// is absolute path
		{
			absMode = true;
			file = new File(path);
		}
		else									// is relative path
		{
			file = new File(Basic.getDataPath(null)+"/"+path);
		}
		if (!file.exists() || !file.isDirectory())	// bad directory ?
		{
			RetCode = -2;							// directory error
			Run.setDIALOG = false;
			finish();
			return;
		}

		try                  { mDirPath = file.getCanonicalPath(); }
		catch(IOException e) { mDirPath = file.getAbsolutePath(); }

		if (DirMode|| MultiMode) fileName = "";	// ignore any filename given
//------
		mAdapter = new ColoredTextAdapter(this, FL, Basic.defaultTextStyle);

		setContentView(R.layout.filesel);

		okButton = (Button) findViewById(R.id.ok_button);

		et = (EditText) findViewById(R.id.filesel_text);
		if (!Editable)
		{
			et.setEnabled (false);					// disable edittext
			et.setBackgroundColor (0xFFD6D7D7);		// 	dim it
			if (DirMode || MultiMode)				// directory mode or multi
				et.setVisibility(View.INVISIBLE);	// 	hide it
		}
		et.setText (fileName);						// editText = filename
		et.clearFocus();

		ListView lv = (ListView)findViewById(R.id.fileSel); 
		lv.setAdapter(mAdapter);
		lv.setTextFilterEnabled(false);
		lv.requestFocus();

		if (Astyle.textBG != null) mAdapter.setBackgroundColor (Astyle.textBG);
		if (Astyle.textFG != null) mAdapter.setTextColor (Astyle.textFG);
		if (Astyle.highColor != null) mAdapter.setHighlightColor (Astyle.highColor);
		if (Astyle.voidColor != null) lv.setBackgroundColor(Astyle.voidColor);
		else lv.setBackgroundColor(mAdapter.getBackgroundColor()); // follow textBG

		lv.setDivider(new ColorDrawable(mAdapter.getLineColor()));	// -humpty 0310
		lv.setDividerHeight(1);						// needs this or it won't work

		updateList();								// put file list in FL

		// Click listeners
		lv.setOnItemClickListener(new OnItemClickListener()
		{
			public void onItemClick(AdapterView<?> parent, View view, int position, long id)
			{
				// User has selected a line.
				// If the selection is the top line, ignore it.
				if (position == 0)		return;

				// If the selection is a directory, change the program path
				// and then display the list of files in that directory.
				// Otherwise select file.

				fileName = FL.get(position);

				if (SelectionIsFile(fileName) && !DirMode)
				{
					if (MultiMode)		// file selected in multi-mode
					{
						Basic.mStyList styList = mAdapter.mList.styLists.get(position);
						styList.selected = !styList.selected;
						mAdapter.notifyDataSetChanged();
						return;
					}
										// file selected in single mode
					if (lastView!=null)			// un-highlight last picked
						lastView.setBackgroundColor(mAdapter.getBackgroundColor());
					lastView = view;

					view.setBackgroundColor(mAdapter.getHighlightColor());
					et.setText (fileName);		// editText = new filename
					Toast_Kill();
					return;
				}
				// any thing else, just ignore
			}//_onItemClickListener
		});

		okButton.setOnClickListener(new OnClickListener()	// **** Done Button ****
		{
			public void onClick(View v)
			{
				fileName = et.getText().toString();

				if (
							   !path.isEmpty ()
							&& !path.endsWith (File.separator))
					path += File.separator;	// dirs must end with '/'

				fileName = fileName.trim();		// trim illegal chars
				String sep = "\\"+File.separator+"+";
				fileName = fileName.replaceAll(sep+"$|^"+sep, "");

				if (DirMode && !fileName.isEmpty())
					fileName += File.separator; // user dirs must end with '/'

				path = path += fileName;		// add the filename

				Path=path;
				if (MultiMode)		// multi mode
				{
					selectList.clear();
					for (int i=0; i<FL.size(); i++)
					{
						Basic.mStyList styList = mAdapter.mList.styLists.get(i);
						if (styList.selected) selectList.add (FL.get(i));
					}
					RetCode = selectList.size();	// returns a list
				}
				else				// single selection
				{
					if (DirMode) RetCode = 1;		// returns a path
					else							// returns a file
						if (path.isEmpty()) RetCode = 0; else RetCode = 1;
				}
				Toast_Kill();
				finish();
				return;
			}
		});//_okButton
		// End of Click Listeners
	}//_onCreate
//-------------------------------------------------
	@Override
	protected void onResume()
	{
		Run.setDIALOG = false;
		super.onResume();
	}//_onResume

	@Override
	public void onDestroy() {
		super.onDestroy();
		finish();
	}
//-------------------------------------------------
	private void Toast_Kill ()						// kill current toast
	{
		if (mToast != null)	{ mToast.cancel(); mToast = null; }
	}//_Toast_Kill
//-------------------------------------------------
	private void Toast_Now (String msg)				// Toast immediatley
	{
		Toast_Kill();								// kill any current toast
		mToast = Basic.toaster(this, msg);
	}//_Toast_Now
//-------------------------------------------------
	private String[] GetFileList(File dir)	// get the list of files in a directory
	{
		String fileList[] = dir.list();
		if (fileList == null) {					// null means not a directory
			fileList = new String[] {" "};		// make a blank entry.
		}
		return fileList;
	}//_GetFileList
//-------------------------------------------------
	private void updateList()
	{	// Note: The checking for SD card present was done in the Editor just before calling delete

		// Go through the file list and mark directory entries with (d)
		ArrayList<String> dirs = new ArrayList<String>();
		ArrayList<String> files = new ArrayList<String>();
		File dir = new File(mDirPath);

		for (String s : GetFileList(dir)) {		// for each file in the directory
			File test = new File(mDirPath, s);
			if (test.isDirectory()) {			// If file is a directory, add "(d)"
				dirs.add(addDirMark(s));		// and add to display list
			} else {
				if (s.toLowerCase(Locale.getDefault()).endsWith(EndFilter))
				files.add(s);					// else add name without the (d)
			}
		}
		Collections.sort(dirs);					// Sort the directory list
		Collections.sort(files);				// Sort the file list

		if (!absMode) path = Basic.getRelativePath(mDirPath, Basic.getDataPath(null));
		else		  path = dir.getPath();		// show absolute path

		FL.clear();
//		FL.add("Path: " + getDisplayPath(mDirPath));			// put the path at the top of the list - will not be selectable
		FL.add("Path: " + path);				// put the path at the top of the list - will not be selectable
		if (!DirLock)
		{
			FL.add(GO_UP);			// put  the ".." above the directory contents
			FL.addAll(dirs);						// copy the directory list to the adapter list
		}
		if (!DirMode) FL.addAll(files);			// copy the file list to the end of the adapter list

		if (mAdapter != null) { mAdapter.notifyDataSetChanged(); }

//		Toast_Now ("Select file to Delete");	// tell the user what to do using Toast
	}//_updateList
//-------------------------------------------------
	private boolean SelectionIsFile(String fName) {
		
		// Test to see if the user selection is a file or a directory
		// If is directory, then change the path. return..
												// 0=ignored, 1=file, 2=dir
		if (fName.equals(GO_UP)) 				// if GoUp is selected
		{
			String parent = goUp(mDirPath);		// change path to its parent directory
			if (parent.equals(mDirPath))		// if no change
			{									// then it failed
				Toast_Now ("Directory Error: Cannot Go Up");	// give an error msg. Do not updateList()
			}
			else
			{
				mDirPath = parent;				// success, new path
				updateList();					// update the list
				lastView = null;
			}
			return false;						// report this is not a file
		}//_ if GO_UP
												// Not UP, is selection a dir
		if (isMarkedDir(fName)) 				// if has (d), then is directory
		{
			fName = stripDirMark(fName);		// remove the (d)
			mDirPath = new File(mDirPath, fName).getPath();	// add dir to path
			updateList();						// update the list
			lastView = null;
			return false;						// report this is not a file
		}
		return true;							// if none of the above, it is a file
	}//_SelectionIsFile

}//_FileSel
