/****************************************************************************************************

BASIC! is an implementation of the Basic programming language for
Android devices.

Copyright (C) 2010 - 2015 Paul Laughton

This file is part of BASIC! for Android

    BASIC! is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    BASIC! is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with BASIC!.  If not, see <http://www.gnu.org/licenses/>.

    You may contact the author or current maintainers at http://rfobasic.freeforums.org

*************************************************************************************************/

package com.rfo.hbasic;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;

import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

import android.text.Spanned;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.app.ActionBar;

public class TextInput extends Activity
{
//	private boolean lockReleased;			// safety valve so interpreter doesn't get hung if this
											// instance is destroyed without first releasing the LOCK
	private Button okButton;				// finished button
	private EditText et;					// The EditText TextView
	public static String Str = "";			// the result
	public static String Title = "";
	public static boolean Updated = false;

	public static void initVars()
	{
		Str = "";
		Title = "Text Input";
		Updated = false;
	}//_initVars

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

//		lockReleased = false;

		Astyle.setStyling (this, Title);
		Astyle.setSystemBars(this);

		setContentView(R.layout.text_input);

		okButton = (Button) findViewById(R.id.ok_button);	// The buttons

		et = (EditText) findViewById(R.id.the_text);		// The text display area
		et.setText (Str);									// The Editor's display text
		et.setTypeface (Typeface.MONOSPACE);
		et.setSelection (Str.length());

		Basic.TextStyle style = Basic.defaultTextStyle;
		if (Astyle.textFG != null) et.setTextColor(Astyle.textFG);
		else et.setTextColor(style.mTextColor);
		if (Astyle.textBG != null) et.setBackgroundColor(Astyle.textBG);
		else et.setBackgroundColor(style.mBackgroundColor);

		et.setTextSize(1, Settings.getFont(this));

		okButton.setOnClickListener(new OnClickListener() {			// **** Done Button ****

			public void onClick(View v) {
				Str = et.getText().toString();	// Grab the text that the user is seeing
				Updated = true;
				releaseLock();
				return;
			}
		});
	}//_onCreate

	@Override
	public void onBackPressed()
	{
		releaseLock();
	}//_onBackPressed

	@Override
	protected void onResume()
	{
		Run.setDIALOG = false;
		super.onResume();
	}//_onResume

	public void releaseLock() {
//		if (lockReleased) return;

//		synchronized (Run.LOCK) {
//			Run.mWaitForLock = false;
//			lockReleased = true;
//			Run.LOCK.notify();								// release the lock that Run is waiting for
//		}
		finish();
	}//_releaseLock
}//_TextInput
