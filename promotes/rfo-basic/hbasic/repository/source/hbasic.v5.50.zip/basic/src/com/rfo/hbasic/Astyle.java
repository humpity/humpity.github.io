
package com.rfo.hbasic;

import android.os.Build;

import android.app.Activity;

import android.view.View;
import android.view.WindowManager;
import android.view.WindowInsets;
import android.view.WindowInsets.Type;
import android.view.WindowInsetsController;

import android.content.Context;

import android.graphics.drawable.ColorDrawable;

import android.text.style.ForegroundColorSpan;
import android.text.style.AbsoluteSizeSpan;
import android.text.Spanned;
import android.text.SpannableString;

import android.util.Log;

import android.widget.TextView;

public class Astyle							// Activity Styling Module
{
	private static final String LOGTAG = "Astyle";

/***************** Styling for Activity Dialogs *****************************/

	public static Integer titleFG = null;	// text color for actionbar
	public static Integer titleBG = null;	// bg color for actionbar
	public static Integer windowBG = null;	// bg color for window
	public static Integer textFG = null;	// fg color for TextInput & FileSel
	public static Integer textBG = null;	// bg color for TextInput & FileSel
	public static Integer voidColor = null;	// listview empty text
	public static Integer highColor = null;	// listview highlight color
//	public static Integer buttonFG = null;	// button color for TextInput & FileSel
//	public static Integer buttonBG = null;	// button bg for TextInput & FileSel
	public static Boolean darkStaText = null;
	public static Boolean darkNavText = null;
//------------------------------------------
	public static void initVars()
	{
		titleFG = titleBG = windowBG = textFG = textBG
		= voidColor = highColor = null;
//		buttonFG = buttonBG = null;
		darkStaText = darkNavText = null;
	}//_initVars
//------------------------------------------
	public static void setSystemBars (Context cx)	// default style for aDialogs
	{
		Activity act = (Activity) cx;

		fixSysBars		(cx, false);
		setStatusBar	(cx, true);
		setNavBar		(cx, true);
		if (darkStaText != null) setDarkStaText (cx, darkStaText);
		else					 setDarkStaText(cx, false);
		if (darkNavText != null) setDarkNavText (cx, darkNavText);
		else 					 setDarkNavText(cx, false);
		act.getActionBar().setElevation(0);
	}//_setSystembars
//------------------------------------------
									// set statusbar to default state
	public static void setStatusBar (Context cx, boolean show)
	{
		Activity act = (Activity) cx;
		if (Build.VERSION.SDK_INT < 30)
		{
			View decor = act.getWindow().getDecorView();
			if (show)
			{														// show status bar
				int flags = decor.getSystemUiVisibility()
				&
				(
					~View.SYSTEM_UI_FLAG_FULLSCREEN				// Api 16-29
				&	~View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN		// Api 16-29
				);
				decor.setSystemUiVisibility (flags);
			}
			else
			{														// hide status bar
				int flags = decor.getSystemUiVisibility()
				|
				(
					View.SYSTEM_UI_FLAG_FULLSCREEN				// Api 16-29
				|	View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN		// Api 16-29
				);
				decor.setSystemUiVisibility (flags);
			}
		}//_< Android 11
		else	// Android 11+
		{
	        final WindowInsetsController insetsController =
					act.getWindow().getInsetsController();
			if (insetsController == null) return;				// (should not happen)
			if (show)							// show status bar
				insetsController.show(WindowInsets.Type.statusBars());
			else								// hide status bar
			{
				insetsController.hide(WindowInsets.Type.statusBars());
				insetsController.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
			}//_hide
		}//_Android 11+
	}//_setStatusBar
//------------------------------------------
									// set navbar to default state
	public static void setNavBar (Context cx, boolean show)
	{
		Activity act = (Activity) cx;
		if (Build.VERSION.SDK_INT < 30)
		{
			View decor = act.getWindow().getDecorView();
			if (show)
			{
				int flags = decor.getSystemUiVisibility()	// show
				&
				(
					~View.SYSTEM_UI_FLAG_HIDE_NAVIGATION	// Api 14
				&	~View.SYSTEM_UI_FLAG_IMMERSIVE			// Api 19
				);
				decor.setSystemUiVisibility (flags);
			}//_show
			else
			{
				int flags = decor.getSystemUiVisibility()	// hide
				|
				(
					View.SYSTEM_UI_FLAG_HIDE_NAVIGATION		// Api 14
				|	View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY	// Api 19
				);
				decor.setSystemUiVisibility (flags);
			}//_hide
		}//_< Android 11
		else	// Android 11+
		{
	        final WindowInsetsController insetsController =
					act.getWindow().getInsetsController();
			if (insetsController == null) return;				// (should not happen)

			if (show)								// show nav bars
				insetsController.show(WindowInsets.Type.navigationBars());
			else									// hide nav bar
			{
				insetsController.hide(WindowInsets.Type.navigationBars());	// hide nav bars
				insetsController.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
			}//_hide
		}//_Android 11+
	}//_setNavBar
//------------------------------------------
							// set text color for status bar API 30+
	public static void setDarkStaText (Context cx, boolean dark)
	{								// dark text = light bars.
		Activity act = (Activity) cx;
		if (Build.VERSION.SDK_INT < 23) return; // < Android 6 unsupported

		if (Build.VERSION.SDK_INT < 30) 	// Api 23 - Api 29
		{
			View decor = act.getWindow().getDecorView();
			int flags = decor.getSystemUiVisibility();
			if (dark)									// dark text
				flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;	// Api 23
			else										// light text
				flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;// Api 23
			decor.setSystemUiVisibility (flags);
			return;
		}
											// >= Api 30
        final WindowInsetsController insetsController =
				act.getWindow().getInsetsController();
		int mask =	WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS;
		int toggle=0;
		if (dark) toggle = mask;	// dark text uses mask else 0
		insetsController.setSystemBarsAppearance (toggle, mask);
	}//_setDarkStaTxt
//------------------------------------------
							// set icon color for nav bar API 30+
	public static void setDarkNavText (Context cx, boolean dark)
	{								// dark icons = light bars.
		Activity act = (Activity) cx;
		if (Build.VERSION.SDK_INT < 26) return; // < Android 8 unsupported

		if (Build.VERSION.SDK_INT < 30) 	// Api 26 - Api 29
		{
			View decor = act.getWindow().getDecorView();
			int flags = decor.getSystemUiVisibility();
			if (dark)									// dark icons
				flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;	// Api 23
			else										// light icons
				flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;// Api 23
			decor.setSystemUiVisibility (flags);
			return;
		}
											// >= Api 30
        final WindowInsetsController insetsController =
				act.getWindow().getInsetsController();
		int mask =	WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
		int toggle=0;
		if (dark) toggle = mask;	// dark icons use mask else 0
		insetsController.setSystemBarsAppearance (toggle, mask);
	}//_setDarkNavTxt
//------------------------------------------
									// fix overwriting of sysbars
	public static void fixSysBars (Context cx, boolean immersive)
	{
		Activity act = (Activity) cx;

		if (immersive)
			act.getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

		if (Build.VERSION.SDK_INT < 21) return;
		act.getWindow().addFlags(WindowManager.LayoutParams
					.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);

		if (Build.VERSION.SDK_INT > 34) return;
		act.getWindow().setStatusBarColor(0);
		act.getWindow().setNavigationBarColor(0);
	}//_fixSysBars
//------------------------------------------
	public static void SetTitle (Context cx, String title)
	{
		SpannableString ss = new SpannableString(title);
		SetTitle (cx, ss);
	}//_SetTitle text
//------------------------------------------
										// set and fix activity title
	public static void SetTitle (Context cx, SpannableString ss)
	{
		Activity act = (Activity) cx;
//		int ori = cx.getResources().getConfiguration().orientation;
//		if (ori == Configuration.ORIENTATION_LANDSCAPE)
		{
			ss.setSpan (new AbsoluteSizeSpan ((int)(20.0f * Basic.DensityDpiSF)),
					0,ss.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
		}
		act.getActionBar().setTitle(ss);
	}//_SetTitle
//------------------------------------------
										// set activity subtitle
	public static void SetSubtitle (Context cx, SpannableString ss)
	{
		Activity act = (Activity) cx;
//		int ori = cx.getResources().getConfiguration().orientation;
//		if (ori == Configuration.ORIENTATION_LANDSCAPE)
		{
			ss.setSpan (new AbsoluteSizeSpan ((int)(16.0f * Basic.DensityDpiSF)),
					 0,ss.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
		}
		act.getActionBar().setSubtitle(ss);
	}//_SetSubtitle
//------------------------------------------
	public static void SetStyling (Context cx,
						String title, Integer title_fg, Integer title_bg,
						String subtitle, Integer subtitle_fg,
						Integer window_bg)
	{										// one off styling
		Activity act = (Activity) cx;
		int color;	SpannableString ss;

		color = window_bg==null?0xFF000000:window_bg;
		act.getWindow().setBackgroundDrawable(new ColorDrawable(color));

		if (act.getActionBar()==null) return;	// do nothing if no actionbar

		color = title_fg==null?0xFFDEDEDE:title_fg;		// alt 0xFFE1E1E2
		ss = new SpannableString(title);
		ss.setSpan(new ForegroundColorSpan(color), 0, title.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
		SetTitle (cx, ss);

		color = title_bg==null?0x00000000:title_bg;
		act.getActionBar().setBackgroundDrawable(new ColorDrawable(color));

		if (subtitle==null) return;
		color = subtitle_fg==null?0xFFDEDEDE:subtitle_fg;
		ss = new SpannableString(subtitle);
		ss.setSpan(new ForegroundColorSpan(color), 0, subtitle.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
		SetSubtitle (cx, ss);

	}//_setStyling
//------------------------------------------
	public static void setStyling(Context cx, String title)
	{										// style global dialogs
		SetStyling (cx, title, titleFG, titleBG, null,null, windowBG);
	}//_setStyling
//------------------------------------------
}//_Astyle
