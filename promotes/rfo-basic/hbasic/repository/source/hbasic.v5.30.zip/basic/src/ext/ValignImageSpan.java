// credits: RoShan Shan https://stackoverflow.com/a/43404618/2779074

package ext;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.text.style.DynamicDrawableSpan;

import android.text.style.ImageSpan;
import java.lang.ref.WeakReference;

public class ValignImageSpan extends ImageSpan 
{
    private WeakReference<Drawable> mDrawableRef;
    private int initialDescent = 0;
    private int extraSpace = 0;
	private int mOffset = 0;

    public ValignImageSpan(Context context, final int drawableRes)
	{
        super(context, drawableRes);
    }
    public ValignImageSpan(Drawable drawableRes, int verticalAlignment)
	{
        super(drawableRes, verticalAlignment);
    }
    public ValignImageSpan(Drawable drawableRes, int verticalAlignment, int offset)
	{
        super(drawableRes, verticalAlignment);
		mOffset = offset;
		if (mOffset<1 || mOffset>100) mOffset = 0;	// force range
    }
    @Override
    public int getSize(Paint paint, CharSequence text,
                       int start, int end,
                       Paint.FontMetricsInt fm)
	{
        Drawable d = getCachedDrawable();
        Rect rect = d.getBounds();
        if (fm == null) return rect.right;

		if (rect.bottom - (fm.descent - fm.ascent) >= 0)
		{
			initialDescent = fm.descent;
			extraSpace = rect.bottom;
		}
		fm.descent = initialDescent + (int) ((float)extraSpace*((float)mOffset/100.0f));
		fm.ascent = fm.descent - rect.bottom;

		fm.bottom = fm.descent;
		fm.top = fm.ascent;
        return rect.right;
    }//_getSize

    // Redefined locally because it is a private member from DynamicDrawableSpan
    private Drawable getCachedDrawable()
	{
        WeakReference<Drawable> wr = mDrawableRef;
        Drawable d = null;

        if (wr != null) d = wr.get();
        if (d == null) { d = getDrawable(); mDrawableRef = new WeakReference<>(d); }
    return d;
    }//_getCachedDrawable
}//_ValignImageSpan
