/****************************************************************************************************

BASIC! is an implementation of the Basic programming language for
Android devices.

Copyright (C) 2010 - 2015 Paul Laughton

This file is part of BASIC! for Android

    BASIC! is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    BASIC! is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with BASIC!.  If not, see <http://www.gnu.org/licenses/>.

    You may contact the author or current maintainers at http://rfobasic.freeforums.org

*************************************************************************************************/

package com.rfo.hbasic;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.util.Log;

import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;

import android.widget.Button;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import android.graphics.drawable.ColorDrawable;
import android.text.Spanned;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.app.ActionBar;

//Log.v(Select.LOGTAG, " " + Select.CLASSTAG + " String Var Value =  " + d);

/* The User Interface used to select items from a list.
 * The user is presented with a list of things from which
 * she can select a thing.
 */

public class Select extends Activity {
	private static final String LOGTAG = "Select";

	public static int Selection = 0;			// The index of the selected item
	public static boolean SelectLongClick;		// True if long click
	public static String Title;
	public static String Message;
	public static ArrayList<String> selectList;	
	public static boolean MultiMode;			// multiple selection

	private Button okButton;					// done button
	private Basic.ColoredTextAdapter mAdapter;
	private Basic.mOutputArray<String> listArray;

	private Toast mToast = null;

// 	private boolean lockReleased;			// safety valve so interpreter doesn't get hung if this
											// instance is destroyed without first releasing the LOCK
	public static void initVars(boolean is_Multi)
	{
		Selection = 0;						// default is no selection
		SelectLongClick = false;
		Message = null;
		selectList = null;
		MultiMode = is_Multi;
		if (is_Multi) Title = "Select item(s)"; else Title = "Select";
	}//_initVars

	@Override
	public void onCreate(Bundle savedInstanceState) {
//		Log.d(Select.LOGTAG, "Select.onCreate >");
		super.onCreate(savedInstanceState);
		Basic.installOnBackPressed(this);

		Intent intent = getIntent();
// 		lockReleased = false;
//		if (title==null) title = getResources().getString(R.string.select_name);

		if (selectList == null) selectList = new ArrayList<String>();	// sanity check

		listArray = new Basic.mOutputArray<String>();
		mAdapter = new Basic.ColoredTextAdapter(this, listArray, Basic.defaultTextStyle);

		setContentView(R.layout.select);
		getActionBar().hide();
		Astyle.setSystemBars(this);
		Astyle.setStyling (this, Title);

		okButton = (Button) findViewById(R.id.ok_button);
		if (!MultiMode)							// single selection
		{
			okButton.setEnabled (false);
			okButton.setVisibility(View.GONE);
		}
		else									// multi selection
		{
			TextView title = (TextView) findViewById (R.id.title);
		}//_hide edittext

		ListView lv = (ListView)findViewById(R.id.Select);
		lv.setAdapter(mAdapter);
		lv.setTextFilterEnabled(false);
		lv.setDivider(new ColorDrawable(mAdapter.getLineColor()));	// -humpty 0310
		lv.setDividerHeight(1);						// needs this or it won't work
		Astyle.styleAdapter ( mAdapter, lv);		// apply global theme

		listArray.addAll (selectList);

		// Click listeners
									// when user long-presses a filename line
		lv.setOnItemLongClickListener(new OnItemLongClickListener()
		{
			public boolean  onItemLongClick(AdapterView<?> parent, View view, int position, long id)
			{
				if (MultiMode) return true;			// ignore

				view.setBackgroundColor(mAdapter.getHighlightColor());
				setSelection(position + 1, true);	// convert to 1-based item index
				return true;
			}
		});//_setOnItemLongClickListener
									// when user short-taps a filename line
		lv.setOnItemClickListener(new OnItemClickListener()
		{
			public void onItemClick(AdapterView<?> parent, View view, int position, long id)
			{
				if (MultiMode)		// multi-select
				{
					Basic.mStyList styList = mAdapter.mList.styLists.get(position);
					styList.selected = !styList.selected;
					mAdapter.notifyDataSetChanged();
					return;
				}
									// single selection
				view.setBackgroundColor(mAdapter.getHighlightColor());
				setSelection(position + 1, false);	// convert to 1-based item index
			}
		});//_setOnItemClickListener

		okButton.setOnClickListener(new OnClickListener()	// **** Done Button ****
		{													// only for multi
			public void onClick(View v)
			{
				selectList.clear();
				for (int i=0; i<listArray.size(); i++)
				{
					Basic.mStyList styList = mAdapter.mList.styLists.get(i);
					if (styList.selected) selectList.add (listArray.get(i));
				}
				Selection = selectList.size();
				Toast_Kill();
				finish();
				return;
			}
		});//_okButton
		// End of Click Listeners
									// Display the user's toast
		if ((Message != null) && !Message.equals("")) Toast_Now (Message);
	} // onCreate

	@Override
	protected void onResume()
	{
		Run.setDIALOG = false;
		super.onResume();
	}

	@Override
	public void onBackPressed()
	{
		setSelection(0, false);				// zero indicates no selection made
	}//_onBackPressed

	public void setSelection(int item, boolean isLongClick) 
	{
//		Log.d(Select.LOGTAG, "setSelection > "+item);
// 		if (lockReleased) return;

//		synchronized (Run.LOCK) {
			Selection = item;				// 1-based index of selected item
			SelectLongClick = isLongClick;
//			Run.mWaitForLock = false;
// 			lockReleased = true;
//			Run.LOCK.notify();					// release the lock that Run is waiting for
//		}
		Toast_Kill();
		finish();
	}//_setSelection

	@Override
	public void onDestroy() {
// 		setSelection(0, false);		// if not already released, release the lock that Run is waiting for
		super.onDestroy();
	}
//-------------------------------------------------
	private void Toast_Kill ()						// kill current toast
	{
		if (mToast != null)	{ mToast.cancel(); mToast = null; }
	}//_Toast_Kill
//-------------------------------------------------
	private void Toast_Now (String msg)				// Toast immediatley
	{
		Toast_Kill();								// kill any current toast
		mToast = Basic.toaster(this, msg);
	}//_Toast_Now
//-------------------------------------------------
}//_Select
