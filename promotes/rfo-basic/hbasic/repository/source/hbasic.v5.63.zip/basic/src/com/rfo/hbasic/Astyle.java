
package com.rfo.hbasic;

import java.util.ArrayList;

import android.content.Context;
import android.util.Log;
import android.os.Build;

import android.app.Activity;
import android.app.ActionBar;

import android.view.View;
import android.view.LayoutInflater;
import android.view.Window;
import android.view.WindowManager;
import android.view.WindowInsets;
import android.view.WindowInsets.Type;
import android.view.WindowInsetsController;
import android.view.Gravity;
import android.view.ViewGroup;

import android.graphics.drawable.ColorDrawable;
import android.graphics.Typeface;

import android.text.style.ForegroundColorSpan;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.StyleSpan;
import android.text.Spanned;
import android.text.SpannableString;

import android.widget.EditText;
import android.widget.TextView;
import android.widget.ListView;
import android.widget.LinearLayout;

public class Astyle							// Activity Styling Module
{
	private static final String LOGTAG = "Astyle";

/***************** Styling for Activity Dialogs *****************************/

	public static Integer	titleFG =null;		// text color for actionbar
	public static Integer	titleBG =null;		// bg color for actionbar
	public static Integer	titleAlign = null;	// 0,1,2 left,center,right
	public static String	titleFont = null;	// font for actionbar
	public static Float		titlePad = null;	// left/right title padding
	public static Integer	windowBG =null;		// bg color for window
	public static Integer	textFG =null;		// fg color for TextInput & FileSel
	public static Integer	textBG =null;		// bg color for TextInput & FileSel
	public static Integer	voidColor =null;	// listview empty text
	public static Integer	highColor =null;	// listview highlight color
//	public static Integer buttonFG = null;		// button color for TextInput & FileSel
//	public static Integer buttonBG = null;		// button bg for TextInput & FileSel
	public static Boolean	statusBar =null;	// status bar on/off
	public static Boolean	darkStaText =null;
	public static Boolean	darkNavText =null;
	public static Float		dimDIALOG =null;
											// Execution vars
	public static String mErrorMsg="No Error";
	public static String ERR_COLOR = "color not found";
//------------------------------------------
	public static boolean setError (String errMsg)
	{
		mErrorMsg = errMsg;
		return false;
	}//_setError
//------------------------------------------
	public static void initVars()
	{
		mErrorMsg = "No Error";

		titleFG = titleBG = null;
		titleAlign = null; titleFont = null; titlePad = null;
		textFG = textBG = null;
		voidColor = highColor = null;
		windowBG = null;
		dimDIALOG = null;
		statusBar = null;
		darkStaText = darkNavText = null;
//		buttonFG = buttonBG = null;
	}//_initVars
//------------------------------------------
	public static void setActionBar (Context cx)	// set up an action bar
	{
		Activity act = (Activity) cx;
		ActionBar b = act.getActionBar();

		b.setDisplayShowCustomEnabled(true);
		b.setDisplayShowTitleEnabled(false);
		b.setDisplayShowHomeEnabled(false);
		b.setDisplayHomeAsUpEnabled(false);

		LayoutInflater li = (LayoutInflater) act.getLayoutInflater();
        View titleView = li.inflate (R.layout.title, null );

		ActionBar.LayoutParams params = new ActionBar.LayoutParams(
			ActionBar.LayoutParams.MATCH_PARENT,
			ActionBar.LayoutParams.MATCH_PARENT, 
			Gravity.CENTER
		);
		b.setCustomView(titleView,params);
	}//_setActionBar
//------------------------------------------
	public static void setSystemBars (Context cx)	// default style for aDialogs
	{
		Activity act = (Activity) cx;

		fixSysBars		(cx, false);
		setNavBar		(cx, true);

		if (statusBar !=null)	setStatusBar	(cx, statusBar);
		else					setStatusBar	(cx, true);
		if (darkStaText !=null) setDarkStaText	(cx, darkStaText);
		else					setDarkStaText	(cx, false);
		if (darkNavText !=null) setDarkNavText	(cx, darkNavText);
		else 					setDarkNavText	(cx, false);
	}//_setSystembars
//------------------------------------------
									// set statusbar to default state
	public static void setStatusBar (Context cx, boolean show)
	{
		Activity act = (Activity) cx;
		if (Build.VERSION.SDK_INT < 30)
		{
			View decor = act.getWindow().getDecorView();
			if (show)
			{														// show status bar
				int flags = decor.getSystemUiVisibility()
				&
				(
					~View.SYSTEM_UI_FLAG_FULLSCREEN				// Api 16-29
				&	~View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN		// Api 16-29
				);
				decor.setSystemUiVisibility (flags);
			}
			else
			{														// hide status bar
				int flags = decor.getSystemUiVisibility()
				|
				(
					View.SYSTEM_UI_FLAG_FULLSCREEN				// Api 16-29
				|	View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN		// Api 16-29
				);
				decor.setSystemUiVisibility (flags);
			}
		}//_< Android 11
		else	// Android 11+
		{
	        final WindowInsetsController insetsController =
					act.getWindow().getInsetsController();
			if (insetsController == null) return;				// (should not happen)
			if (show)							// show status bar
				insetsController.show(WindowInsets.Type.statusBars());
			else								// hide status bar
			{
				insetsController.hide(WindowInsets.Type.statusBars());
				insetsController.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
			}//_hide
		}//_Android 11+
	}//_setStatusBar
//------------------------------------------
									// set navbar to default state
	public static void setNavBar (Context cx, boolean show)
	{
		Activity act = (Activity) cx;
		if (Build.VERSION.SDK_INT < 30)
		{
			View decor = act.getWindow().getDecorView();
			if (show)
			{
				int flags = decor.getSystemUiVisibility()	// show
				&
				(
					~View.SYSTEM_UI_FLAG_HIDE_NAVIGATION	// Api 14
				&	~View.SYSTEM_UI_FLAG_IMMERSIVE			// Api 19
				);
				decor.setSystemUiVisibility (flags);
			}//_show
			else
			{
				int flags = decor.getSystemUiVisibility()	// hide
				|
				(
					View.SYSTEM_UI_FLAG_HIDE_NAVIGATION		// Api 14
				|	View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY	// Api 19
				);
				decor.setSystemUiVisibility (flags);
			}//_hide
		}//_< Android 11
		else	// Android 11+
		{
	        final WindowInsetsController insetsController =
					act.getWindow().getInsetsController();
			if (insetsController == null) return;				// (should not happen)

			if (show)								// show nav bars
				insetsController.show(WindowInsets.Type.navigationBars());
			else									// hide nav bar
			{
				insetsController.hide(WindowInsets.Type.navigationBars());	// hide nav bars
				insetsController.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
			}//_hide
		}//_Android 11+
	}//_setNavBar
//------------------------------------------
							// set text color for status bar API 30+
	public static void setDarkStaText (Context cx, boolean dark)
	{								// dark text = light bars.
		Activity act = (Activity) cx;
		if (Build.VERSION.SDK_INT < 23) return; // < Android 6 unsupported

		if (Build.VERSION.SDK_INT < 30) 	// Api 23 - Api 29
		{
			View decor = act.getWindow().getDecorView();
			int flags = decor.getSystemUiVisibility();
			if (dark)									// dark text
				flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;	// Api 23
			else										// light text
				flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;// Api 23
			decor.setSystemUiVisibility (flags);
			return;
		}
											// >= Api 30
        final WindowInsetsController insetsController =
				act.getWindow().getInsetsController();
		int mask =	WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS;
		int toggle=0;
		if (dark) toggle = mask;	// dark text uses mask else 0
		insetsController.setSystemBarsAppearance (toggle, mask);
	}//_setDarkStaTxt
//------------------------------------------
							// set icon color for nav bar API 30+
	public static void setDarkNavText (Context cx, boolean dark)
	{								// dark icons = light bars.
		Activity act = (Activity) cx;
		if (Build.VERSION.SDK_INT < 26) return; // < Android 8 unsupported

		if (Build.VERSION.SDK_INT < 30) 	// Api 26 - Api 29
		{
			View decor = act.getWindow().getDecorView();
			int flags = decor.getSystemUiVisibility();
			if (dark)									// dark icons
				flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;	// Api 23
			else										// light icons
				flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;// Api 23
			decor.setSystemUiVisibility (flags);
			return;
		}
											// >= Api 30
        final WindowInsetsController insetsController =
				act.getWindow().getInsetsController();
		int mask =	WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
		int toggle=0;
		if (dark) toggle = mask;	// dark icons use mask else 0
		insetsController.setSystemBarsAppearance (toggle, mask);
	}//_setDarkNavTxt
//------------------------------------------
									// fix stuff with sysbars
	public static void fixSysBars (Context cx, boolean immersive)
	{
		Activity act = (Activity) cx;

		if (immersive)
			act.getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

		if (Build.VERSION.SDK_INT > 20)	act.getActionBar().setElevation(0);

		if (Build.VERSION.SDK_INT < 21) return;
		act.getWindow().addFlags(WindowManager.LayoutParams
					.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);

		if (Build.VERSION.SDK_INT > 34) return;
		act.getWindow().setStatusBarColor(0);
		act.getWindow().setNavigationBarColor(0);

	}//_fixSysBars

/**************************** Standard Styling *******************************/
											// set title for standard mode
	public static void SetTitle (Context cx, String title)
	{
		SpannableString ss = new SpannableString(title);
		SetTitle (cx, ss, 1);				// default align left
//------
//		SetStyling (cx,	title, null,null,null,null,
//		null,null,null,null);
//------
	}//_SetTitle cx, title
//------------------------------------------
								// set and fix activity title for standard
	public static void SetTitle (Context cx, SpannableString ss, int align)
	{
		Activity act = (Activity) cx;
//		int ori = cx.getResources().getConfiguration().orientation;
//		if (ori == Configuration.ORIENTATION_LANDSCAPE)
//			ss.setSpan (new AbsoluteSizeSpan ((int)(20.0f * Basic.DensityDpiSF)),
//					0,ss.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);

		if (ss==null) ss=new SpannableString("");	// sanity check
//		int height = (int)(18.0f * Basic.DensitySpiSF);
		int height = (int)(20.0f * Basic.DensityDpiSF);

		View v = act.getActionBar().getCustomView();
		if (v==null)						// standard mode
		{
			ss.setSpan (new AbsoluteSizeSpan (height),
					0,ss.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
			act.getActionBar().setTitle(ss);
			return;
		}

		if (align==2) align = Gravity.CENTER;
		else if (align==3) align = Gravity.RIGHT|Gravity.CENTER_VERTICAL;
		else align = Gravity.LEFT|Gravity.CENTER_VERTICAL;
		LinearLayout bar = v.findViewById(R.id.titlebar);
		bar.setGravity (align);

		TextView tv = v.findViewById(R.id.title);
		tv.setText (ss);
	}//_SetTitle standard
//------------------------------------------
										// set activity subtitle for standard
	public static void SetSubtitle (Context cx, SpannableString ss)
	{
		Activity act = (Activity) cx;
//		int ori = cx.getResources().getConfiguration().orientation;
//		if (ori == Configuration.ORIENTATION_LANDSCAPE)

//		int height = (int)(16.0f * Basic.DensitySpiSF);		// (alt 18.0f dp)
		int height = (int)(18.0f * Basic.DensityDpiSF);		// (alt 16.0f sp)

		View v = act.getActionBar().getCustomView();
		if (v==null)					// standard mode
		{
			if (ss!=null) ss.setSpan (new AbsoluteSizeSpan (height),
					0,ss.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
			act.getActionBar().setSubtitle(ss);		// (can be null)
			return;
		}
		TextView tv = v.findViewById(R.id.subtitle);
		if (ss==null) 	{ tv.setText (""); tv.setHeight(0); }
		else 			{ tv.setText (ss); tv.setHeight(height); }
	}//_SetSubtitle standard
//------------------------------------------
	public static void SetStyling (			// one off standard styling
		Context cx,
		String title, Integer title_fg, Integer title_bg, String font, Integer align,
		String subtitle, Integer subtitle_fg, String subfont,
		Integer window_bg)
	{
		Activity act = (Activity) cx;
		int color;	SpannableString ss; Typeface tf=null; int style;
		int spantype = Spanned.SPAN_INCLUSIVE_EXCLUSIVE;

		color = window_bg==null?0xFF000000:window_bg;	// wdw bg
		act.getWindow().setBackgroundDrawable(new ColorDrawable(color));

		if (act.getActionBar()==null) return;	// do nothing if no actionbar

		color = title_bg==null?0x00000000:title_bg;	// backcolor
		act.getActionBar().setBackgroundDrawable(new ColorDrawable(color));

		if (title==null) title = "";			// title (must be something)
		ss = new SpannableString(title);
												// textcolor
		color = title_fg==null?0xFFDEDEDE:title_fg;		// alt 0xFFE1E1E2
		ss.setSpan(new ForegroundColorSpan(color), 0, title.length(), spantype);
		if (font!=null)							// font
		{		
			tf = getFontFace (font); style = getFontStyle (font);
			if (tf!=null)
			{
				ss.setSpan(new Basic.TF_Span(tf,true), 0, title.length(), spantype);
				ss.setSpan(new StyleSpan(style), 0, title.length(), spantype); //fake
			}
		}//_font
		if (align==null) align=1;				// default is left
		SetTitle (cx, ss, (int)align);
												// subtitle
		if (subtitle==null) ss=null;
		else
		{
			ss = new SpannableString(subtitle);
													// sub textcolor
			color = subtitle_fg==null?0xFFBDBDBD:subtitle_fg;
			ss.setSpan(new ForegroundColorSpan(color), 0, subtitle.length(), spantype);

			if (subfont!=null)						// subtitle font
			{		
				tf = getFontFace (subfont); style = getFontStyle (subfont);
				if (tf!=null)
				{
					ss.setSpan(new Basic.TF_Span(tf,true), 0, subtitle.length(), spantype);
					ss.setSpan(new StyleSpan(style), 0, subtitle.length(), spantype); // fake
				}
			}//_subfont
		}
		SetSubtitle (cx, ss);
	}//_setStyling one-off standard

/***************************** Global Styling *******************************/
												// style global dialogs
	public static void setStyling(Context cx, String title)
	{
		Activity act = (Activity) cx;

		TextView tv = (TextView) act.findViewById (R.id.title);

		int color;	SpannableString ss; Typeface tf=null; int style;
		int tbase, tpad, talign;
		int spantype = Spanned.SPAN_INCLUSIVE_EXCLUSIVE;

		color = windowBG==null?0xFF000000:windowBG;	// wdw bg
		act.getWindow().setBackgroundDrawable(new ColorDrawable(color));
													// override title padding
		if (titlePad==null) tpad = (int)Basic.getPixSize(6.0f);	// default
		else tpad = (int)Basic.getPixSize(titlePad);	// override
		setPadding ( tv, tpad, -1,tpad,-1 );			// horizontal padding

		color = titleBG==null?0x00000000:titleBG;	// backcolor
		tv.setBackgroundColor(color);

		if (title==null) title = "";		// title (must be something)
		ss = new SpannableString(title);
											// textcolor
		color = titleFG==null?0xFFDEDEDE:titleFG;		// alt 0xFFE1E1E2
		ss.setSpan(new ForegroundColorSpan(color), 0, title.length(), spantype);

		if (titleAlign != null)				// alignment
		{
			if (titleAlign==2) talign = Gravity.CENTER_HORIZONTAL;
			else if (titleAlign==3) talign = Gravity.RIGHT;
			else talign = Gravity.LEFT;
//			tv.setGravity(talign);
			LinearLayout bar = act.findViewById(R.id.titlebar);
			bar.setGravity (talign);
		}
		if (titleFont!=null)				// font
		{		
			tf = getFontFace (titleFont); style = getFontStyle (titleFont);
			if (tf!=null)
			{
				ss.setSpan(new Basic.TF_Span(tf,true), 0, title.length(), spantype);
				ss.setSpan(new StyleSpan(style), 0, title.length(), spantype); //fake
			}
		}//_titleFont

//		ss.setSpan (new AbsoluteSizeSpan ((int)(20.0f * Basic.DensityDpiSF)),
//				0,ss.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
		tv.setText (ss);

	}//_setStyling (global)
//------------------------------------------
											// style an adaptor
	public static void styleAdapter (	Basic.ColoredTextAdapter adapter,
										ListView lv)
	{
		if (textFG != null) adapter.setTextColor (textFG);
		if (textBG != null) adapter.setBackgroundColor (textBG);
		if (highColor != null) adapter.setHighlightColor (highColor);
		if (voidColor != null) lv.setBackgroundColor(voidColor);
		else lv.setBackgroundColor(adapter.getBackgroundColor()); // follow textBG
	}//_styleAdapter
//------------------------------------------
											// style an EditText
	public static void styleEditText (EditText et )
	{
		int color;
		Basic.TextStyle style = Basic.defaultTextStyle;

		color = textFG==null?style.mTextColor:textFG;		// textcolor
		et.setTextColor(color);

		color = textBG==null?style.mBackgroundColor:textBG;	// backcolor
		et.setBackgroundColor(color);
	}//_styleEditText

//-------------------------- Global Font List & Utils -----------------------
	public static ArrayList<Typeface> FontList;	// is shared with Run.FontList

	public static void clearFontList()
	{
		FontList.clear();						// clear the font list
		FontList.add(null);						// add a dummy element 0
	}//_clearFontList
//------------------------------------------
	public static boolean fontExists (int fp)	// font index exists ?
	{
		mErrorMsg = "No Error";
		if (fp > 0 && fp < FontList.size())		// exists (but could be null)
			return true;

		mErrorMsg = "Invalid font pointer "+fp;
		return false;
	}//_isValidFont
//------------------------------------------
	public static int getLastFont ()	// get last font index (non null)
	{									// or 0 => none found
		Typeface font = null;
		int fp;

		for (fp = FontList.size() - 1; fp > 0; --fp)
		{
			font = FontList.get(fp);	// get last font
			if (font != null) break;
		}
		return fp;						// (0 will be null)
	}//_getLastFont
//------------------------------------------
	public static boolean deleteFont (int fp)	// delete a font
	{
		mErrorMsg = "No Error";
		Typeface font = null;

		if (!fontExists(fp)) return false;		// error msg set

		FontList.set(fp, null);					// null the font entry
		return true;
	}//_deleteFont
//------------------------------------------
	public static int getFontStyle (String value)	// parse a style
	{
		int split = value.lastIndexOf('.');			// see if there's a style
		if (split < 0) return Typeface.NORMAL;		// no style = default
		String str = value.substring(split+1);		// get style

		if		(str.equals("b")  || str.equals("bold"))        return Typeface.BOLD;
		else if (str.equals("i")  || str.equals("italic"))      return Typeface.ITALIC;
		else if (str.equals("bi") || str.equals("bold_italic")) return Typeface.BOLD_ITALIC;
		return Typeface.NORMAL;			// anything else defaults to normal
	}//_getFontStyle
//------------------------------------------
	public static Typeface getFontFace (String value)	// parse a typeface
	{													// <num|name>.style
									// 0=>last loaded -1=>monospace
		mErrorMsg = "No Error";
		boolean isNUM = true;
		int fontnum = -1;
		String familyName = null;
		int style = getFontStyle (value);		// must be something
		Typeface tf = null;

		int split = value.lastIndexOf('.');		// if there's a style
		if (split > -1) value = value.substring(0,split); // chop it

		try	{ fontnum = Integer.parseInt(value);}	// is it a number ?
		catch (NumberFormatException ex) {isNUM = false;}
		if (isNUM)								// is a font number
		{
			if (fontnum >= FontList.size() || fontnum < -1)
			{
				mErrorMsg = "Invalid font pointer "+fontnum;
				return null;
			}
			if (fontnum > 0)					// normal font number
			{
				tf = FontList.get(fontnum);	// get specified custom font
				if (tf == null)
				{
					mErrorMsg = "Font "+fontnum+" was deleted";
					return null;
				}
			}
			else if (fontnum == 0)	// font 0 means use last loaded
			{
				for (int fp = FontList.size() - 1; (fp > 0) && (tf == null); --fp)
					tf = FontList.get(fp);		// get last font loaded and not deleted
			}									// tf is null if no loaded fonts
			else					// -1 loads mono
				tf = Typeface.create("monospace", Typeface.NORMAL);
		}//_is a font number
		else
		{
			familyName = value;
		}//_is a family
									// if no fonts loaded OR is a font family string
									// get the font for this family name
									// bad family name sets system default
		if (tf == null) tf = Typeface.create(familyName, style);
		if (tf == null) mErrorMsg = "Could not set font"; // sanity check
		return tf;
	}//_getFontFace
//------------------------------------------
	public static void setDIM (Window wdw)	// apply dimming
	{
		if (dimDIALOG !=null) wdw.setDimAmount(dimDIALOG);	// api 14
	}//_setDIM
//------------------------------------------
	public static void setPadding (TextView tv, int l, int t, int r, int b)
	{
		if (l<0) l = tv.getPaddingLeft(); if (t<0) t = tv.getPaddingTop();
		if (r<0) r = tv.getPaddingRight();if (b<0) b = tv.getPaddingBottom();
		tv.setPadding (l,t,r,b);
	}//_setPadding
//------------------------------------------
	public static void setMargins (TextView tv, int l, int t, int r, int b)
	{
		ViewGroup.MarginLayoutParams params =
			(ViewGroup.MarginLayoutParams)tv.getLayoutParams();
		if (l<0) l = params.leftMargin; if (t<0) t = params.topMargin;
		if (r<0) r = params.rightMargin;if (b<0) b = params.bottomMargin;
		params.leftMargin = l;	params.topMargin = t;
		params.rightMargin = r;	params.bottomMargin = b;
		tv.setLayoutParams(params);
	}//_setMargins
//------------------------------------------
	public static boolean set (String keyword, String value)	// update setting
	{
		float val=0.0f;	Integer cInt=null;
		setError ("No Error");
		switch (keyword)
		{
			case "title_fg" :
				if (value.equals("default")) {titleFG=null; return true;};
				cInt = GR.findColor (value);
				if (cInt == null) return setError(ERR_COLOR);
				titleFG = cInt;				return true;

			case "title_bg" :
				if (value.equals("default")) {titleBG=null; return true;};
				cInt = GR.findColor (value);
				if (cInt == null) return setError(ERR_COLOR);
				titleBG = cInt;				return true;

			case "title_pad" :
				if (value.equals("default")) {titlePad = null; return true;}
				try	{ val = Float.parseFloat(value); }		// +DP or -SP
				catch (NumberFormatException ex)
					{return setError("expected <number|default>");}
				titlePad = Basic.capHeight (val);	// cap stupid values
				return true;

			case "title_font" :
				if (value.equals("default")) {titleFont=null; return true;};
				Typeface tf	= getFontFace (value);		// check ahead
				if (tf == null)			return false;	// error msg was set
				titleFont = value;		return true;

			case "title_align" :
				if (value.equals("center")) {titleAlign=2; return true;};
				if (value.equals("right"))  {titleAlign=3; return true;};
				titleAlign = 1;		return true;

			case "window_bg" :
				if (value.equals("default")) {windowBG=null; return true;};
				cInt = GR.findColor (value);
				if (cInt == null) return setError(ERR_COLOR);
				windowBG = cInt;			return true;

			case "text_fg" :
				if (value.equals("default")) {textFG=null; return true;};
				cInt = GR.findColor (value);
				if (cInt == null) return setError(ERR_COLOR);
				textFG = cInt;				return true;

			case "text_bg" :
				if (value.equals("default")) {textBG=null; return true;};
				cInt = GR.findColor (value);
				if (cInt == null) return setError(ERR_COLOR);
				textBG = cInt;				return true;

			case "voidcolor" :
				if (value.equals("default")) {voidColor=null; return true;};
				cInt = GR.findColor (value);
				if (cInt == null) return setError(ERR_COLOR);
				voidColor = cInt;			return true;

			case "highcolor" :
				if (value.equals("default")) {highColor=null; return true;};
				cInt = GR.findColor (value);
				if (cInt == null) return setError(ERR_COLOR);
				highColor = cInt;				return true;

			case "statusbar" :
				if (value.equals("default")){statusBar=null; return true;};
				if (value.equals("on")) 	{statusBar=true; return true;};
				if (value.equals("off"))	{statusBar=false; return true;};
				return setError("expected <on|off>");

			case "statustxt" :
				if (value.equals("default")){darkStaText=null; return true;};
				if (value.equals("dark")) 	{darkStaText=true; return true;};
				if (value.equals("light"))	{darkStaText=false; return true;};
				return setError("expected <dark|light>");

			case "navbartxt" :
				if (value.equals("default")){darkNavText=null; return true;};
				if (value.equals("dark"))	{darkNavText=true; return true;};
				if (value.equals("light"))	{darkNavText=false; return true;};
				return setError("expected <dark|light>");

			case "dim" :
				if (value.equals("default")) {dimDIALOG = null; return true;}
													// get dim percent
				try	{	val = Float.parseFloat(value);
						if ( (val >= 0.0) && (val <= 100.0) )
						{	dimDIALOG = (float) (val / 100.0f);	// range 0..1
							return true;
						}
				}//_try
				catch (NumberFormatException ex) {}
				return setError("expected <0..100|default>");
		}//_switch
		return setError("Keyword not found");
	}//_set
}//_Astyle
