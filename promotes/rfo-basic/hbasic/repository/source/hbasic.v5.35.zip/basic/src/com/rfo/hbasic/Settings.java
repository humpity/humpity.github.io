/****************************************************************************************************

BASIC! is an implementation of the Basic programming language for
Android devices.

Copyright (C) 2010 - 2015 Paul Laughton

This file is part of BASIC! for Android

    BASIC! is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    BASIC! is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with BASIC!.  If not, see <http://www.gnu.org/licenses/>.

    You may contact the author or current maintainers at http://rfobasic.freeforums.org

*************************************************************************************************/

package com.rfo.hbasic;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.StringTokenizer;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;

import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;

import android.content.pm.ActivityInfo;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;

import android.support.preference.EditTextPreference;
import android.support.preference.ListPreference;
import android.support.preference.CheckBoxPreference;
import android.support.preference.Preference;
import android.support.preference.PreferenceActivity;
import android.support.preference.PreferenceManager;
import android.support.preference.PreferenceScreen;

import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;

import android.provider.Settings.System;

// Called from Editor when user presses Menu->Settings

public class Settings extends PreferenceActivity implements
        OnSharedPreferenceChangeListener
{
	private static final String LOGTAG = "Settings";

	private static float  Small_font = 12;
	private static float  Medium_font = 18;
	private static float  Large_font = 24;
	private static int  Pref_screenID = 0;	// debug

	public static boolean changeBaseDrive = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {	// The method sets the initial displayed
		super.onCreate(savedInstanceState);					// checked state from the xml file

		addPreferencesFromResource(R.xml.settings);			// it does not affect the above variables
		setBaseDriveList();
		for (String key : PreferenceManager.getDefaultSharedPreferences(this)
							.getAll().keySet())
		{
			Preference pref = findPreference(key);
			if (pref instanceof EditTextPreference)
			{
				EditTextPreference etp = (EditTextPreference) pref;
				pref.setSummary(etp.getText());
			}
		}
	}

	@Override
	protected void onPause()
	{
		super.onPause();
		SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        prefs.unregisterOnSharedPreferenceChangeListener( this );
	}

    @Override
    public void onResume()
    {
        super.onResume();
		SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        prefs.registerOnSharedPreferenceChangeListener( this );
    }

    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences,
            String key)
	{
        Preference pref = findPreference(key);
        if (pref instanceof EditTextPreference)
		{
            EditTextPreference etp = (EditTextPreference) pref;
            pref.setSummary(etp.getText());
        }
											// update the defaultTextStyle.
		if (Basic.defaultTextStyle != null) Basic.defaultTextStyle.refresh();
    }//_onSharedPreferenceChanged

	@Override
	public boolean onKeyUp(int keyCode, KeyEvent event) {						// If back key pressed
	    if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
	       finish();
	       return false;
	    }
	    return super.onKeyUp(keyCode, event);
	}

	@Override
	public boolean onPreferenceTreeClick (PreferenceScreen preferenceScreen, Preference preference) {
		String title = preference.getTitle().toString();
		changeBaseDrive |= title.equals("Base Drive");
		return false;
	}

	public void setBaseDriveList()
	{
		ArrayList <String> list = new ArrayList <String>();
		String entries[];
							// -humpty 0300 get scoped storage dirs (API 19+)
		entries = getExtStorageDirs (getApplicationContext());
		list.addAll ( Arrays.asList(entries) );

		if (Build.VERSION.SDK_INT < 30)	// -humpty 0525 support legacy devices
		{								// deprecated since api29
//			entries = getStorageDirectories(defaultPath);	// legacy scan
			String defaultPath = Environment.getExternalStorageDirectory().getPath();
			list.add(defaultPath);
		}
		entries = list.toArray ( new String[list.size()] );
								// if no paths exist, at least try something
		if ( entries.length < 1 ) entries = new String[]{"/sdcard"};

		String values[] = entries.clone();
		final String sdcard = "/sdcard";
		String sdcardPath;
		try { sdcardPath = new File(sdcard).getCanonicalPath();	}
		catch (IOException e) { sdcardPath = ""; }
		for (int i=0; i<entries.length; i++)
			if (entries[i].equals(sdcardPath)) entries[i] = sdcard;

		PreferenceManager PM = getPreferenceManager();
		ListPreference baseDrivePref = (ListPreference) PM.findPreference("base_drive_pref");
		baseDrivePref.setEntries(entries);
		baseDrivePref.setEntryValues(values);

		String value = getBaseDrive(getApplicationContext());
		if (value.equals("none")) {
			baseDrivePref.setValueIndex(0);
		}
	}
//-------------------------------------------------
	private static String[] getExtStorageDirs(Context appContext)	// -humpty 0300, 0306
	{
	 File[] fdirs = appContext.getExternalFilesDirs(null);	// api 19+
	 int size = fdirs.length;

	 ArrayList<String> valid = new ArrayList<String>();	// capture only valid entries

	 for (int i=0;i<size;i++)
	 {
		if (fdirs[i] != null)							// (null means the mount failed)
			valid.add(getParentPath (fdirs[i]));		// add the parent path
	 }

	 String[] sdirs;
//	 if ( valid.size() < 1 ) sdirs = new String[]{"/sdcard"}; // no paths exist
	 sdirs = valid.toArray(new String[valid.size()]);

	 return sdirs;
	}//_getExtStorageDirs
//-----------------------------------------
	public static String getParentPath (File f)		// get parent path, return root on failure
	{
	 String s = f.getParent();

	 if (s == null) return ("/");			// no parent, just return root (should never happen)
	 return (s);							// else return the parent path without slash
	}//_getParentPath
//-----------------------------------------

	public static void setDefaultValues(Context context, boolean force)
	{
		if (force) {
			SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(context);
			pref.edit().clear().commit();
		}
		PreferenceManager.setDefaultValues(context, R.xml.settings, force);
	}

	public static String getBaseDrive(Context context) {
		String baseDrive = PreferenceManager.getDefaultSharedPreferences(context)
				.getString("base_drive_pref", "none");
		return baseDrive;
	}

	public static float getFont(Context context) {

		String font = PreferenceManager.getDefaultSharedPreferences(context)
				.getString("font_pref", "Medium");

		if (font.equals("Small")) return Small_font;
		if (font.equals("Medium")) return Medium_font;
		return Large_font;
	}

	public static Typeface getConsoleTypeface(Context context) {
		String font = PreferenceManager.getDefaultSharedPreferences(context)
				.getString("csf_pref", "MS");

		if (font.equals("MS")) return Typeface.MONOSPACE;
		if (font.equals("SS")) return Typeface.SANS_SERIF;
		if (font.equals("S")) return Typeface.SERIF;
		return Typeface.MONOSPACE;
	}

	public static boolean getConsoleMenu(Context context) {
		return PreferenceManager.getDefaultSharedPreferences(context)
				.getBoolean("console_menu", true);
	}

	public static boolean getLinedConsole(Context context) {
		return PreferenceManager.getDefaultSharedPreferences(context)
				.getBoolean("lined_console", true);
	}

	public static boolean getLinedEditor(Context context) {
		return PreferenceManager.getDefaultSharedPreferences(context)
				.getBoolean("lined_editor", true);
	}

	@TargetApi(Build.VERSION_CODES.HONEYCOMB)
	public static boolean menuItemsToActionBar(Context context, Menu menu) {
		if (menu == null) return false;				// no action needed
		if (Build.VERSION.SDK_INT < 11) return false;

		int[][] idMap = {
			{ R.string.pref_MAB_run_key,    R.id.run    },
			{ R.string.pref_MAB_load_key,   R.id.load   },
			{ R.string.pref_MAB_save_key,   R.id.save   },
			{ R.string.pref_MAB_clear_key,  R.id.clear  },
			{ R.string.pref_MAB_search_key, R.id.search },
			{ R.string.pref_MAB_exit_key,   R.id.exit   },
		};
		SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
		Resources res = context.getResources();
		for (int[] ids : idMap) {
			MenuItem item = menu.findItem(ids[1]);
			String key = res.getString(ids[0]);
			int action = prefs.getBoolean(key, false)
				? MenuItem.SHOW_AS_ACTION_IF_ROOM : MenuItem.SHOW_AS_ACTION_NEVER;
			item.setShowAsAction(action);
		}
		return true;
	}

	public static boolean getEditorLineWrap(Context context) {
		return PreferenceManager.getDefaultSharedPreferences(context)
				.getBoolean("wrap_editor", false);
	}

	public static boolean getAutoIndent(Context context) {
		return PreferenceManager.getDefaultSharedPreferences(context)
				.getBoolean("autoindent", false);
	}

	public static boolean getGraphicAcceleration(Context context){
		return PreferenceManager.getDefaultSharedPreferences(context)
				.getBoolean("gr_accel", false);
	}

	public static void setGraphicAcceleration (Context context, boolean toggle)
	{											// set graphics Acceleration
		SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(context);

		SharedPreferences.Editor prefEdit = pref.edit();
		Resources res = context.getResources();
		
		prefEdit.putBoolean("gr_accel", toggle);
		prefEdit.commit();
	}//_setGraphicAcceleration

	public static String getEmptyConsoleColor(Context context) {
		return PreferenceManager.getDefaultSharedPreferences(context)
				.getString("empty_color_pref", "background");
	}

	public static String getColorScheme(Context context) {
		return PreferenceManager.getDefaultSharedPreferences(context)
				.getString("es_pref", "BW");
	}

	public static boolean useCustomColors(Context context) {
		SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(context);
		boolean useCustom = pref.getBoolean("custom_colors_pref", false);
		if (!useCustom) {
			SharedPreferences.Editor prefEdit = pref.edit();
			Resources res = context.getResources();
			prefEdit.putString("tc_pref", String.format("%#06x", res.getInteger(R.integer.color2)));
			prefEdit.putString("bc_pref", String.format("%#06x", res.getInteger(R.integer.color3)));
			prefEdit.putString("lc_pref", String.format("%#06x", res.getInteger(R.integer.color1)));
			prefEdit.putString("hc_pref", String.format("%#06x", res.getInteger(R.integer.color4)));
			prefEdit.commit();
		}
		return useCustom;
	}

	public static String[] getCustomColors(Context context) {
		SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(context);
		String[] colors = new String[4];				// use same mapping as "WBL"
		colors[0] = pref.getString("lc_pref", "");		// color1
		colors[1] = pref.getString("tc_pref", "");		// color2
		colors[2] = pref.getString("bc_pref", "");		// color3
		colors[3] = pref.getString("hc_pref", "");		// color4 (highlight)
		return colors;
	}

	public static int getOrientMode(Context context)
	{
		String SO = PreferenceManager.getDefaultSharedPreferences(context)
				.getString("so_pref", "0");			// internal 0..4
		return Integer.parseInt(SO) -1 ;			// output  -1..3 mode
	}//_getOrientMode

	public static int getOrientCode(int SO)	// input mode -1..3, output code
	{
		int RV = ActivityInfo.SCREEN_ORIENTATION_SENSOR;	// -1 => default 4
		if      (SO == 0) RV = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE;	// 0
		else if (SO == 1) RV = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;	// 1
		else if (SO == 2) RV = ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE; //8;
		else if (SO == 3) RV = ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT; //9
		return RV;
	}//_getOrientCode

	public static int getScreenOrientation(Context context) {
		return getOrientCode( getOrientMode(context) );
	}//_getScreenOrientation

	public static int getOrientLock ()				// return 0 => locked
	{												// 		  1 => unlocked
													//		 -1 => undefined
		Context cx = Basic.mContextMgr.getContext(ContextManager.ACTIVITY_APP);
		return android.provider.Settings.System.getInt(
				cx.getContentResolver(),
				android.provider.Settings.System.ACCELEROMETER_ROTATION,
				-1);
	}//_getOrientLock

//------------------------------------------

	public static int getFtpPort(Context context)			// -humpty get ftp port
	{														// -1 => invalid port
		String s = PreferenceManager.getDefaultSharedPreferences(context)
				.getString("ftp_port", "2345");

		int ftpPort = -1;									// assume failed
		try { ftpPort=Integer.parseInt(s); }
		catch (Exception e) {ftpPort = -1;}					// probably wrong format

		if (ftpPort < 1025 || ftpPort>65535) ftpPort = -1;	// port range check

		return ftpPort;
	}//_getFtpPort

	public static String getFtpUsername(Context context)
	{
		String s = PreferenceManager.getDefaultSharedPreferences(context)
				.getString("ftp_username", "");
		return s;
	}//_getFtpUsername

	public static String getFtpPassword(Context context)
	{														// -1 => invalid port
		String s = PreferenceManager.getDefaultSharedPreferences(context)
				.getString("ftp_password", "");
		return s;
	}//_getFtpPassword
//------------------------------------------
}//_class Settings
