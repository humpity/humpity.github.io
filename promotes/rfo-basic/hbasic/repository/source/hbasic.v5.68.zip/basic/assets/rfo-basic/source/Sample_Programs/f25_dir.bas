!!
This program can be used to
explore the file system on an
Android device. 

Any filename with a (d) after
it is a directory. Tap on that
entry to open that directory.

Tap on the top entry, "..", to
move up one directory level.

Press the BACK key to exit.

This program will list all the
way up to two levels above the
data directory called the
base drive.

The initial directory shown is
file.root, i.e
"<base-drive>/rfo-basic/data/"
!!

! Lists a directory. Gets and
! returns the user's selection

FILE.ROOT base$
cut=ENDS_WITH("rfo-basic/data",base$)
base$ = left$(base$,cut-1)
path$ = ""

loop:

! Get the listing from
! the path directory
! and sort it

ARRAY.DELETE d1$[]
FILE.DIR path$, d1$[]
ARRAY.LENGTH length, d1$[]

! Copy the file list
! adding the top ",,"
! entry

ARRAY.DELETE d2$[]
DIM d2$[length+1]
d2$[1] = ".."
FOR i = 1 TO length
 d2$[i + 1] = d1$[i]
NEXT i

! Present the list
! and get the user's
! choice

SELECT s, d2$[], ""
IF s = 0 THEN END

! If top entry, back "..",
! not selected then append
! the selected directory
! name to the path

IF s>1
 n = IS_IN("(d)", d2$[s])
 IF n <> 0 THEN
	dname$ = LEFT$(d2$[s],n-1)
	path$=path$+dname$+"/"
 ENDIF
ENDIF
IF s>1 THEN GOTO loop

! See if we want to Go back one level
				
IF path$="../../" THEN popup "Not Allowed !"	% not allowed outside scoped storage
IF path$="../" THEN path$ = "../../"	% allowed to go back two from base
IF path$="" THEN path$="../"		% allowed to go back one from base
IF path$="../" | path$="../../" THEN GOTO loop

! Otherwise there is a longer path to cut back one level
! split the path by the "/" chars

ARRAY.DELETE p$[]
SPLIT p$[], path$, "/"
ARRAY.LENGTH length, p$[]

! delete the
! last directory from
! the path

! If only one entry
! then path is back
! to the base path

! Reconstruct path without
! the last directory

path$ = ""
FOR i = 1 TO length - 1
 path$ = path$ + p$[i] + "/"
NEXT i

GOTO loop
