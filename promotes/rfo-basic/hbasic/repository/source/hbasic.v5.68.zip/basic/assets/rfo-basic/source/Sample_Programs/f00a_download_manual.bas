
? "This is a link to the Original Basic! Manual."
?
? "The original 01.91 manual is in PDF format."
?
Dialog.Message	"Open Link ?", "- Original Basic! Manual v0191.pdf -\n\n"+~
		"Your Browser should be able to Download it.\n"+~
		"(2.8Mb)\n\n"+~
		"choose your browser after tapping Yes."~
		,choice ,"No", "Yes"

if choice <> 2 then print "(cancelled).": end

PRINT "Opening the manual in your Browser.."
BROWSE "http://laughton.com/basic/programs/apks/De_Re_BASIC!-v0191.pdf"
END
