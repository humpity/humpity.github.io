! This program is designed to demonstrate
! the gr.touch and gr.bitmap, commands in
! the context of a graphics application.
!
! Run the program and follow the instructions.
! modified from original f11_graphics_touch.bas
! v2.0 -humpty Apr 2024
!       - wait a bit for 2nd finger

PRINT "Touch the screen. A small star will appear."
PRINT "Pressing Volume UP makes the next star bigger."
PRINT "Pressing Volume DOWN makes the next star smaller"
PRINT "A Two-Finger touch will toggle between a star"
PRINT "or a Galaxy"
PRINT
PRINT "When done, Press the BACK key to close the graphics screen."
PRINT "Press the BACK key again to exit the text console."
PRINT
PRINT "When ready, Tap the screen."

! Wait for the screen to be tapped
Tapped = 0
DO
UNTIL Tapped
GOTO Start

onConsoleTouch:
Tapped = 1
cls
PRINT "Press the BACK key again to exit the text console."
ConsoleTouch.Resume


Start:
volkeys.off     % disable passing vol key events to android
star = 1        % 1==star, 0==galaxy
r = 1           % Set the start radius to 1

! open the Graphics Screen

GR.OPEN 255, 0,0,0,0,1      % A,R,G,B,barOFF,portrait
PAUSE 1000          % wait a bit
GR.SCREEN sw,sh

! Load the bitmap object and set mode to dots

GR.BITMAP.LOAD BM_ptr, "Galaxy.png"

! Set the color of the dot and Write text

GR.COLOR 255,255,255,255,1
th = sh/30
GR.TEXT.SIZE th
msg$="Star"
GR.TEXT.DRAW otext, 10 , th*1.3, msg$
GR.TEXT.DRAW otext2, sw/2 , th*1.3, "size: "+int$(r)
GR.RENDER

! Run an infinite loop testing for a touch
! key presses are detected with onkeypress

DO
 GR.TOUCH flag, x , y       % test for single touch
 IF flag THEN
    pause 30                % wait a bit for finger 2
    GR.TOUCH2 flag, x2 , y2 % could be a 2 finger touch
    IF flag THEN
        star = !star
        if star then
            msg$="Star"
            GR.SHOW otext2
        else
            msg$="Galaxy"
            GR.HIDE otext2
        endif
        GR.MODIFY otext,"text", msg$
        GR.RENDER
    ELSE            % it's just a 1 finger touch
        IF star THEN 
            GR.CIRCLE n, x, y, r 
        ELSE 
            GR.BITMAP.DRAW n, BM_ptr , x, y
        ENDIF
        GR.RENDER
        flag=1
    ENDIF
 ENDIF
 IF flag then
     DO
      GR.TOUCH flag, x, y       % wait until finger/s off
     UNTIL !flag
 ENDIF
UNTIL 0
END
onkeypress:
    inkey$ key$
    IF key$ = "key 24" THEN r = r + 1
    IF key$ = "key 25" THEN r = r - 1
    if r<1 then r=1
    GR.MODIFY otext2,"text", "size: "+int$(r)
    GR.RENDER
key.resume
END
! When you exit the graphic screen
! with the back key, you will get
! back to the text console.
! Hit the Back key one more time to get
! back to the Editor.
END
