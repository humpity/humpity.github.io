! GPS test 
! modified from original f15_gps.bas
! v2.1 -humpty Aug 2023

? "GPS test"
fn.def seeSat (b)
	bundle.get b,"infix",i
	bundle.get b,"prn",p
	bundle.get b,"elevation",e
	bundle.get b,"azimuth",a
	bundle.get b,"snr",s
	if i then i$="*" else i$=" "
	p$=using$ ("", "%3d", int(p))
	e$=using$ ("", "%5.1f", e)
	a$=using$ ("", "%5.1f", a)
	s$=using$ ("", "%.2f", s)
	? i$+"|"+p$+"|"+e$+"|"+a$+"|"+s$
fn.end
MaxPoll = 10

GPS.OPEN OK,0,0,0,0	% status,time,dist,useNET,useLAST
pause 1000

if !OK then ?"Could not open GPS" : goto Quit

for poll = 1 to MaxPoll
	gosub scan
	cls
	gosub output
	?"Poll "+int$(poll)+"/"+int$(MaxPoll)+" > ";
	for d=5 to 1 step -1 : ?int$(d); :pause 1000 :next
	print
next

Goto Finish

Scan:
	Gps.location gtime, gprov$, gcount, gacc, glat, ~
                glong, galt, gbear, gspeed
	gps.status stat$,infix,inview,satlist
RETURN

Output:
	? "GPS test      status: ";stat$
    ? "inView:";int$(inview),"inFix:";int$(infix)
	? "Provider  : ";gprov$
	? "Time      : ";
    if gtime then ? USING$(, "%tT", int(gtime)) else ?
	? "Latitude  : ";using$("","%g°",glat)
    ? "Longitude : ";using$("","%g°",glong)
	? "Accuracy  : ";using$("","%.1f m",gacc)
	? "Altitude  : ";using$("","%.1f m",galt)
	? "Bearing   : ";using$("","%g°",gbear)
	? "Speed     : ";using$("","%.1f m/s",gspeed)
	? "Sats used : ";gcount
    list.size satList,z
    ? "list size : ";int$(z)
	? "(backkey to quit)"
RETURN

OnBackKey:
Finish:
	print
	if satlist<1 then ? "No Sat list":goto Quit
	list.size satlist,z
	if z<1 then ? "Empty Sat list":goto Quit
                        % dump satellite list
    ? "    B u prn   elv  azi   snr"
	for i=1 to z
		list.get satlist,i,b
		i$=using$ ("", "%2d", int(i))
		b$=using$ ("", "%2d", int(b))
		? i$+":"+b$+":";
		seeSat (b)
	next
    ? "Done"
Quit:
    gps.close
END
