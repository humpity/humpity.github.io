!!
 Apply gravity to a Moving ball.
 For hBasic v5.04+

 This program demonstrates
 acceleration (gravity) using
 GR.TWEEN.PUSH.
 And angle reflection using 
 GR.ADD.

 - v2.00 -humpty: Sep-2024
   Uses hBasic's built-in
   motion & tweens.
!!
GR.OPEN "black", 1,1 % color,bar,portrait
gr.color "white"
gr.screen sw,sh
m = min(sw,sh)
radius = m/10
startx = radius : starty = sh/2

again:          % app loop
damp = 0.9          % damping 1=none, 0=max
pixPerM = m         % pixels per meter
acc = 9.8*pixPerM   % gravity

GR.TWEEN.CLR        % clear the tweens list
                    % create circle
if oC=0 then gr.circle oc,startx,starty,radius
gr.modify oC, "x",startx, "y",starty
gr.modify oC, "dir",0   % go right with
                        % initial speed
gr.modify oC, "speed",m*1.3

gosub release   % ask user to tap
!*** apply gravity forever ***
GR.TWEEN.PUSH oC,90,acc,-1

gr.render
GR.MOTION.MARK  % 1st timing
while 1         % motion loop
 gr.render
 GR.MOTION      % apply motion & tweens
                % check bounce
 gr.get.value oC,"speed",speed~
                ,"dir",angle~
                ,"y",y
 if (y+radius>sh) then % at bottom, bounce up
    speed *= damp      % lose speed on bounce
    if speed < radius then w_r.break % don't bounce forever
    gr.modify oC,"speed",speed
!*** bounce off floor ***
    GR.ADD Oc,"dir",-2*angle
    gr.modify oC,"y",sh-radius % start from bottom
 endif
                % check walls 
 gr.get.value oC,"x",x
 if x+radius>sw | x<radius
    gr.get.value oC,"dir",angle
! *** bounce off wall ***
    GR.ADD oC,"dir",180-2*angle
    if x<radius then x=radius   % keep inside
    if x>sw-radius then x=sw-radius
    gr.modify oC, "x",x
 endif 
repeat

gr.render : pause 1000
goto again      % loop forever
END

onbackkey:
 GR.CLOSE
end
release:
    if oT=0     % create text
     gr.text.size radius/1.5
     gr.text.draw oT,0,0,"Tap to Drop"
    endif
    gr.modify ot, "x",sw/2, "y",starty-radius*2
    GR.TWEEN.ADD oT,"x",sw,500 % move right
    gr.render % show it & wait for touch
    do : gr.touch tch,x,y : until tch
    do : gr.touch tch,x,y : until !tch
return
end
