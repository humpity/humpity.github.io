!!
 This example program demonstrates the
 use of the Pseudo "Orientation" sensor
 to make a simple Compass.

 Device must have both Acceleration 
 and Magnetic Field hardware sensors.

 - v2.1 - Spike:  Dec 2024
          smooth & faster speed
          needle & cosmetics
 - v2.0 - humpty: Jun 2023
          modified from f14_compass.bas
          uses sensor type -3 (not 3)
!!
!----------------------------------------
! To read out true North rather than magnetic North,
! change the next line to be your local magnetic
! declination, positive for East, negative for West

declination = 0

! Open the graphics screen with white background

GR.OPEN 255,255,255,255, 0,1    % A,R,G,B,barOFF,landscape
PAUSE 1000
GR.SCREEN w, h

cx = w/2
cy = h/2
th = h/24                   % text height

if w<h then r=w/2 else r=h/2
r *= 0.7                    % radius

! Initialize the text parameters

GR.COLOR 255,0,0,0,1      % text color
GR.TEXT.SIZE th*0.7
GR.TEXT.ALIGN 2

! Draw the parameter value displays

z = TORADIANS(45)
x = COS(z) * r + cx
y = SIN(z) * r + cy
GR.TEXT.DRAW ta, x, y,"A000"    % Azimuth
z = TORADIANS(135)
x = COS(z) * r + cx
y = SIN(z) * r + cy
GR.TEXT.DRAW tp, x, y,"P000"    % Pitch
z = TORADIANS(225)
x = COS(z) * r + cx
y = SIN(z) * r + cy
GR.TEXT.DRAW tr, x, y, "R000"   % Roll

! Draw the compass labels

GR.COLOR 255,0,0,255,1   % labels color
GR.TEXT.SIZE th
GR.TEXT.DRAW k, cx, cy - r - th/2, "N"
GR.TEXT.DRAW k, cx + r + th, cy, "E"
GR.TEXT.DRAW k, cx - r - th ,cy, "W"
GR.TEXT.DRAW k, cx, cy + r + th*1.5, "S"
GR.COLOR 255,0,0,255,0   % don't color in the circle!
GR.SET.STROKE 4
GR.CIRCLE    k, cx, cy, r
GR.RENDER   % Show what we have drawn so far

GR.COLOR 255,255,0,0,1   % red for compass needle
GR.ROTATE.START 0, cx, cy, compassobject
GR.LINE ignored, cx,   cy, cx, cy-r
GR.LINE ignored, cx-4, cy, cx, cy-r
GR.LINE ignored, cx+4, cy, cx, cy-r
GR.COLOR 255,192,192,192
GR.LINE ignored, cx,   cy, cx, cy+r
GR.LINE ignored, cx-4, cy, cx, cy+r
GR.LINE ignored, cx+4, cy, cx, cy+r
GR.ROTATE.END

! Use hBasic's Orientation pseudo-sensor -3
! It uses sensors 1 (acceleration) and 2 (magnetic)
! and they must be open
SENSORS.OPEN 1:1,2:1

! In an infinite loop, read the sensor
! and show the compass line for Azimuth.
! az0 is raw Azimuth, az is smoothed Azimuth,
! 90% of old reading + 10% of new raw reading,
! but must range-check it so it doesn't walk from
! 359 deg to 1 deg the long way.
DO
 SENSORS.READ -3, az0, pitch, roll
 IF az0 - az < -180 THEN az0 += 360
 IF az0 - az >  180 THEN az0 -= 360
! smooth & add in the declination
 az = 0.9*az + 0.1*az0 + declination  

! Range-check Azimuth again, in bounds 0..360
! But it's anti-clockwise; we compute clockwise N
 if az > 360 then az -= 360
 if az < 0   then az += 360
 N = 360 - az

! Use GR.MODIFY on the displayed values
! and the rotation of the compass needle
 az$ = FORMAT$("A%%%", N)
 pitch$ = FORMAT$("P%%%", pitch)
 roll$ = FORMAT$("R%%%", roll)
 GR.MODIFY ta, "text", az$
 GR.MODIFY tp, "text", pitch$
 GR.MODIFY tr, "text", roll$
 GR.MODIFY compassobject, "angle", N
 GR.RENDER
 PAUSE 10
UNTIL 0  % Loop forever
END
