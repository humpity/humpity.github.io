!!
 Sliding menu demo.
 For hBasic v5.10+

  This program demonstrates
  a sliding menu using
  goal tweens and a delay
  to animate a star at the 
  corner.

 - v1.01 -humpty: Nov-2024
   Uses hBasic's built-in 
   motion & tweens.
!!
! directives must be at start.
@@hide_actionbar    % prevents flash of console title
!-------------------------------
fn.def tMenu_make (h$, t$[])    % (header, titles)
                % return a tMenu as a group object
    array.length nitems,t$[]    % #items
    list.create n, olist        % list of objects
    gr.text.width mw,h$
    j=1
    for i= 1 to nitems          % get max text width
        gr.text.width w,t$[i]
        if w>mw then mw=w:j=i
    next i
    gr.text.height th :gr.set.stroke 0 :gr.text.align 2
    pad = th/2.5            % padding
    bw = ceil(mw+2*pad)     % button width
    bh = ceil((th*1.1))     % button height
    l=pad : t=pad : r=l+bw : b=t+bh % header
    bgw = bw+2*pad              % bg width
    bgh = b+bh*2*nitems+3*pad   % bg height
                            % background obj 1
    gr.color "tan",1
    gr.rect o, 0, 0, bgw, bgh   % (exclusive)
    list.add olist, o
                            % sprite obj2
    gr.color "black",1          % opaque
    gr.anim.load a1,"s-anim.png",32,32,16 % animation
    gr.anim.scaf a1,3           % enlarge animation
    gr.bitmap.create b1,32,32   % empty bitmap
    gr.sprite.draw oS,bgw-48,-55,b1,a1 % sprite
    gr.modify oS,"arate",0,"aloop",0   % no run, no loop
    list.add olist, oS
                            % header objs 3,4
    gr.color "wheat",1
    gr.rect oR, l, t, r, b+pad  % (exclusive)
    gr.color "black",1
    gr.text.draw oT, l+bw/2, t+bh, h$
    list.add olist, oR,oT
                            % button objs 5..n
    gr.color "wood",1 : gr.paint.get pR % rect color
    gr.color "white",1                  % blink rect
    gr.color "azure",1: gr.paint.get pT % text color
    gr.color "black",1                  % blink text
    for i= 1 to nitems
        gr.rect o, l, t+bh*2*i, r ,b+pad+bh*2*i
        gr.modify o,"paint",pR
        list.add olist, o       % rect obj
        gr.text.draw o, l+bw/2, t+bh*2*i+bh, t$[i]
        gr.modify o,"paint",pT
        list.add olist, o       % text obj
    next i

    gr.group.list g_all, olist  % group of objects
    gr.move g_all,-bgw-10,0     % move it offscreen
    fn.rtn g_all
fn.end
!-------------------------------
fn.def tMenu_exec (im,x2,y2)    % execute tMenu at x2,y2

    gr.get.value im,"list",gl   % get the group list
    list.size gl,last
    list.get gl,1,oB            % 1st object is background
    list.get gl,2,oS            % 2nd object is star
    gr.get.value oB, "left",l,"right",r,"x",x1,"y",y1
    w = r-l                     % width
    gr.move im,-x1-w-10, -y1+y2   % move left offscreen
    gr.render
    GR.TWEEN.GOAL im,"x",w+10+x2,300    % slide right
    gr.modify oS,"aframe",0 % reset frame
    GR.TWEEN.GOAL oS,"aframe",16,1000,300 % delayed animation

    go_tweens(1)            % do tweens, get touch
    get_touch()             % if not touched, wait for one
    gr.touch tch,x,y,1      % get last touch (& unscale)
    GR.TWEEN.CLR : gr.modify oS,"aframe",0 % clear effects

    sel=0
    for i=5 to last         % detect button touch
        list.get gl,i,o
        gr.get.type o,t$
        if t$<>"rect" then f_n.continue
        if !gr_contains (o,x,y) then f_n.continue

        GR.ADD o,"paint",1      % blink the button
        GR.ADD o+1,"paint",1    % blink the text
        gr.render               % unblink with delay
        GR.TWEEN.GOAL o,"paint",-1,1,100
        GR.TWEEN.GOAL o+1,"paint",-1,1,100
        sel=(i-5)/2+1           % get selection
        f_n.break
    next i
                    % slide left for exit
    GR.TWEEN.GOAL im,"x",-w-10-x2,300,300*(sel<>0)
    go_tweens(0)    % do tweens, ignore touches
    fn.rtn sel      % return selection
fn.end
!-------------------------------
fn.def get_touch()      % wait for a touch
    do:gr.touch tch,x,y:pause 10:until tch
    do:gr.touch tch,x,y:pause 10:until !tch
fn.end

fn.def go_tweens (intr) % do tweens (touch interrupt?)
    gr.motion.mark      % 1st timing
    do
        gr.motion
        gr.render
        gr.touch tch,x,y
        if tch & intr then d_u.break
    until !gr_tweens()  % no more tweens
    fn.rtn
fn.end
!===============================
! Main Program
dW=720 : dH=1280    % dev screen size
gr.open "cream",,1  % color,bar,portrait
gr.screen rW,rH     % real screen size
sW=rW/dW            % scale to width
gr.scale sW,sW
array.load item$[], "item 1","item 2","item 3", "Quit"

gr.text.size 40     % this determines menu size
gr.text.align 2
gr.color "black",1
gr.text.draw oT1,dw/2,dH/6,"Tap screen for Menu"
gr.text.draw oT2,dw/2,dH/6+80,""
                    % create menu
im = tMenu_make ("Please Select",item$[])
gr.render
do
 get_touch()    % wait for a touch

 sl= tMenu_exec (im,100,dH/3) % invoke menu @x,y

 gr.modify oT2,"text","Selected "+int$(sl)
 gr.render
until sl=4      % until quit
pause 500
end
