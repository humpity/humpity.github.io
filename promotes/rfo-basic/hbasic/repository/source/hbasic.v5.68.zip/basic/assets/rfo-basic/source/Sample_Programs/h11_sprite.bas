!!
 This program demonstrates
 movement and sprite animation
 for hBasic v5.00+

 - v1.01 -Jan-2025
   - scale to width
 - v1.00 -humpty: May-2024
   Uses hBasic's built-in motion
   Uses hBasic's sprite animation.

 Two sprites share the same
 animation.
 When the screen is touched,
 they both animate. The top
 sprite also moves. When
 the screen is not touched,
 one shows it's standing bitmap,
 the other one just freezes.
!!

gWID = 600 : gHGT = 1200   % development size

GR.OPEN "white", 1,1 % color,bar,portrait
gr.screen rWID,rHGT  % real WxH
scale=rWID/gWID  % scale to width
gr.scale scale,scale % scale to device

! Load a standing bitmap
! scale factor 3x, no smoothing
GR.BITMAP.LOAD sb, "h-stand.png"
GR.BITMAP.SCAF sb,3

! Create left & right animations 
! from a sprite sheet.
! Load the 2nd one from offset 16
! gr.anim.load ani,file,w,h,nFrames,skip

GR.ANIM.LOAD al,"h-anim.png",32,33,16
GR.ANIM.LOAD ar,"h-anim.png",32,33,16,16
GR.ANIM.SCAF al,3  % scale factor 3x
GR.ANIM.SCAF ar,3  % default=no smoothing

! Create 2 sprites
GR.SPRITE.DRAW s1,100,120,sb % x,y,standing bmp
GR.SPRITE.DRAW s2,250,300,sb
speed=120                   % movement speed
arate=16                    % animation rate
gr.modify s1,"dir",0        % degrees 0 => east
gr.modify s1,"speed",speed  % pixels/sec
gr.modify s1,"arate",arate  % frames/sec
gr.modify s1,"anim",0       % off = standing bmp

gr.modify s2,"dir",0        % degrees 0 => east
gr.modify s2,"speed",0      % 0 => don't move
gr.modify s2,"arate",arate  % frames/sec
gr.modify s2,"anim",ar      % right animation

! Text for information
gr.text.size 36 : gr.color "blue"
gr.text.draw t1,50,600,"Touch to move & animate"
gr.text.draw t2,260,500,"BackKey to quit"

ani = ar    % the current animation

while 1         % the main loop
    gr.render               % show current state
    while !touched          % wait for touch
        gr.touch touched,tx,ty
        pause 10
    repeat
                            % touched (finger down)
    gr.modify s1,"anim",ani % animate (not standing)
    gr.render               % display current frames

    f=0 : hold=clock()-1
    GR.MOTION.MARK          % first motion is from now
    while touched       % The motion loop
        GR.MOTION           % update motion & animation
                            % test for collision
        gr.get.value s1,"x",x
        if x<0                  % change direction
            gr.modify s1,"x",0,"dir",0~
                ,"anim",ar~     % change animation
                ,"aframe",0     % reset frame #
            gr.modify s2~       % s2 doesn't move
                ,"anim",ar~     % change animation
                ,"aframe",0     % reset frame
        elseif x>500            % change direction
            gr.modify s1,"x",500,"dir",180~
                ,"anim",al~     % change animation
                ,"aframe",0     % reset frame #
            gr.modify s2~       % s2 doesn't move
                ,"anim",al~     % change animation
                ,"aframe",0     % reset frame
        endif
                            % show frame number
        gr.get.value s2,"aframe",af % get frame
        gr.modify t2,"text","[ "+int$(af)+" ]"
        gr.render           % display motion
        f++
        gr.touch touched,tx,ty
    repeat %_motion_loop
    fps = f*1000/(clock()-hold)
                            % not touched (finger up)
    gr.get.value s1,"anim",ani % save current animation
    gr.modify s1,"anim",0   % remove anim = standing bitmap
repeat % main_loop

onbackkey:
 GR.CLOSE
 ? "fps = ";fps
END
