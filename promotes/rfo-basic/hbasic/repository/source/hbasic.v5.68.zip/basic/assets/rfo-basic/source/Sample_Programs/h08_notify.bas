!!
This program demonstrates the
use of the Notify command
and subcommands.
to put up a notification.

v1.00 -humpty: Oct-2023 

!!
print "Testing Notify"
print "  Tap the notification"
print "  to see if it succeeds."
print "  or BackKey to continue"
print
print "Notify.Status gets last state"
print "0 = was not waiting"
print "1 = continued (e.g backkey)"
print "2 = tapped notification"
print "3 = dismissed notification"
print "4 = cancelled (notify.cancel)"

wait=1

print "waiting.."
Notify "Title","Sub-Title","Alert String", wait

print "back to program"
Notify.Status last
print "last state = ";last
if last=1 then		% notification continued
	gosub getTouch	% wait for next action
	Notify.Status last
	print "last state = ";last
endif
end "End of program."

getTouch:
	print "Short Tap a line to continue, or"
	print "Long Tap cancels notification"
	backKey=0
	ctouched=0
	do : pause 100 :until ctouched | backKey
return

OnBackKey:
	print "OnBackKey"
	backKey=1
Back.Resume

onConsoleTouch:
	Console.line.touched line,long
	if long then Notify.Cancel else ctouched=1
ConsoleTouch.Resume
