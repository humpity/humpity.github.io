!!
This program demonstrates
a twidle cursor using the
BACKSPACE command.
!!


PRINT "BACKSPACE Demo"
PRINT
PRINT "Processing,"
PRINT "Please wait.. "

ARRAY.LOAD twidle$[], "-", "\\", "|", "/"
busy = 1
i = 1

WHILE busy
 BACKSPACE
 PRINT twidle$[i]
 IF ++i > 4 THEN i=1

 GOSUB myJob
REPEAT

BACKSPACE	% clear twidle
PRINT "Job done."
END

myJob:
 PAUSE 1000	% pretend to do something
 busy++
 IF busy > 10 THEN busy = 0
RETURN
