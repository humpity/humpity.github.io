!!
 Adapt to console Orientation
 For hBasic v5.63+

 - v1.00 -humpty: Jan-2026

!!
@@hide_actionbar
@@hide_statusbar
@@window_bg "black"
       % Set auto-rotate
console.Orient -1

gosub doInit
oriChanged = 0
do
    if oriChanged then
        gosub doUpdate
        oriChanged = 0
    endif
    pause 100
until 0
% (backKey never gets here)
END

doInit:
    % Set up screen, print text
    .cs "textsize 20",~
    "textcolor yellow",~
    "backcolor #00000000",~
    "dividers off",~
    "voidcolor black",~
    "wrap off"

    f$="sky.jpg"
    fit=4   % fit to longest side

    ?.img 1,1,"tag","cartman.png",-2,3
    CONSOLE.backIMG f$,fit
    ?.at 1,0;" Cartman says"
    ?"        Rotate the phone"
    .cs "textcolor blue"
return

doUpdate:
    % Reload wallpaper
    CONSOLE.backIMG f$,fit

    % Format some empty lines
    clr 3 : clr 4

    % Print orientation
    .cs "backcolor white.150"
    ?.at 3,w/2-4;" "~
    ;DEVICE$("Orient_Simple")~
    ;" "

    % Restore text transparency
    .cs "backcolor #00000000"
    ?.at 4,w-16;"BackKey to quit"
return

onOrient:  % On Orientation Change
    % (could happen before program starts)
    console.screen w,h
    OriChanged = 1
Orient.Resume
OnBackKey:
    END
Back.Resume

