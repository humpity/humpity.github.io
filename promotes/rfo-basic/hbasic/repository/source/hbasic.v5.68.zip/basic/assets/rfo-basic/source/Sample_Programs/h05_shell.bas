!!
The program implements a
terminal using TGET and
SYSTEM commands.

v1.01 -humpty: adaptation of f36_superuser.bas,
device does not have to be rooted.

!!
CONSOLE.SET "SPACING 2",~
            "TEXTCOLOR black",~
            "BACKCOLOR white"
PRINT "       Terminal Demo"
PRINT "'exit' to exit or BackKey"
PRINT "or [menu]-Stop"
PRINT " e.g cmd> pwd"
CONSOLE.SET "BACKCOLOR BLUE"
CONSOLE.SET "TEXTCOLOR LIGHTGREY"
CONSOLE.SET "DIVIDERS OFF",~
            "VOIDCOLOR BLUE"
! Open a shell
SYSTEM.OPEN

! Main loop
loop:

! get the command from the user
TGET r$, "cmd> ","Enter Command", bkey

! if cmd is "exit"
IF r$ = "exit" | bkey
 SYSTEM.CLOSE
 CONSOLE.SET "TEXTCOLOR black",~
             "BACKCOLOR white",~
             "VOIDCOLOR white"
 PRINT "Exited"
 IF bkey THEN PRINT "by BackKey"
 END
ENDIF

! write the command
SYSTEM.WRITE r$	+" 2>&1"	% also capture errors

! Give system time to respond
PAUSE 500
SYSTEM.READ.READY ready
! read responses if any

WHILE ready
 SYSTEM.READ.LINE l$
 if l$<>"" then PRINT l$
 SYSTEM.READ.READY ready
REPEAT

! Go for the next command
GOTO loop

