!!
This program demonstrates some
of the possibilities
when using the BASIC! html commands.
!!

! html must be opened before doing
! any html command
HTML.OPEN

! Load the file, htmldemo1.html

HTML.LOAD.URL "htmldemo1.html"

!The user now sees the html

! We can now monitor the user
! actions

xnextUserAction:

! loop until data$ is not ""

DO
 HTML.GET.DATALINK data$
UNTIL data$ <> ""

! The first four characters of data$
! identify the type of data returned.
! Extract those three characters to
! use in a switch statement

PRINT "data$=";data$
type$ = LEFT$(data$, 4)

! Trim the first four characters from
! data$

data$ = MID$(data$,5)

! Act on the data type
! Shown are all the current data types

SW.BEGIN type$

 ! Back Key hit.
 ! if we can go back then do it
 SW.CASE "BAK:"
  PRINT  "BAK: Received > " + data$
  IF data$ = "1" THEN HTML.GO.BACK ELSE END
  SW.BREAK

 ! A hyperlink was clicked on
 SW.CASE "LNK:"
  PRINT  "LNK: Received > "+ data$
  HTML.LOAD.URL data$
  PRINT "LNK Forwarded ";
  IF RIGHT$(data$,7)="sign_in" THEN PRINT "(with 'FORM')" ELSE PRINT
  SW.BREAK

 ! An error occured
 SW.CASE "ERR:"
  PRINT  "ERR: Received > " + data$
  SW.BREAK

 ! User data returned
 SW.CASE "DAT:"
  PRINT  "DAT: Received > "+ data$
  
  ! Check for Exit
  IF data$ = "Exit"
   PRINT "User ended demo."
   HTML.CLOSE
   END
  ENDIF
  
  ! Check for Speech to text
  IF data$ = "Speech"

   HTML.CLOSE	% speech is unreliable inside HTML
		% so let's do it in console
   STT.LISTEN 
   STT.RESULTS theList

   ! Get the first (best) result
   LIST.GET theList, 1, theText$
   theText$ = "You said: " + theText$

   ! Insert the text into the HTML (* UNRELIABLE *)
   ! insert$ = "javascript:text(\""+theText$+"\")"

   PRINT theText$
   ! save speech to a pre-determined file (* MORE RELIABLE *)
   TEXT.OPEN w,fv,"speech.js"
   TEXT.WRITELN fv,"document.write ('"+theText$ +"');"
   TEXT.CLOSE fv
   ! speech will show up inside webpage
   HTML.OPEN
   HTML.LOAD.URL "htmldemo1.html"
  ENDIF

  SW.BREAK

 ! Form data returned.
 ! Note: Form data returning
 ! always exits the html.

 SW.CASE "FOR:"
  PRINT  "FOR: Received > "+data$
  PRINT "End of Program"
  END
  SW.BREAK

 ! download requested
 ! extract the filename
 ! tell user download starting
 ! download it

 SW.CASE "DNL:"
  PRINT  "DNL: Received > "+ data$
  ARRAY.DELETE p$[]
  SPLIT p$[], data$, "/"
  ARRAY.LENGTH l, p$[]
  fn$ = p$[l]
  PRINT  "     Downloading ";fn$
  HTML.LOAD.STRING "<html> Starting download of " + fn$ + "<BR>2.8 mb<BR>Please Be Patient..</html>"
  BYTE.OPEN r,f,data$
  BYTE.COPY f,fn$
  PRINT  "     Downloaded."
  PRINT "End of Program"
  END
  SW.BREAK

 SW.DEFAULT
  PRINT "Unexpected data type:", type$ + data$
  END

SW.END

GOTO xnextUserAction

