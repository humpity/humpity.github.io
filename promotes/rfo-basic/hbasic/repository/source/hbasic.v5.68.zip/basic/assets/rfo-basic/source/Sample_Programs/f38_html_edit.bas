!!
	A program to edit files.
	uses FILE.DIR and TEXT.INPUT.
!!

! Get the filename and filter for *.html

FILE.DIR "" , dlist$[] , "/"
LIST.CREATE s, filtered
ARRAY.LENGTH last, dlist$[]
FOR i=1 to last
    IF RIGHT$ (dlist$[i], 5) = ".html" THEN
	LIST.ADD filtered, dlist$[i]
    ENDIF
NEXT

LIST.SIZE filtered, last
IF last<1 THEN PRINT "Aborted, no *.html files found.":END

DIALOG.SELECT f, filtered , "Select a File"
IF f=0 THEN PRINT "Aborted.": END
LIST.GET filtered, f, fn$

! open it, grab the contents
! and close the file

data$ = ""
GRABFILE data$, fn$

! use text.input to do
! the editing

TEXT.INPUT data1$, data$, "Editing "+fn$
IF data1$ = data$ THEN PRINT "No Changes made.": END

! Now write the edited
! text to a new file
fn$=fn$+".edited"
TEXT.OPEN w,f, fn$
TEXT.WRITELN f,data1$
TEXT.CLOSE f
PRINT "Your edits were saved to ";fn$
END
