! Buttons Demo
! for hBasic v4.48+
! v1.1 - correct centering

! console.tapped can detect a word under the tap.

fn.def center()
    console.screen  scrW,scrH	% for current text size
    fn.rtn ceil(scrW/2)         % screen center
fn.end
!---------------------------
fn.def msg(s$)
    fn.import mline
    .cs "textsize 24"
    clr mline,1             % clear old msg
    ?.at mline,center()-len(s$)/2;s$
    .cs "textsize 20"
fn.end
!---------------------------
colorN$="textcolor black, backcolor vanilla"
colorI$="textcolor blue, backcolor white"
colorB$="textcolor white, backcolor blue"
colorE$="textcolor black, backcolor peagreen"

menu.set ""                 % hides menu
console.title "Button Demo"
.cs "voidcolor vanilla, dividers off"
.cs "textsize 20"
cen20 = center()
cls
          % print blanks with default styling
.cs colorN$ : ?:?:?:?:?:?:?:?:?
console.line.count mline
!-------------------------- load & print buttons
dim button$[11]              % print buttons
.cs colorB$                 % button style
for i=1 to 8
    button$[i]=" Button"+int$(i)+" "
    gosub stamp
next
.cs colorE$
button$[i]=""           % 9
button$[++i]=""         % 10
button$[++i]=" Exit "   % 11
gosub stamp
.cs colorN$          % normal style

msg ("Tap a button")
quit=0 : do: pause 50: until quit
END
!==========================================
stamp:          % print button i
    row = 2+ floor((i+1)/2)
    if band(i,1) = 1 then col=cen20-9 else col=cen20+2
    ?.at row,col;button$[i]
return
!---------------------------------
flash:          % flash button i
    .cs colorI$
    gosub stamp
    pause 200
    if i<9 then .cs colorB$ else .cs colorE$
    gosub stamp
    .cs colorN$
return
!---------------------------------
onConsoleTouch:
    console.tapped row,col,wrd$,long
    if starts_with ("Button",wrd$) then
        i=val(right$(wrd$,1))
        gosub flash
        msg ("You pressed "+int$(i))
    endif
    if wrd$="Exit" then
        i=11:gosub flash
        msg ("End of Demo")
        quit=1
    endif
consoletouch.resume

