!!
 Tweens demo.
 For hBasic v5.04+

 This program demonstrates
 using Tweens with gr.motion.

 - v1.01 -humpty: Oct-2024
   Uses hBasic's built-in 
   motion & tweens.
!!
@@hide_actionbar    % prevents flash of console title
dW=720 : dH=1280    % dev size
gr.open "cream",,1  % color,bar,portrait
gr.color "blue",1
gr.screen rW,rH     % real WxH
sW=rW/dW            % scale to width
gr.scale sW,sW

! Shapes
gr.circle oC,100,100,50
gr.rect oR,200,100,300,200
gr.arc oA,100,200,300,400,290,40,1
!---------------------------------
% Animation w,h,frames{,offset}
gr.anim.load a1,"h-anim.png",32,33,16
gr.anim.scaf a1,3   % enlarge left animation
!---------------------------------
! Sprite oS
gr.bitmap.load b1,"h-stand.png"
gr.bitmap.scaf b1,3         % 3x enlarge inplace
gr.sprite.draw oS,300,700,b1 % standing sprite
!-------------
! attach animation
gr.modify oS,"anim",a1~     % player left animation
            ,"aframe",0~    % reset frame
            ,"arate",0~     % rate 0 => freeze frame
            ,"aloop",1      % loop forever
!---------------------------------
! Status text oT
gr.text.size 40
gr.text.draw o,200,50,"#Tweens:"
gr.text.draw oT,380,50,""
!---------------------------------
! Collections
gr.group oG,    oC,oR,oA        % group
array.load a[], oC,oR,oA        % array
!---------------------------------
! Add Tweens - obj,parm$,rate,dur
gr.tween.add oC,"x",100,2000          % 1
gr.tween.add oR,"x",100,4000          % 2
gr.tween.add oR,"alpha",-50,4000      % 3
gr.tween.add oA,"start_angle",90,5000 % 4

! tween frame# of animation
! instead of using "arate"
gr.tween.add oS,"aframe",16,6000 % 5 tweened animation

! tween a set of objects
! use one of the below
!gr.tween.add oG,"y",100,3000   % 6,7,8 tweened motion (group)
gr.tween.add a[],"y",100,3000  % 6,7,8 tweened motion (array)
!---------------------------------
gr.render       % show intial positions
pause 500
gr.motion.mark  % 1st timing
do              % main loop
 gr.motion      % all motion & tweens
 gr.render
 if gr_tweens() <> tz then
    tz=gr_tweens()  % update text
    gr.modify oT,"text",str$(tz)
 endif
until tz<1
gr.render
pause 1000      % show last render
end
