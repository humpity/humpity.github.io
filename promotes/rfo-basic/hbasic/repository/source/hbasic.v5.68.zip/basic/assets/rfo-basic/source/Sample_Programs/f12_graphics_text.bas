! This example shows the different effects
! available for drawing graphical text.
!
! Open Graphics Screen with a White background.

GR.OPEN 255, 255, 255, 255,0,1	% A,R,G,B,barOFF,portrait
PAUSE 1000
GR.SCREEN w,h

xleft = w/4
block = h/9
bc = 1 % Block level

! Draw a Black text alignment line

GR.COLOR 255,0,0,0,1
GR.LINE n, xleft,0, xleft,h

! Eight block of text will be drawn
! evenly spaced

! Set the text color to Red with fill = false

GR.COLOR 255,255, 0, 0, 1

! Set the text size to 1/25th screen height

tsize = w/25
GR.TEXT.SIZE tsize

! Set the text align to Left = 1

GR.TEXT.ALIGN 1

GR.TEXT.DRAW P, xleft, block/2, "Left Aligned"

! Set the text align to Center = 2

GR.TEXT.ALIGN 2

GR.TEXT.DRAW P, xleft, block/2+tsize*1.3, "Center Aligned"

! Set the text align to Right = 3

GR.TEXT.ALIGN 3

GR.TEXT.DRAW P, xleft, block/2+tsize*2.6, "Right Aligned"

! Demonstrate Text Sizes and Styles
! All examples will be aligned Left = 1
! and with Blue (0,0,255) text with fill = false

xleft = w/2
GR.TEXT.ALIGN 2
GR.COLOR 255, 0, 0, 255, 0

bc = bc +1
GR.TEXT.SIZE  block
GR.TEXT.DRAW blink_ptr, xleft, bc*block, "Bigger"
bc = bc +1

GR.TEXT.SIZE block/4
GR.TEXT.DRAW P, xleft,  bc*block, "Tiny Text"
bc = bc +1

! normal text size is block/2
hblock = block/2
GR.TEXT.SIZE hblock
GR.TEXT.BOLD 1
GR.TEXT.DRAW BTP, xleft , bc*block, "Bold, unfilled"
bc = bc +1

! Show Bold, filled text. Change the color
! fill parameter to true

GR.COLOR 255, 0, 0, 255, 1

GR.TEXT.DRAW P, xleft, bc*block, "Bold, filled"
bc =bc + 1

! Show Underlinded text

GR.TEXT.BOLD 0
GR.TEXT.UNDERLINE 1
GR.TEXT.DRAW P, xleft, bc*block, "Underlined"
bc =bc + 1

! Show strike through text

GR.TEXT.UNDERLINE 0
GR.TEXT.STRIKE 1
GR.TEXT.DRAW P, xleft, bc*block, "Strike through"
bc =bc + 1

! Show skewed text

GR.TEXT.STRIKE 0
GR.TEXT.SKEW -0.25
GR.TEXT.DRAW P,xleft, bc*block, "Skewed text"

! Now render everything

GR.RENDER

! After a one second pause,
! start to blink the big text

PAUSE 1000

DO
 GR.HIDE blink_ptr
 GR.RENDER
 PAUSE 500
 GR.SHOW blink_ptr
 GR.RENDER
 PAUSE 750
UNTIL 0

! The program does not end until the
! BACK key is pressed. When BACK
! is pressed, there will be a graphics
! not open error. The onerror will
! it an end without an error.

ONERROR:
END
