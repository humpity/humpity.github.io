!! TGET.S/N/I/P Demo
 for hBasic v4.48+

 Console Form Input using TGET and CONSOLE.TAPPED

 - v1.10 -humpty: Nov-2025
          Added dimming
!!
fn.def center()         % get horizontal center
    console.screen  W,H % (depends on textsize)
    fn.rtn ceil(W/2)
fn.end
!---------------------------
fn.def msg(s$)          % print a message
    fn.import mline     % on this line
    .cs "textsize 22"
    clr mline,1         % clear old msg
    ?.at mline,center()-len(s$)/2;s$
    .cs "textsize 20"
fn.end
!---------------------------
                % setup screen & styles
colorN$="textcolor black, backcolor vanilla"  % normal
colorF$="textcolor blue, backcolor white"     % field
colorD$="textcolor vanilla, backcolor grey"   % dim
colorE$="textcolor white, backcolor peagreen" % exit

menu.set ""                 % hides menu
console.title "TGET./S/N/I/P Demo"
.cs "voidcolor vanilla, dividers off"
.cs "textsize 20"
cen = center()
cls
.cs colorN$
blank$ = "                    "
mline = 8       % msg line
!---------------------------
last=0          % load data
DO
    last++      % find last
    READ.NEXT find$
    READ.NEXT dat
    READ.NEXT dat$
    READ.NEXT dat$
until find$="END"
last--          % allocate storage
dim lab$[last], typ$[last], col[last]
dim siz[last], val$[last]

READ.DATA~
"Name",15,"John","S",~
"Location",15,"London","S",~
"Height (m)",5,"1.75","N",~
"User Key",6,"137631","I",~
"Password",10,"secret","P",~
"END",0,"",""
!---------------------------
                    % print labels
xoff=1 : yoff=1
READ.FROM 1
for i = 1 to last
    READ.NEXT lab$[i]
    READ.NEXT siz[i]
    READ.NEXT val$[i]
    READ.NEXT typ$[i]
                    % collect input columns
    col[i] = len(lab$[i])+2 + xoff
next
GOSUB pFields       % print fields
!---------------------------
msg ("Tap a field to edit")
.cs colorE$         % print exit button
    gosub pExit
quit=0 : do: pause 50: until quit
END
!=========================================
pExit:              % print Exit
    ?.at 1,center()*2-6;" Exit "
    .cs colorN$
return
!---------------------------------
pField:             % print field i
    ?.at yoff+i,xoff+1; lab$[i];" " % label
    .cs color$      % with this color
    v$ = val$[i]
    if lab$[i]="Password" then v$="*****"
    if len(v$) < siz[i] then v$+=mid$(blank$,1,siz[i]-len(v$))
    ?.at yoff+i,col[i]; v$  %input box
    .cs colorN$     % restore normal color
return
!---------------------------------
pFields:            % print all fields
    color$ = colorF$
    for i=1 to last
        gosub pField
    next
return
!---------------------------------
dimField:               % dim a field
    color$ = colorD$    % with dim color
    i=edit
    gosub pField
return
!---------------------------------
detect:         % detect if field tapped
    edit=0
    if row <= yoff | row > yoff+last then return
    i = row - yoff
    if col < col[i] | col >= col[i]+siz[i] then return
                % field was tapped
    edit = i    % at this index
return
!---------------------------------
editField:      % get input for edit index
    s$ = val$[edit]         % get old value
    prompt$ = "Enter your "+lab$[edit]
    if typ$[edit] = "S"         % string
        TGET.S s$, prompt$,,BK
    elseif typ$[edit] = "N"     % number
        TGET.N s$, prompt$,,BK
    elseif typ$[edit] = "I"     % integer
        TGET.I s$, prompt$,,BK
    else                        % password
        s$=""
        TGET.P s$, prompt$,,BK
    endif
    if BK then
        msg ("update cancelled")
    elseif len(s$) > siz[edit]
        msg ("size too long! ")
    else
        val$[edit] = s$     % save result
        msg ("field updated ")
    endif
    GOSUB pFields
    pause 1000: msg ("")
return
!---------------------------------
onConsoleTouch:
    console.tapped row,col,wrd$,long
    gosub detect
    if edit then
        gosub dimField
        gosub editField
    elseif wrd$ = "Exit" then
        .cs colorD$     % dim exit
        gosub pExit
        goto done
    endif
consoletouch.resume
!---------------------------------
onBackKey:
    Dialog.message "","Quit Now ?",r,"Yes","No"
    if r=1 then END
Back.Resume
!---------------------------------
done:
    .cs "spacing 0"
    msg ("_Record Dump_")
    for i=1 to last : ?lab$[i] : next
    for i=1 to last : ?.at -last+i-1,center();val$[i] : next
END
