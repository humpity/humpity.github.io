!!
v2.00 -humpty: Mar-2025
        - uses hBasic commands
        - accomodate for cancel selection

v1.01 -humpty: Aug-2023 
        - modified from original f35_bluetooth
        - clear screen on new connection

This program demonstrates using
Bluetooth as both an application
that LISTENS for a connection
or MAKES a connection to a listener.
Data can be sent both ways.

   *** IMPORTANT ***
Before running this program use
the Android "Settings" application
to enable Bluetooth and to PAIR
with the device(s) that you will
talk to.

   *** IMPORTANT ***
Connection can be Initiated by
either device *-but not both-*.

Select ONE device to Connect,
Select the other device to Just Listen.
Once they both connect, they will both
be listening and can both send and
read data.

You can use this program to 
(among many other things) set
up a chat between two Android
devices.
!!

! Begin by opening Bluetooth
! If Bluetooth is not enabled
! the program will stop here.

BT.OPEN

! When BT is opened, the program
! will start listening for another
! device to connect. At this time
! the user can continue to wait
! for a connection are can attempt
! to connect to another device
! that is waiting for a connection

! Create first menu that Asks
! if the user wants to connect.
  ARRAY.LOAD type$[], "Connect to other device", "Just listen", "Quit"
  title$ = "Select Intial mode"

! Create the menu that will be loaded
! when the screen is touched.
  ARRAY.LOAD menu$[], "Send", "Disconnect","Quit"

new_connection:
? "new connection"
xdomenu =0

SELECT type, type$[], title$

! If the user pressed the back
! key or selected quit then quit
! otherwise try to connect to
! a listener

IF (type = 0) | (type =3) THEN GOTO Quit
IF type=2 THEN GOTO listen_loop

    % else type must be 1 - connect to device
    % user must choose the device from system gui
BT.CONNECT rc,1
        % If cancelled or error, try again
IF rc < 1 THEN 
    IF rc<0 THEN t$="Cancelled"
    IF rc=0 THEN t$="Error"
    DIALOG.MESSAGE t$,getError$(),again,"Try Again","Quit"
    IF again=1 THEN GOTO new_connection
    GOTO Quit
ENDIF

PRINT "Waiting for connection"
DO
 PAUSE 100
 BT.STATUS s
UNTIL s = 3
last=0      
BT.DEVICE.NAME n$ : ?"Connected to ";n$

! If the screen is touched, the interrupt
! code will change xdoMemu to 1 (true)
! In that case, show the menu.
! Otherwise look for incoming msgs.

! *** Listening Loop - wait for a message or tap ****
        % Only xdoMenu can break loop
listen_loop:
DO
 IF xdoMenu THEN D_U.break  % user taps for menu
 IF s = 1 & s<>last
    PRINT "Listening"
 ELSEIF s = 2 & s<>last
    PRINT "Connecting"
 ELSEIF s = 3 & s<>last
    BT.DEVICE.NAME device$      % get device name connected to
    CLS                         % new connection
    PRINT "Connected to ";device$
    PRINT "Touch any text line to send, disconnect or quit."
 ELSEIF s = -1
    PRINT "No Bluetooth"
    GOTO Quit
 ENDIF
 last = s

 BT.READ.READY rr       % check if any msg came in
 if rr then GOSUB readMsg   % ..and process it
 PAUSE 500
 BT.STATUS s
UNTIL 0
                % user has tapped menu
! *** xdoMenu Send, Disconnect, Quit or Continue to listen ***

  xdoMenu =0
  SELECT menu,  menu$[], "Do what?"
  IF menu = 3 THEN GOTO Quit            % wants to quit
  IF menu = 1 THEN GOSUB xdoSend : menu=0   % wants to send & continue
  IF menu = 0 THEN GOTO listen_loop     % continue listen loop
                    % else menu 2 wants disconnect
  BT.DISCONNECT
GOTO new_connection

! *** Read and Process Message ****
 ! Read messages until
 ! the message queue is
 ! empty
readMsg:
    % PRINT "Ready to Read"
    DO
      BT.READ.READY rr
      IF !rr THEN D_U.break     % no more to read
      BT.READ.BYTES rmsg$
      PRINT device$;": ";rmsg$
    UNTIL 0
RETURN

! *** Send Message ****
! Get and send message
! to the connected device
xdoSend:
    INPUT "Text to send", wmsg$
    BT.WRITE wmsg$;     % don't add a newline. PRINT will add it.
    PRINT "Me: "; wmsg$
RETURN

! *** Console was touched ****
 ! When Console is touched
 ! set xdoMenu to true
onConsoleTouch:
    xdoMenu = 1
    ConsoleTouch.Resume
OnBackKey:
Quit:
    BT.CLOSE
    PRINT "Quit> Thanks for playing"
END
onError:
    PRINT GETERROR$()
END
