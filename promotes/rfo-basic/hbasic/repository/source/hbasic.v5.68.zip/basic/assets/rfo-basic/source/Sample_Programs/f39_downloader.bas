! f39_downloader.bas
!
! Downloads shared BASIC! programs
! from the BASIC! shared program ftp site.
! Run the program and select the BASIC!
! program that you want to down load.
!
! v.2.0 -humpty: Jul-2025
! (format of website had changed)

CONSOLE.TITLE "Program Downloader"
PRINT "Getting directory list.."

! Set the default base
root$="/basic/programs"
base$="http://laughton.com"+root$

! Clear the relative path
path$="/"

! Load the first page
graburl page$, base$+path$

loop: % Main loop

! Create a list
! Add the parent dir

LIST.CREATE S, list
LIST.ADD list, ".."

! % get an array of items
! and add it to the list

split a$[], page$, "<a href=\""
ARRAY.LENGTH n,a$[]
FOR i=5 TO n
	split w$[], a$[i], "\">"
	head = len(root$+path$)
	a$[i]=right$(w$[1],-head)	% remove /basic/programs/..
NEXT
LIST.ADD.ARRAY list, a$[5,n]

! and an option to quit
LIST.ADD list, "Quit!"
LIST.SIZE list, s

!CLS % Clear the screen 

DIALOG.SELECT s, list, path$
! Use the path as message

! See if user quits (BackKey)
IF s=0 THEN GOTO Quit

! Get the file/folder name

LIST.GET list, s, choose$

! See if user quits (Selection)
IF choose$="Quit!" THEN GOTO Quit

! Check if user clicks ".."
! If it does, go back

IF choose$=".." THEN
 IF path$="/" THEN
  PRINT "Can't go back any more"
  POPUP "Can't go back"
  GOTO skip
 END IF
 SPLIT result$[], path$, "/"
 ARRAY.LENGTH l, result$[]
 PRINT "Going back..."
 l=l-1
 path$=""
 FOR i=1 TO l
  path$=path$+result$[i]+"/"
 NEXT i
 GRABURL page$, base$+path$
 GOTO skip
END IF

! Check if user clicked
! a folder

IF IS_IN("/", choose$, 1)>0 THEN
 path$ = path$ + choose$
 print "DIR chosen = ";choose$
 PRINT "Loading dir ";base$;path$
 PRINT "Please Wait.."
 GRABURL page$, base$+path$
 GOTO SKIP
END IF

! If the program reaches here
! Means than the user clicked
! A file
 print "FILE chosen = ";choose$

! Guess the destination of
! The download directory

IF IS_IN(".bas", choose$, 1) THEN
 default$="rfo-basic/source/"
ELSEIF IS_IN(".db", choose$, 1)
 default$="rfo-basic/databases/"
ELSE
 default$="rfo-basic/data/"
END IF

! Ask the user the
! Destination path

INPUT "Destination path", dest$, default$

dest$="../../"+dest$

! Download the file

PRINT "Downloading file...";base$+path$+choose$
POPUP "Downloading file...", 0, 0, 1
BYTE.OPEN r,f,base$+path$+choose$
BYTE.COPY f,dest$+choose$
! Tell user that the file has
! Finished downloading and
! Loop again

PRINT "Download complete!"
PAUSE 1000 % Pause for a little

skip:

ARRAY.DELETE result$[]
LIST.CLEAR list

GOTO loop % Loop again
Quit:
PRINT "Quit"
END

