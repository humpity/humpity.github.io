!!
This file contains executable examples
if - then - else operations. Examine 
the code  and run then run this program.
!!

! The code will print numbers
! 1 through 13 in the sequence
!
PRINT "Example 1 - Single LINE IF"

IF 1<2 THEN PRINT 1 ELSE PRINT 1000

IF 1>2 THEN PRINT 2000 ELSE PRINT 2

PRINT "Example 2 - BLOCK IF THEN ENDIF"

IF 1 THEN
 PRINT 3
 PRINT 4
ENDIF

PRINT "Example 3 - BLOCK IF THEN ELSE ENDIF"

IF 0 THEN
 PRINT 3
 PRINT 4
ELSE
 PRINT 5
ENDIF

! BLOCK IF (optional THEN)
! Note: If no statement is going to follow
! the THEN on same line,
! the THEN is assumed and need not be present.
! You can ONLY do this in a BLOCK IF
!
PRINT "Example 4 - BLOCK IF (optional THEN)"

IF 0
 PRINT 4000
 PRINT 4001
ELSE
 PRINT 6
ENDIF
PRINT 7

IF 1 | 0 THEN
 PRINT 8
 PRINT 9
ELSE
 PRINT 5000
 PRINT 5001
ENDIF
PRINT 10

IF 1 & 0 THEN
 PRINT 6000
 PRINT 6001
ELSE
 PRINT 11
 PRINT 12
ENDIF
PRINT 13

PRINT "Example 5 - Nested IF BLOCKs"

IF 1 = 1 THEN
 PRINT 1
 IF 1 = 2 THEN
  PRINT 1000
 ELSE
  PRINT 2
 ENDIF
 PRINT 3
ENDIF

IF 3 <> 3 THEN
 PRINT 2000
 IF 1 = 2 THEN
  PRINT 1000
 ELSE
  PRINT 2000
 ENDIF
 PRINT 3000
ELSE
 PRINT 4
 PRINT 5
ENDIF

IF 1 & 1
 PRINT 6
 IF 1 THEN
  PRINT 7
  IF 2 THEN
   PRINT 8
   PRINT 9
  ELSE
   PRINT 9000
  ENDIF
  PRINT 10
 ENDIF
 PRINT 11
ENDIF

! ELSEIF can chain a sequence of exclusive IFs.
! Only the first matching ELSEIF is executed,

! Note that the THEN is optional

PRINT "Example 6 - ELSEIF"

x=1
IF x=3
 PRINT 3
ELSEIF x=2 THEN
 PRINT 2
ELSEIF x=1
 PRINT 12
ELSEIF x=4 THEN
 PRINT 4
ELSEIF x=3
 PRINT 3000
ENDIF

! ESLEIF may be followed
! by an ELSE; however
! no following ELSEIF
! will ever be executed.
PRINT "Example 7 - ELSEIF - final ELSE"
x=1
IF x=3
 PRINT 3
ELSE IF x =4
 PRINT 4
ELSE
 PRINT 13
ELSEIF x=1
 PRINT 1
ENDIF
