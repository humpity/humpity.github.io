!!
 Decors demo.
 For hBasic v5.50+

 This program demonstrates
 hiding the actionbar using
 directives and/or decors.
 You may also use it to test 
 out other system bars.

 - v1.00 -humpty: Sep-2025
!!
! directives must be at start.
@@hide_actionbar    % hides console actionbar
@@window_bg "lightgrey"

! start of program
.CS "StatusTxt dark"     % Api 23 and later
.CS "NavBarTxt dark"     % Api 26 to Api 34
.CS "TextSize 20, Font sans-serif"
? "Console> tap BackKey to graphics"
for i=1 to 50 : ?int$(i) :next
console.goto 1
bk=0: do:pause 100: until bk

    % decors for graphics & web
    % dark text, no actionbar

sta=1: act=0 :nav=1
ndark=1 : sdark=1 : imm=0

    % set bits (nav inverted)
decors = sta*1 + act*2 + (!nav)*4 ~
+ sdark*8 + ndark*16 + imm*32

winBG$  = "lightgrey"
                    % Graphics
GR.OPEN "white", decors ,1, winBG$
GR.SCREEN w,h,d : th=20*(d/160)
gr.title "Graphics Title"~
,"red","lightblue.100"
gr.text.size th
gr.color "black" : gr.set.stroke 2
gr.text.draw oT,0,th*1.2~
," Graphics> tap BackKey to web"
gr.line oL,0,0,w,h
gr.render
bk=0: do:pause 100: until bk
GR.CLOSE
                    % Web
cls: ?"Please Wait.."
HTML.OPEN decors, 1, winBG$
html.title "HTML Title"~
,"blue","lightgreen.100"
s$="<big>Web> tap BackKey to End</big>"
for i=1 to 50 : s$+= "<br>"+int$(i)
next
html.load.string s$
    do : html.get.datalink data$
    until starts_with ("BAK:",data$)
HTML.CLOSE
cls: ? "Console> done."

END

OnBackKey:
 bk=1
Back.Resume
