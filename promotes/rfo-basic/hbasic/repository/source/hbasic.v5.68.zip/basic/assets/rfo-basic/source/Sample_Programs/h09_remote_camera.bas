!!

Modified from original f34_camera.bas

v1.00 -humpty: Nov-2023 
	- accept .jpg as well as .png
	- add re-connect on client
	- fix orientation switching

******  READ!  *******

See f32_tcp-ip_socket.bas
introduction for details
about setting up a server
and a client.

This program must be run
on two different Android
devices.

In this program, it is
a server that takes a picture
under command from a client. It
is a client that retrieves the
image and displays it.

The viewer saves the received
image in 
/<app_base>/rfo-basic/data/rimage.jpg
and displays the image

!!
! All menus to portrait
CONSOLE.ORIENT 1

ARRAY.LOAD type$[], "Camera Server", "Camera Viewer"
DIALOG.SELECT type, type$[], "Select Remote Type"
IF type = 0
 print "Thanks for playing"
 END
ELSEIF type = 2
 GOTO xdoViewer
ENDIF

!***********  Camera Server Server Demo  **************

SOCKET.MYIP ip$[],n
IF n=0 THEN GOTO Server_NoIP
IF n>1 THEN
	DIALOG.SELECT rc,ip$[], "Select This Device LAN IP"
	IF rc=0 THEN GOTO Server_NoIP
	ip$=ip$[rc]
ELSE
	ip$=ip$[1]
ENDIF

INPUT "Enter the port number", port, 1080

PRINT "LAN IP: " + ip$
GRABURL ip$, "http://icanhazip.com"
ip$ = TRIM$(ip$)
PRINT "WAN IP: " + ip$
PRINT "Port  :"+int$(port)
PRINT "(tap back-key to stop)"

! Create the server on the specified port
SOCKET.SERVER.CREATE port

newConnection:

! Connect to the next Client
! and print the Client IP
PRINT
PRINT "Waiting for Viewer Client.."
SOCKET.SERVER.CONNECT 0
DO
 SOCKET.SERVER.STATUS st
UNTIL st = 3
SOCKET.SERVER.CLIENT.IP ip$
PRINT "Connected to ";ip$
PRINT "Waiting for command.."
! Connected to a Client
! Wait for Client to send a message
! or time out after 30 seconds

maxclock = CLOCK() + 30000
breakout = 0
DO
 SOCKET.SERVER.READ.READY flag
 IF CLOCK() > maxclock THEN
  breakout=1
  PRINT "Read time out"			% waited too long for client cmd
 ENDIF
 IF breakout THEN D_U.BREAK
UNTIL flag

IF breakout THEN GOTO New_Server	% try again with a new server

! Message received. Read it.

SOCKET.SERVER.READ.LINE msg$
PRINT "Viewer command = ";msg$

! The message is a string with
! single digit

! Open Graphics (needs landscape)
GR.OPEN 255, 0,0,0, 0,0		% A,R,G,B, barOFF,landscape

SW.BEGIN msg$

 SW.CASE "0" % 0 = Quit
  PRINT "Viewer says to shutdown"
  GOTO QUIT
  SW.BREAK

 SW.CASE "1" % Automatic mode auto flash
  GR.CAMERA.AUTOSHOOT bm_ptr, 0
  SW.BREAK

 SW.CASE "2" % Automatic mode without flash
  GR.CAMERA.AUTOSHOOT bm_ptr, 2
  SW.BREAK

 SW.CASE "3" % Automatic mode with flash
  GR.CAMERA.AUTOSHOOT bm_ptr, 1
  SW.BREAK

 SW.CASE "4" % Re-Connect
  GR.CLOSE
  GOTO New_Server
  SW.BREAK

 SW.DEFAULT
  PRINT "Server Error> Invalid msg. Do some more debugging"
  END

SW.END

! We do not need the bitmap,
! so delete it.
IF bm_ptr < 1 THEN 
	PRINT "No bitmap captured"
ELSE
	GR.BITMAP.DELETE bm_ptr
ENDIF

! Close graphics
GR.CLOSE

IF bm_ptr < 1 THEN GOTO ServerFailed

! The autoshoot mode places an
! image file, image.png/jpg in the
! /sdcard/rfo-basic/data/
! directory
!
! Send that image to the client

BYTE.OPEN R, fr, "image.png"
IF fr=-1 THEN BYTE.OPEN r,fr, "image.jpg"
IF fr=-1 THEN PRINT "Cannot open image"
IF fr=-1 THEN GOTO ServerFailed

PRINT "Sending image.."
SOCKET.SERVER.WRITE.FILE fr
PRINT "Image sent."

! Finished this capture.
! Disconnect from Client

SOCKET.SERVER.DISCONNECT
PRINT "Disconnected from viewer"

! Loop to get the next Client

GOTO newConnection
ServerFailed:
  Dialog.Message , "Failed", again, "Try Again", "Quit"
  if again<>1 THEN GOTO QUIT
!----------------------------
New_Server:

 ! Disconnect, Close and bring up a new Server

  PRINT "Disconnecting Client"
  SOCKET.SERVER.DISCONNECT
  PRINT "Closing Server"
  SOCKET.SERVER.CLOSE
  PRINT "Creating new Server"
  SOCKET.SERVER.CREATE port

 GOTO newConnection

 ! ****************** Client Demo ****************

 xDOViewer:

  ! Load an array with the
  ! Select Options
  ARRAY.LOAD method$[], "Quit" ~
  "Capture with auto flash", "Capture without flash", "Capture with flash"~
  "Re-Connect","Shut down remote camera"

  ! Set the Popup Message
  msg$ ="Connected. Select A Capture Mode"

  INPUT "Enter the connect-to IP", ip$
  INPUT "Enter the port number", port, 1080

viewerAgain:

  ! Connect to the specified IP on the
  ! specified Port

  PRINT "Connecting to ";ip$
  SOCKET.CLIENT.CONNECT ip$, port
  SOCKET.CLIENT.STATUS rc
  IF rc=3 THEN GOTO viewerSelect	% connection OK

viewerFailed:
  Dialog.Message , "Connect Failed", again, "Try Again", "Quit"
  if again=1 THEN GOTO viewerAgain ELSE GOTO QUIT

viewerSelect:
  PRINT "Connected."
  ! Ask the user what to do
  SELECT mode, method$[], msg$

  ! A choice has been made
  ! Act on that choice
  SW.BEGIN mode

   SW.CASE 0 % Back Key
   SW.CASE 1 % Quit
    PRINT "Done taking pictures"
    END
    SW.BREAK

   SW.CASE 2 % Capture with auto flash
    SOCKET.CLIENT.WRITE.LINE "1"
    SW.BREAK

   SW.CASE 3 % Automatic mode without flash
    SOCKET.CLIENT.WRITE.LINE "2"
    SW.BREAK

   SW.CASE 4 % Automatic mode with flash
    SOCKET.CLIENT.WRITE.LINE "3"
    SW.BREAK

   SW.CASE 5 % Re-Connect
    SOCKET.CLIENT.WRITE.LINE "4"
	PAUSE 1000 %  give some time for new server
    GOTO viewerAgain
    SW.BREAK

   SW.CASE 6 % Shut down camera
    SOCKET.CLIENT.WRITE.LINE "0"
    PRINT "Done taking pictures"
    GOTO QUIT
    SW.BREAK

  SW.END

  ! and then wait for Server to respond
  ! or time out after 20 seconds

  PRINT "Waiting for image"
  maxclock = CLOCK() + 20000
  DO
   SOCKET.CLIENT.READ.READY flag
   IF CLOCK() > maxclock
    PRINT "Read time out"
    GOTO viewerFailed			% ask if try again
   ENDIF
  UNTIL flag

  ! Server has sent the image file.
  ! Read it. Print it.
  PRINT "Receiving image.."
  BYTE.OPEN W, fw, "rimage.jpg"
  SOCKET.CLIENT.READ.FILE fw
  BYTE.CLOSE fw
  PRINT "Image received"

  ! The image is now in the file
  ! "rimage.jpg"

  ! Close the client

  SOCKET.CLIENT.CLOSE
  PRINT "Disconnected from server"

  ! Open Graphics
  GR.OPEN 255, 0,0,0, 0,0		% A,R,G,B, barOFF,landscape

  ! Load the file into a bitmap

  GR.BITMAP.LOAD bm_ptr, "rimage.jpg"

  ! Scale the bitmap to fit the
  ! screen with the proper
  ! aspect ratio

  GR.BITMAP.SIZE bm_ptr, bw,bh
  IF bh > bw
   GR.ORIENTATION 1
   PAUSE 1000
   GR.SCREEN sw, sh
   ar = bw/bh
   GR.BITMAP.SCALE scaled_bm, bm_ptr, sw, sh*ar
  ELSE
   GR.SCREEN sw, sh
   ar = bh/bw
   GR.BITMAP.SCALE scaled_bm, bm_ptr, sw*ar, sh
  ENDIF

  ! Draw the scaled image bitmap
  GR.BITMAP.DRAW obj_ptr, scaled_bm, 0, 0

  ! Add some text

  GR.TEXT.SIZE sw/25
  GR.TEXT.ALIGN 1
  xleft = sw/12
  xtop = sh - 2*(sw/25)
  GR.COLOR 255, 255, 255, 255, 1
  GR.TEXT.DRAW P, xleft,  xtop, "Tap screen to take another picture."

  ! Now render the picture and text
  GR.RENDER

  ! Wait until touch and then untouch

  flag = 0
  DO
   GR.TOUCH flag, xx, yy
  UNTIL flag
  DO
   GR.TOUCH flag, xx, yy
  UNTIL !flag

  ! Delete the old bitmaps
  GR.BITMAP.DELETE bm_ptr
  GR.BITMAP.DELETE scaled_bm

  ! Close graphics
  GR.CLOSE

  ! Ready for the next capture
  GOTO viewerAgain
!-----------------------------
Server_NoIP:
	PRINT "Could not get My IP"
END
!-----------------------------
OnBackKey:
QUIT:
	IF type <> 1
	 PRINT "Shutting down Client"
	 SOCKET.CLIENT.CLOSE
	ELSE
	 PRINT "Shutting down Server"
	 SOCKET.SERVER.DISCONNECT
	 SOCKET.SERVER.CLOSE
	ENDIF

	PRINT "Done"
END

