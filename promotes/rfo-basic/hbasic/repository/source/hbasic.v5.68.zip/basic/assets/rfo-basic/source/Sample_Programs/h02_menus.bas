! hBasic Menu Test

? "Console Menu Test"
debug$ = ",$stop"

finish = 0
menuSelected = 0

console.title "Menu Test", "white","Green"
main_menu$ = "~Main Menu,Item 1,Item 2,~disabled item,Quit"+debug$
menu.set main_menu$

do
    menuSelected = 0
    do                  % wait for a menu selection
        pause 100
    until menuSelected
until finish            % user quits from menu
? "Done"
END

do_Menu:                % process menu tap
    menu.get label$, m : ? "Tapped: ";label$,m
    if m=0 then goto reset   % tapped outside of menu
    sw.begin label$
        sw.case "Item 1"
            menu.set "~Exclusive,Item 1-a,Item 1-b"+debug$
            if Item1a=1 then menu.disable 2 else menu.disable 3
            menu.show
            sw.break
        sw.case "Item 2"
            menu.set "~Non-Exclusive,Item 2-a,Item 2-b"+debug$
            menu.show
            sw.break
        sw.case "Item 1-a" : Item1a=1 : gosub Reset : sw.break
        sw.case "Item 1-b" : Item1a=0 : gosub Reset : sw.break
        sw.case "Item 2-a"
        sw.case "Item 2-b" : gosub Reset : sw.break
        sw.case "Quit"     : finish = 1  : sw.break
    sw.end
    menuSelected = 1
return
Reset:                % restore main menu
    menu.set main_menu$
return
onMenuTap:
    gosub do_Menu
    MenuTap.Resume
end
