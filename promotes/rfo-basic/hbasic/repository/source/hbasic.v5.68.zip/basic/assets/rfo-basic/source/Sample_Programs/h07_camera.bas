!!
This program demonstrates the
use of the camera interfaces 
by BASIC!
Modified from original f33_camera.bas

v1.02 -humpty: Nov-2023 
	- better orientation switching

GR.CAMERA saves images to data/image.<ext>
!!
! Load Select Options
ARRAY.LOAD method$[], "Quit" ~
"Use Device User Interface" ~
"Automatic with auto flash", "Automatic mode without flash", "Automatic mode with flash"~
"Manual with auto flash", "Manual mode without flash", "Manual mode with flash"

! Set the Title
msg$ ="Select A Capture Mode"

! Open Graphics
GR.OPEN 255, 0,0,0, 0,-1 % A,R,G,B, barOFF,auto

again:
! go back to phone orientation 
gr.orientation -1
pause 500
! Ask the user what to do
 SELECT mode, method$[], msg$, ""

 IF mode < 2	% Back Key or Quit
	PRINT "Done taking pictures"
	END
 ENDIF
! camera needs landscape
gr.orientation 0

! Act on that choice
SW.BEGIN mode

 SW.CASE 2 % Use Device User Interface
  GR.CAMERA.SHOOT bm_ptr
  SW.BREAK

 SW.CASE 3 % Automatic mode auto flash
  GR.CAMERA.AUTOSHOOT bm_ptr, 0
  SW.BREAK

 SW.CASE 4 % Automatic mode without flash
  GR.CAMERA.AUTOSHOOT bm_ptr, 2
  SW.BREAK

 SW.CASE 5 % Automatic mode with flash
  GR.CAMERA.AUTOSHOOT bm_ptr, 1
  SW.BREAK

 SW.CASE 6 % Manual mode with auto flash
  GR.CAMERA.MANUALSHOOT bm_ptr, 0
  SW.BREAK

 SW.CASE 7 % Manual mode without flash
  GR.CAMERA.MANUALSHOOT bm_ptr, 2
  SW.BREAK

 SW.CASE 8 % Manual mode with flash
  GR.CAMERA.MANUALSHOOT bm_ptr, 1
  SW.BREAK

SW.END

! Test to insure that an
! image was captured
IF bm_ptr = 0
 PRINT "Image not captured"
 GOTO again
ENDIF

! If the picture is in
! in Portrait mode, switch
! to Portrait mode

! Scale the bitmap to fit the
! screen with the proper
! aspect ratio

GR.BITMAP.SIZE bm_ptr, bw,bh
ori = bh>=bw		% 1 = portrait, 0=landscape
GR.ORIENTATION ori	% set GR to same orientation as bitmap
PAUSE 1000			% give GR some time to re-orientate
ar = bw/bh
GR.SCREEN sw, sh
IF sw<sh			% phone is portrait
 GR.BITMAP.SCALE scaled_bm, bm_ptr, sw, sw/ar
ELSE				% phone is landscape
 GR.BITMAP.SCALE scaled_bm, bm_ptr, sh*ar, sh
ENDIF

! Draw the scaled image bitmap
GR.BITMAP.DRAW obj_ptr, scaled_bm, 0, 0

! Add some text

GR.TEXT.SIZE sw/25
GR.TEXT.ALIGN 1
xleft = sw/12
xtop = sh - 2*(sw/25)
GR.COLOR 255, 255, 255, 255, 1
GR.TEXT.DRAW P, xleft,  xtop, "Tap screen to take another picture."

! Now render the picture and text
GR.RENDER

! Wait until touch and then untouch

flag = 0
DO
 GR.TOUCH flag, xx, yy
 pause 50
UNTIL flag
DO
 GR.TOUCH flag, xx, yy
 pause 50
UNTIL !flag

!Clear the screen

GR.CLS
GR.RENDER

! Delete the old bitmaps
GR.BITMAP.DELETE bm_ptr
GR.BITMAP.DELETE scaled_bm

! Ready for the next capture
GOTO again
