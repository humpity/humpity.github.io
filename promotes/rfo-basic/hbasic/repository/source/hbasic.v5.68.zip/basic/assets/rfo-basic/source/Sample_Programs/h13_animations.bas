!! Animated Graphics

 Modified from original legacy
 Basic f13_animations.bas

 This program demonstrates
 the gr.rotate , gr.modify, 
 gr.motion, gr.anim, gr.sprite
 and audio commands in the
 context of a graphics animation.

- v1.00 -humpty May-2024
  Uses hBasic's built-in motion
  instead of manual positioning.
  Uses hBasic's sprite animation 
  instead of multiple objects.
!!
! Open Graphics screen & get size
GR.OPEN "white",0,1 % color,barOFF,portrait
GR.SCREEN w,h

! Set up to draw objects with filled Red
GR.COLOR "red", 1

! Draw some rotated text
GR.TEXT.ALIGN 1      % align left
GR.TEXT.SIZE h/17
tx = w
t$ = "Cartman loves BASIC!"
GR.TEXT.WIDTH tw,t$     % calc offscreen X
xOffScr = tw+tx * (1- cos(toRadians(-45)))
GR.ROTATE.START -45, tx, 180
    GR.TEXT.DRAW o_txt, tx, 180, t$
GR.ROTATE.END   % signals end of rotate

! The text moves left but because
! it's rotated, it also moves down.
! Give the text a direction and speed

gr.modify o_txt,"dir",180     % left
gr.modify o_txt,"speed",100   % pixels/sec

! General positions
bleft = w/4 : btop = h-55   % box position
floor   = btop-48           % standing on box
ceiling = btop-148          % top of a jump

! First draw a box for Cartman to land on.
! (filled red from gr.color command)
! The box is 68 x 55 pixels
GR.RECT q, bleft, btop, bleft+68, h

! Cartman's Sprite is 48 x 48 Pixels
cw=48 : ch=48

% There are 9 animation frames 0 to 8
frames=9 : lastFrame = frames-1

! Load a standing image for the Sprite
! from the data directory
! "<something>/rfo-basic/data/"
GR.BITMAP.LOAD p_bmp, "cartman.png"

! Create a Sprite with a standing bitmap
! set cartman on top of the box
GR.SPRITE.DRAW spr, bleft+10, floor, p_bmp

! Create an animation with 9 empty frames.
GR.ANIM.LOAD ani,"", cw,ch, frames

! Use a temporary bitmap to draw into.
GR.BITMAP.CREATE bmp,cw,ch

! Draw & Load the animation frame by frame
frame=0
FOR angle = 0 TO 360 STEP 45  % For each angle

 ! draw one rotation of Cartman
 GR.BITMAP.DRAWINTO.START bmp
     GR.ROTATE.START angle, 24, 24
     GR.BITMAP.DRAW o, p_bmp, 0,0
     GR.ROTATE.END
 GR.BITMAP.DRAWINTO.END
                % copy bmp to frame
 GR.ANIM.PUTF ani,frame++,bmp   
 GR.BITMAP.CLR bmp % clear for next frame

NEXT angle  % step through all 9 positions
! Above animation will be attached
! to the sprite only when it's played.

! Don't attach the animation to the
! sprite yet. (Cartman starts standing).
GR.MODIFY spr,"anim",0  % no animation

! But do preset the sprite's animation
! rate to frames per second (9).
GR.MODIFY spr, "arate",frames

! Don't loop the animation
GR.MODIFY spr, "aloop",0    % one run only
! At the end of the animation, 
! it will freeze on the last frame.

!---------------------------
! Load up some audio cips
AUDIO.LOAD whee, "whee.mp3"
AUDIO.LOAD boing, "boing.mp3"

GR.MOTION.MARK  % first motion is from now

! This is the main animation loop
loop:
 t=clock()
 do         % wait 1 second for standing cartman
    gr.render               % display objects
    GR.MOTION               % (moves text)
                            % check if text has
    gr.get.value o_txt,"x",x    % moved off screen
    if x < -xOffScr then gr.modify o_txt,"x",tx
 until clock()>t+1000
                            % jump up
 gr.modify spr,"speed",500,"dir",-90
 AUDIO.STOP                 % play whee sound
 AUDIO.PLAY whee,1
 do                 % motion loop1 - jump
    gr.render               % display objects
    GR.MOTION               % update positions
    gr.get.value spr,"y",y
 until y < ceiling          % stop in mid-air
 gr.modify spr,"y",ceiling, "speed",0

    ! attach animation and reset frame
 gr.modify spr,"anim",ani,"aframe",0
 do                 % motion loop2 - animate
    gr.render               % display objects
    GR.MOTION               % update animation
    gr.get.value spr,"aframe",f
 until f >= lastFrame       % until end of animation

    ! remove animation and float down
 gr.modify spr,"anim",0     % 0 = standing bitmap
 gr.modify spr,"speed",100,"dir",90 
 do                 % motion loop3 - fall
    gr.render               % display objects
    GR.MOTION               % update positions
    gr.get.value spr,"y",y
 until y >= floor           % until fallen down
 gr.modify spr,"y",floor,"speed",0  % stop on box

 ! Cartman just landed on the box,
 AUDIO.STOP                 % play boing sound
 AUDIO.PLAY boing,1

! end of one animation step
GOTO loop       % do the animations forever
!-----------------------------
END
