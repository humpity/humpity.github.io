/****************************************************************************************************

BASIC! is an implementation of the Basic programming language for
Android devices.

Copyright (C) 2010 - 2015 Paul Laughton

This file is part of BASIC! for Android

    BASIC! is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    BASIC! is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with BASIC!.  If not, see <http://www.gnu.org/licenses/>.

    You may contact the author or current maintainers at http://rfobasic.freeforums.org

*************************************************************************************************/

package com.rfo.hbasic;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;

import com.rfo.hbasic.Basic.ColoredTextAdapter;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import android.graphics.drawable.ColorDrawable;

import static com.rfo.hbasic.Editor.GO_UP;
import static com.rfo.hbasic.Editor.addDirMark;
import static com.rfo.hbasic.Editor.isMarkedDir;
import static com.rfo.hbasic.Editor.stripDirMark;
import static com.rfo.hbasic.Editor.getDisplayPath;
import static com.rfo.hbasic.Editor.goUp;
import static com.rfo.hbasic.Editor.quote;


// Loads a file. Called from the Editor when user selects Menu->Load

public class LoadFile extends Activity {
	private static final String LOGTAG = "Load File";

	private Basic.ColoredTextAdapter mAdapter;
	private Toast mToast = null;

	private String mProgramPath;										// load file directory path
	private Basic.mOutputArray<String> FL = new Basic.mOutputArray<String>();

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setRequestedOrientation(Settings.getScreenOrientation(this));
		Basic.installOnBackPressed(this);
		Astyle.SetTitle (this, getResources().getString(R.string.load_name));

		mProgramPath = Editor.ProgramPath;							// set Load path to current program path

		mAdapter = new ColoredTextAdapter(this, FL, Basic.defaultTextStyle);	// Display the list
		updateList();												// put file list in FL

		setContentView(R.layout.loadfile);
		ListView lv = (ListView)findViewById(R.id.loadFile); 
		lv.setAdapter(mAdapter);
		lv.setTextFilterEnabled(false);
		lv.setBackgroundColor(mAdapter.getBackgroundColor());		// void=textbg
		lv.setDivider(new ColorDrawable(mAdapter.getLineColor()));	// -humpty 0310
		lv.setDividerHeight(1);										// needs this or it won't work

		// The click listener for the user selection *******************

		lv.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

				// User has selected a line.
				// If the selection is the top line, ignore it.
				if (position == 0)		return;

				view.setBackgroundColor(mAdapter.getHighlightColor());

				// If the selection is a directory, change the program path
				// and then display the list of files in that directory.
				// Otherwise load the selected file and tell the Editor it was loaded.

				String fileName = FL.get(position);
//				Log.i(LOGTAG, "Selection: " + quote(fileName));
				if (SelectionIsFile(fileName))			// -humpty 0300 will also update list if dir
				{
					FileLoader(fileName);
					setResult(RESULT_OK);
					Toast_Kill();
					finish();									// LoadFile is done
					return;
				}
//~				else									// -humpty 0300 don't updateList if not needed
//~				{										// don't overwrite error toasts if dir
//~					updateList();
//~				}
			}
		});

		// End of Click Listener **********************************************
	}//_onCreate

	@Override
	public void onBackPressed()
	{
		setResult(RESULT_CANCELED);
		Toast_Kill();
		finish();								// done with LoadFile
	}//_onBackPressed
//-------------------------------------------------
	private void Toast_Kill ()						// kill current toast
	{
		if (mToast != null)	{ mToast.cancel(); mToast = null; }
	}//_Toast_Kill
//-------------------------------------------------
	private void Toast_Now (String msg)				// Toast immediatley
	{
		Toast_Kill();								// kill any current toast
		mToast = Basic.toaster(this,msg);
	}//_Toast_Now
//-------------------------------------------------
	private void updateList() {

		File dir = new File(mProgramPath);
		dir.mkdirs();

		String[] fileList = dir.list();							// Get the list of files in this dir
		if (fileList == null) {									// -humpty 0300 this should never happen now,
																//  as mProgramPath is pre-validated
			String msg = dir.exists() ? "File not directory" : "Source directory does not exist";
//			Toast_Now ("System Error: " + msg);					// debug - dir.getPath()
			Toast_Now ("System Error: " + mProgramPath);		// debug - dir.getPath()
			return;
		}

		// Go through the list of files and mark directories with "(d)".
		// Display only files with the .bas extension.
		ArrayList<String> dirs = new ArrayList<String>();
		ArrayList<String> files = new ArrayList<String>();
		String absPath = dir.getAbsolutePath() + '/';
		for (String s : fileList) {
			File test = new File(absPath + s);
			if (test.isDirectory()) {							// If file is a directory, add "(d)"
				dirs.add(addDirMark(s));						// and add to display list
			} else {
				if (s.toLowerCase(Locale.getDefault()).endsWith(".bas")) { // Only put files ending in
					files.add(s);								// .bas into the display list
				}
			}
		}
		Collections.sort(dirs);									// sort the directory list
		Collections.sort(files);								// sort the file list

		FL.clear();
		FL.add("Path: " + quote(getDisplayPath(mProgramPath))); // put the path at the top of the list - will not be selectable
		FL.add(GO_UP);											// put  the ".." above the directory contents
		FL.addAll(dirs);										// copy the directory list to the adapter list
		FL.addAll(files);										// copy the file list to the end of the adapter list

		if (mAdapter != null) { mAdapter.notifyDataSetChanged(); }

//~		if (mToast != null) { mToast.cancel(); }				// -humpty 0300 this is annoying, don't do it
//~		mToast = Basic.toaster(this, "Select File To Load");	// tell the user what to do using Toast
	}//_updateList
//-------------------------------------------------
	private boolean SelectionIsFile(String fileName) {
		
		// Test to see if the user selection is a file or a directory
		// If is directory, then change the path so that the files
		// in that directory will be displayed.					// -humpty 0300 only updateList if neccessary
		
		if (fileName.equals(GO_UP)) 							// if GoUp is selected
		{
			String parent = goUp(mProgramPath);					// change path to its parent directory
			if (parent.equals(mProgramPath))	// if no change
			{									// then it failed
				Toast_Now ("Directory Error: Cannot Go Up");	// give an error msg. Do not updateList()
			}
			else
			{
				mProgramPath = parent;			// success, new path
				updateList();					// update the list
			}
			return false;										// report this is not a file
		}//_ if GO_UP
																// Not UP, is selection a dir
		if (isMarkedDir(fileName)) 								// if has (d), then is directory
		{
			fileName = stripDirMark(fileName);					// remove the (d)
			mProgramPath = new File(mProgramPath, fileName).getPath();	// add dir to path
			updateList();						// update the list
			return false;										// and report not a file
		}
		return true;											// if none of the above, it is a file
	}//_SelectionIsFile
//-------------------------------------------------
	private void FileLoader(String aFileName) {					// The user has selected a file to load, load it.

		Basic.clearProgram(); 				// Clear the old program
		Editor.DisplayText = "";			// Clear the display text buffer

		Editor.ProgramPath = mProgramPath;
		Editor.ProgramFileName = aFileName;

		String FullFileName = new File(mProgramPath, aFileName).getPath();

		ArrayList<String> lines = new ArrayList<String>();
		int size = Basic.loadProgramFileToList(true, FullFileName, lines);	// is full path to the file to load
		if (size == 0) {					// File not found - this should never happen
			// Turn the program file into an error message
			// and act as if we loaded a file.
			String msg = "! Load Error: " + quote(aFileName) + " not found";
			lines.add(msg);
			size = msg.length() + 1;
		}

		// The file is now loaded into a String ArrayList. Next we need to move
		// the lines into the Editor display buffer.

		Editor.DisplayText = Basic.loadProgramListToString(lines, size);
		Editor.InitialProgramSize = Editor.DisplayText.length();		// Save the initial size for changed check
		Editor.Saved = true;
		if (Editor.mText == null) {
			throw new RuntimeException("LoadFile: Editor.mText null");
		}
		Editor.mText.setText(Editor.DisplayText);
	}//_FileLoader
}//_LoadFile
