/****************************************************************************************************

BASIC! is an implementation of the Basic programming language for
Android devices.

Copyright (C) 2010 - 2016 Paul Laughton

This file is part of BASIC! for Android

    BASIC! is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    BASIC! is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with BASIC!.  If not, see <http://www.gnu.org/licenses/>.

    You may contact the author or current maintainers at http://rfobasic.freeforums.org

*************************************************************************************************/

package com.rfo.hbasic;

import static com.rfo.hbasic.Run.EventHolder.*;

import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;

import android.graphics.drawable.ColorDrawable;
import android.graphics.Paint;
import android.graphics.Canvas;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.graphics.Color;

import android.bluetooth.BluetoothAdapter;
import android.media.AudioManager;

import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.os.Handler;

import android.speech.RecognizerIntent;
import android.util.Log;

import android.view.KeyEvent;
import android.view.WindowManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Gravity;

import android.widget.FrameLayout;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;

import android.app.Activity;

public class GR extends Activity {
	private static final String LOGTAG = "GR";

	public static final String EXTRA_SHOW_DECORS = "decors";
	public static final String EXTRA_ORIENTATION = "orientation";
	public static final String EXTRA_BACKGROUND_COLOR = "background";
	public static final String EXTRA_WINDOWBG_COLOR = "window_bg";

	public static Object LOCK = new Object();
	public static boolean waitForLock = false;
	public static Context mContext;

	public static FrameLayout.LayoutParams commonParams =
					new FrameLayout.LayoutParams
						(	FrameLayout.LayoutParams.MATCH_PARENT,
							FrameLayout.LayoutParams.WRAP_CONTENT	);

	public static FrameLayout topLayout;
	public static DrawView drawView;
	public static Bitmap screenBitmap = null;
//	public static boolean NewTouch[] = {false, false};
//	public static double TouchX[] = {0,0};
//	public static double TouchY[] = {0,0};
	public static long Time = 0;
	public static int deltaTime = 0;

	public static float scaleX = 1f;
	public static float scaleY = 1f;
	public static boolean Running = false;		// set when Open object runs
	public static boolean NullBitMap = false;
	public static boolean BTsilent = false;

	private boolean mCreated = false;			// set when on Create is complete

	private boolean showStatusBar = true;
	private boolean showNavBar = true;
	private boolean darkStaText = false;			// dark status bar text
	private boolean darkNavText = false;			// dark nav bar text
	private	boolean showActionBar =	false;
	private boolean immersive = false;

	private View.OnSystemUiVisibilityChangeListener sysBarListener1 = null;
	private boolean restoringBars = false;
	public static boolean ignoreConfig = false;
	public static int gr_ORIENT = 0;		// -1=sensors 0=L 1=P 2=RL 3=RP

	public static Integer WindowBGColor = null;		// window background color
	public static String  TitleText = "Graphics";	// title (actionbar) text
	public static Integer TitleTextColor = null;	// title text color
	public static Integer TitleBackColor = null;	// title bg color
	public static String  TitleFont = null;			// title font
	public static Integer TitleAlign = null;		// title alignment
	public static String  TitleSubText = null;		// subtitle text
	public static Integer TitleSubColor = null;		// subtitle text color
	public static String  TitleSubFont = null;		// subtitle font

	public static Handler mHandler = null;			// GR post handler
//------------------------------------------------------
	public static String mErrorMsg="No Error";
	public static String ERR_COLOR = "Color not found";
//------------------------------------------
	public static boolean setError (String errMsg)
	{
		mErrorMsg = errMsg;
		return false;
	}//_setError
//------------------------------------------
	public static void defaultVars ()		// default vars for new a run
	{
		TitleText = "Graphics";
		TitleTextColor = null;	TitleBackColor = null;
		TitleFont = null;		TitleAlign = null;
		TitleSubText = null;	TitleSubColor = null;
		TitleSubFont = null;
	}//_defaultVars
//------------------------------------------------------
	public static void setTitle(String title) {TitleText=title; setStyling();}

	public static void setStyling ()		// change activity styling
	{
		if (mHandler==null || GR.mContext==null) return;	// sanity check
		mHandler.post( new Runnable() { @Override public void run()
		{
			Astyle.SetStyling (GR.mContext,
				TitleText, TitleTextColor, TitleBackColor,
				TitleFont, TitleAlign,
				TitleSubText, TitleSubColor, TitleSubFont,
				WindowBGColor
			);
		}});
	}//_setStyling
//------------------------------------------------------
	private void restoreBars()			// restore bars after a swipe
	{
		if (restoringBars)  return;		// don't overlap
		restoringBars = true;

		Handler handler = new Handler();
		Runnable r = new Runnable()
		{
			@Override
		    public void run()
			{
				Astyle.setStatusBar(GR.this, showStatusBar);// restore statusbar to default state
				Astyle.setNavBar (GR.this, showNavBar);		// restore navbar to default state
				restoringBars = false;	// done
			}
		};
		handler.postDelayed(r, 3000);
	}//_restoreBars()
//------------------------------------------------------
	private void install_BarListener()					// listen for bar changes
	{
		if (Build.VERSION.SDK_INT > 29) return;			// only for < Android 11
		if (sysBarListener1 != null) return;			// don't install twice

		sysBarListener1 = new View.OnSystemUiVisibilityChangeListener()
		{
			@Override
			public void onSystemUiVisibilityChange(int visibility)
			{
				boolean SysBarInCall =
				(!showStatusBar && ((visibility & View.SYSTEM_UI_FLAG_FULLSCREEN)==0))
				||
				(!showNavBar && ((visibility & View.SYSTEM_UI_FLAG_HIDE_NAVIGATION)==0))
				;
				if (SysBarInCall) restoreBars();
			}
		};//_sysBarListener1
		final View decor = getWindow().getDecorView();
		decor.setOnSystemUiVisibilityChangeListener(sysBarListener1);
	}//_install_BarListener
//------------------------------------------------------
	private void setSystemBars ()		// set system bars to current states
	{
		Astyle.fixSysBars		(this, immersive);
		Astyle.setStatusBar		(this, showStatusBar);
		Astyle.setNavBar		(this, showNavBar);
		Astyle.setDarkStaText	(this, darkStaText);
		Astyle.setDarkNavText	(this, darkNavText);
		Astyle.setActionBar		(this);
	}//_setSystemBars
//------------------------------------------------------
	public void openMenu()						// open menu
	{
		if (!showActionBar) return;			// do nothing if no actionbar
		Runnable r = new Runnable()
		{
			@Override
		    public void run()
			{
				openOptionsMenu ();
			}
		};
		mHandler.post(r);
	}//_openMenu
//------------------------------------------------------
	@Override
	public void onCreate(Bundle savedInstanceState) {
//		Log.d(LOGTAG, "GR.onCreate");
		super.onCreate(savedInstanceState);

		ContextManager cm = Basic.getContextManager();
		if (cm == null) {Log.e(LOGTAG, "GR.onCreate: Lost context."); finish(); return;}
		cm.registerContext(ContextManager.ACTIVITY_GR, this);
		cm.setCurrent(ContextManager.ACTIVITY_GR);
		mContext = this;									// keep a copy
		Intent intent = getIntent();
		Basic.installOnBackPressed(this);

		int flags = intent.getIntExtra(EXTRA_SHOW_DECORS, 1);
		showStatusBar		= (flags & 1)==1;				// -humpty 0409
		showActionBar		= (flags & 2)==2;
		showNavBar			= (flags & 4)==0;				// navbar inverts
		darkStaText			= (flags & 8)==8;
		darkNavText			= (flags & 16)==16;
		immersive			= (flags & 32)==32;
		int backgroundColor	= intent.getIntExtra(EXTRA_BACKGROUND_COLOR, 0xFF000000);
		WindowBGColor		= intent.getIntExtra(EXTRA_WINDOWBG_COLOR, 0xFF000000);
		gr_ORIENT			= intent.getIntExtra(EXTRA_ORIENTATION, -1);

		mHandler = new Handler();
		ignoreConfig = false;
		scaleX = 1.0f;
		scaleY = 1.0f;

		setVolumeControlStream(AudioManager.STREAM_MUSIC);
		setRequestedOrientation(Settings.getOrientCode(gr_ORIENT));

		if (immersive) setTheme (R.style.Immersive_Theme);
		else if (!showStatusBar) setTheme (R.style.Full_Theme);

		setStyling();
		if (showActionBar)							// show actionbar if wanted
		{
			getActionBar().addOnMenuVisibilityListener(Run.menu_Listener());
			getActionBar().show();
		}
		else getActionBar().hide();

		setSystemBars();
		if (!showStatusBar || !showNavBar)
			install_BarListener();			// listen for bar changes if needed

		drawView = new DrawView(this);
		drawView.requestFocus();
		drawView.setBackgroundColor(backgroundColor);

		setContentView(R.layout.gr);
		topLayout = findViewById(R.id.top_layout);
		topLayout.setFitsSystemWindows(!immersive);

		topLayout.addView(drawView,commonParams);

		synchronized (drawView) {
			mCreated = true;
		}
	}//_onCreate
//--------------------------------------------------
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{		// Called when the menu key is pressed.
		super.onCreateOptionsMenu(menu);
		if (!Settings.getConsoleMenu(this)) { return false; }

		Run.menu_copy (Run.UserMenu, menu);			// copy the Run menu
		return true;
	}//_onCreateOptionsMenu
//--------------------------------------------------
	@Override
	public boolean onPrepareOptionsMenu(Menu menu) 	// Executed when Menu key is pressed (before onCreateOptionsMenu() above.
	{
		super.onPrepareOptionsMenu(menu);
		invalidateOptionsMenu();					// force an update
		Run.ItemSelected = false;
		return true;
	}//_onPrepareOptionsMenu
//--------------------------------------------------
	@Override
	public boolean onOptionsItemSelected(MenuItem item) // A menu item is selected
	{
		Menu rM = Run.mMenu;
		rM.performIdentifierAction(item.getItemId(), 0);	// activate Run item
		Run.ItemSelected = true;
		return true;
	}//_onOptionsItemSelected
//--------------------------------------------------
	@Override
	protected void onStart() {
		super.onStart();
//		Log.v(LOGTAG, "GR.onStart");
	}

	@Override
	protected void onResume() {
//		Log.v(LOGTAG, "GR.onResume " + this.toString());

		ContextManager cm = Basic.getContextManager();
		if (cm == null) {Log.e(LOGTAG, "GR.onResume: Lost context."); finish(); return;}
		if (mContext != this) {
			Log.d(LOGTAG, "GR.onResume> Context changed from " + mContext + " to " + this);
			mContext = this;
			cm.registerContext(ContextManager.ACTIVITY_GR, this);
		}
		cm.onResume(ContextManager.ACTIVITY_GR);
		Run.mEventList.add(new Run.EventHolder(GR_STATE, ON_RESUME, null));
		if (Run.runDIALOG == null && !Run.setDIALOG) Run.releaseLOCK();
		super.onResume();
	}//_onResume

	@Override
	protected void onPause() {
//		Log.v(LOGTAG, "GR.onPause " + this.toString());
		ContextManager cm = Basic.getContextManager();
		if (cm == null) {Log.e(LOGTAG, "GR.onPause: Lost context."); finish(); return;}
		cm.onPause(ContextManager.ACTIVITY_GR);
		Run.mEventList.add(new Run.EventHolder(GR_STATE, ON_PAUSE, null));
		if (drawView.mKB != null) { drawView.mKB.forceHide(); }
		super.onPause();
	}//_onPause

	protected void onStop() {
//		Log.v(LOGTAG, "GR.onStop");
		super.onStop();
	}

	@Override
	protected void onRestart() {
		super.onRestart();
//		Log.v(LOGTAG, "GR.onRestart");
	}

	@Override
	public void finish() {
//		Log.d(LOGTAG, "GR.finish >" + this.toString());
		// Tell the ContextManager we're done, if it doesn't already know.
		ContextManager cm = Basic.getContextManager();
		if (cm != null) cm.unregisterContext(ContextManager.ACTIVITY_GR, this);
		super.finish();
	}

	@Override
	protected void onDestroy() {
//		Log.v(LOGTAG, "GR.onDestroy >" + this.toString());
		// if a new instance has started, don't let this one mess it up
		if (mContext == this) {
			Running = mCreated = false;
			mContext = null;
			releaseLOCK();								// don't leave GR.command hanging
		}
		super.onDestroy();
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig)
	{
//		Log.d(LOGTAG, "GR.onConfig> OnOrientation");
		super.onConfigurationChanged(newConfig);
		if (gr_ORIENT > -1) return;
		Run.ignoreConfig = Web.ignoreConfig = true;
		ignoreConfig= Basic.onOrientChange (GR.drawView, newConfig, ignoreConfig);
	}//_onConfigurationChanged

	@Override
	public void onBackPressed() {
//		Log.d(LOGTAG, "GR.onBackPressed >");

		if (Run.runDIALOG !=null) { Run.runDIALOG.cancel(); return; }
		if (TGet.in_TGET) { TGet.tGet_done(String.valueOf((char)0)); return; }

		Run.mEventList.add(new Run.EventHolder(GR_BACK_KEY_PRESSED, 0, null));
		if (Run.Notified==-1) Run.Notified = 1;
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// Log.v(LOGTAG, "keyDown " + keyCode);
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			return super.onKeyDown(keyCode, event);
		}
		if (!Run.mBlockVolKeys && (
				(keyCode == KeyEvent.KEYCODE_VOLUME_UP)   ||
				(keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) ||
				(keyCode == KeyEvent.KEYCODE_VOLUME_MUTE) ||
				(keyCode == KeyEvent.KEYCODE_MUTE)        ||
				(keyCode == KeyEvent.KEYCODE_HEADSETHOOK) ))
		{
			return super.onKeyDown(keyCode, event);
		}
		if (keyCode == KeyEvent.KEYCODE_MENU) {
			// Do not put the KeyEvent on the EventList.
			// This keeps Run.onKeyDown() from building a menu.
			Run.mEventList.add(new Run.EventHolder(KEY_DOWN, keyCode, null));
		}
		return true;									// ignore anything else
	}

	public boolean onKeyUp(int keyCode, KeyEvent event)  {	// The user hit a key
		// Log.v(LOGTAG, "keyUp " + keyCode);
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			return super.onKeyUp(keyCode, event);
		}
		if (keyCode == KeyEvent.KEYCODE_MENU) {
			// Do not put the KeyEvent on the EventList.
			// This keeps Run.onKeyDown() from building a menu.
			event = null;
		}
		Run.mEventList.add(new Run.EventHolder(KEY_UP, keyCode, event));
		return true;
	}

	public void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		switch (requestCode)
		{
			case Run.REQUEST_CONNECT_DEVICE_SECURE:
				// When DeviceListActivity returns with a device to connect
				Run.connect_BTresult (resultCode, data, true);
				break;
			case Run.REQUEST_CONNECT_DEVICE_INSECURE:
				// When DeviceListActivity returns with a device to connect
				Run.connect_BTresult (resultCode, data, false);
				break;
			case Run.REQUEST_ENABLE_BT:
				// When the request to enable Bluetooth returns
				if (resultCode == Activity.RESULT_OK) {
					// Bluetooth is now enabled, so set up a chat session
					Run.bt_enabled = 1;
				} else {
					Run.bt_enabled = -1;
				}
				break;
			case Run.VOICE_RECOGNITION_REQUEST_CODE:
				if (resultCode == RESULT_OK) {
					Run.sttResults = new ArrayList<String>();
					Run.sttResults = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
				}
				Run.sttDone = true;
		}//_switch
	}//_onActivityResult
//-----------------------------------------
	private void condReleaseLOCK()			// conditionally release LOCK
	{
		if (mCreated & Running) { releaseLOCK(); }
	}//_condReleaseLOCK

	private void releaseLOCK()				// unconditionally release LOCK
	{
		if (waitForLock) {
			synchronized (LOCK) {
				waitForLock = false;
				LOCK.notify();	// release GR.OPEN or .CLOSE if it is waiting
			}
		}
	}//_releaseLOCK
//--------------------------------------------------
	public class DrawView extends View {
		private static final String LOGTAG = "GR.DrawView";

		public KeyboardManager mKB;

		@SuppressLint("NewApi")
		public DrawView(Context context) {
			super(context);
			setFocusable(true);
			setFocusableInTouchMode(true);
			mKB = new KeyboardManager(context, this, new KeyboardManager.KeyboardChangeListener() {
				public void kbChanged() {
					Run.mEventList.add(new Run.EventHolder(GR_KB_CHANGED, 0, null));
				}
			});

//			if (Build.VERSION.SDK_INT >= 11) {				// Hardware acceleration is supported starting API 11
				// Assume hardware acceleration is enabled for the app.
				// Choose whether to use it in DrawView based on user Preference.
				int layerType = Settings.getGraphicAcceleration(context)
								? View.LAYER_TYPE_HARDWARE	// use hardware acceleration
								: View.LAYER_TYPE_SOFTWARE;	// disable hardware acceleration
				setLayerType(layerType, null);
//			}
			Time = SystemClock.elapsedRealtime();
		}//_DrawView

		@Override
		public boolean onKeyPreIme(int keyCode, KeyEvent event) {
			return (mKB != null) && mKB.onKeyPreIme(keyCode, event); // delegate to KeyboardManager
		}

		public boolean onTouchEvent(MotionEvent event) {

			super.onTouchEvent(event);

			int action = event.getAction() & MotionEvent.ACTION_MASK;	// Get action type, mask off index field
			int numPointers = event.getPointerCount();

			for (int i = 0; i < numPointers; i++) {
				int pid = event.getPointerId(i);
				if (pid > 1)  { continue; }				// currently, we allow only two pointers

				Run.TouchX[pid] = (double)event.getX(i);
				Run.TouchY[pid] = (double)event.getY(i);
				if (action == MotionEvent.ACTION_DOWN ||
					action == MotionEvent.ACTION_POINTER_DOWN) {
					Run.NewTouch[pid] = true;			// which pointer (0 or 1), cleared on UP
					Run.mEventList.add(new Run.EventHolder(GR_TOUCH, 0, null));
				}
				else if	(action == MotionEvent.ACTION_MOVE) {
					Run.NewTouch[pid] = true;
				} else if (action == MotionEvent.ACTION_UP ||
					action == MotionEvent.ACTION_POINTER_UP) {
					Run.NewTouch[pid] = false;
				}
			}
			return true;
		}

		public Paint newPaint(Paint fromPaint) {
			Typeface tf = fromPaint.getTypeface();
			Paint rPaint = new Paint(fromPaint);
			rPaint.setTypeface(tf);
			return rPaint;
		}

		@Override
		synchronized public void onDraw(Canvas canvas)
		{

			if ((Run.RealDisplayList == null) || (Run.DisplayList == null)) {
				Log.d(LOGTAG, "GR.onDraw: null DisplayList");
				finish();			// lost context, bail out
				return;
			}

			// float scale = getResources().getDisplayMetrics().density;
			// drawView.setDrawingCacheEnabled(true);		// deprecated api 28
			canvas.scale(scaleX, scaleY);
			synchronized (Run.DisplayList) {
				for (int di : Run.RealDisplayList) {
					if (di<0 || di >= Run.DisplayList.size()) continue;
					BDraw b = Run.DisplayList.get(di);

					doDraw(canvas, b);

					if (!Running) {finish(); break;}
				}//_for
				condReleaseLOCK();
			}//_sync
		} // onDraw()

		public void doDraw(Canvas canvas, BDraw b)
		{
			Paint thePaint = null;
			BDraw.Type type = BDraw.Type.Null;

			if (b==null || b.isHidden()) return;
			type = b.type();

			int pIndex = b.paint();
			if (Run.PaintList.size() == 0)						return;
			if (pIndex < 1 || pIndex >= Run.PaintList.size())	return;

			thePaint = Run.PaintList.get(pIndex);
			int alphaO = (int)b.alpha();
			int alphaP  = thePaint.getAlpha();
			boolean useO = (alphaO < 256) && (alphaO != alphaP);
			if (useO) thePaint.setAlpha(alphaO);

			type.mRender.render(b, canvas, thePaint);	// execute render

			if (useO) thePaint.setAlpha(alphaP);
		} // doDraw()

	} // class DrawView

// ************************************** Colors & Utilities **************************************

	private static final	String colorNames[] = {"acidgreen","algaegreen","aliceblue","aliengray","aliengreen","aloeveragreen","antiquebronze","antiquewhite","aqua","aquamarine","aquamarinestone","armybrown","armygreen","ashgray","ashwhite","avocadogreen","aztechpurple","azure","azureblue","babyblue","babypink","bakersbrown","balloonblue","bananayellow","bashfulpink","basketballorange","battleshipgray","beanred","beer","beetlegreen","beeyellow","beige","bisque","black","blackbean","blackcat","blackcow","blackeel","blanchedalmond","blonde","bloodnight","bloodred","blossompink","blue","blueangel","blueberryblue","bluediamond","bluedress","blueeyes","bluegray","bluegreen","bluehosta","blueivy","bluejay","bluekoi","bluelagoon","bluelotus","bluemossgreen","blueorchid","blueribbon","blueturquoise","blueviolet","bluewhale","bluezircon","blushpink","blushred","boldyellow","brass","brightblue","brightcyan","brightgold","brightgreen","brightlilac","brightmaroon","brightnavyblue","brightneonpink","brightorange","brightpurple","brightturquoise","bronze","brown","brownbear","brownsand","brownsugar","bulletshell","burgundy","burlywood","burntpink","butterflyblue","cadetblue","cadillacpink","camelbrown","camouflagegreen","canaryblue","canaryyellow","cantaloupe","caramel","carbongray","carbonred","cardboardbrown","carnationpink","carrotorange","celeste","chameleongreen","champagne","charcoal","chartreuse","cherryred","chestnut","chestnutred","chillipepper","chocolate","chocolatebrown","cinnamon","clemantisviolet","cloudygray","clovergreen","cobaltblue","coffee","columbiablue","constructionconeorange","cookiebrown","copper","copperred","coral","coralblue","cornflowerblue","cornsilk","cornyellow","cotton","cottoncandy","cranberry","cream","crimson","crimsonpurple","crocuspurple","crystalblue","cyan","cyanopaque","darkbisque","darkblue","darkbluegrey","darkbrown","darkcarnationpink","darkcoffee","darkcyan","darkforestgreen","darkgoldenrod","darkgray","darkgreen","darkgrey","darkhotpink","darkkhaki","darklimegreen","darkmagenta","darkmint","darkmoccasin","darkolivegreen","darkorange","darkorchid","darkpink","darkpurple","darkred","darksalmon","darkseagreen","darksienna","darkslate","darkslateblue","darkslategray","darkslategrey","darkturquoise","darkviolet","darkyellow","dayskyblue","deepemeraldgreen","deepmauve","deeppeach","deeppink","deeppurple","deepred","deeprose","deepsea","deepseablue","deepseagreen","deepskyblue","deepteal","deepturquoise","deepyellow","deerbrown","denimblue","denimdarkblue","desertsand","dimgray","dimgrey","dimorphothecamagenta","dinosaurgreen","dodgerblue","dollarbillgreen","donutpink","dragongreen","dullgreenyellow","dullpurple","dullseagreen","earthblue","earthgreen","eggplant","eggshell","electricblue","emerald","emeraldgreen","fallforestgreen","fallleafbrown","ferngreen","ferrarired","firebrick","fireenginered","flamingopink","floralwhite","forestgreen","frenchlilac","froggreen","fuchsia","gainsboro","ghostwhite","gingerbrown","glacialblueice","gold","goldenbrown","goldenrod","goldensilk","goldenyellow","granite","grape","grapefruit","gray","graybrown","graycloud","graydolphin","graygoose","grayishturquoise","graywolf","green","greenapple","greenishblue","greenonion","greenpeas","greenpepper","greensnake","greenthumb","greenyellow","grey","gulfblue","gunmetal","halloweenorange","harvestgold","hazel","hazelgreen","heavenlyblue","heliotropepurple","honeydew","hotdeeppink","hotpink","hummingbirdgreen","iceberg","iguanagreen","indianred","indigo","iridium","irongray","ivory","jadegreen","jasminepurple","jeansblue","jellyfish","jetgray","junglegreen","kellygreen","khaki","khakirose","lapisblue","lavared","lavender","lavenderblue","lavenderblush","lavenderpinocchio","lavenderpurple","lawngreen","lemonchiffon","lightaquamarine","lightblue","lightbrown","lightcopper","lightcoral","lightcyan","lightdayblue","lightfrenchbeige","lightgoldenrodyellow","lightgray","lightgreen","lightgrey","lightjade","lightorange","lightpink","lightpurple","lightpurpleblue","lightred","lightrose","lightrosegreen","lightsalmon","lightsalmonrose","lightseagreen","lightskyblue","lightslate","lightslateblue","lightslategray","lightslategrey","lightsteelblue","lightwhite","lightyellow","lilac","lime","limegreen","limemintgreen","linen","lipstickpink","lovelypurple","lovered","macaroniandcheese","macawbluegreen","magenta","magicmint","mahogany","mangoorange","marbleblue","maroon","mauve","mauvetaupe","mediumaquamarine","mediumblue","mediumforestgreen","mediumorchid","mediumpurple","mediumseagreen","mediumslateblue","mediumspringgreen","mediumteal","mediumturquoise","mediumvioletred","metallicgold","metallicsilver","middayblue","midnight","midnightblue","milkchocolate","milkwhite","mint","mintcream","mintgreen","mistblue","mistyrose","moccasin","mocha","mustardyellow","navajowhite","navy","nebulagreen","neonblue","neongreen","neonorange","neonpink","newmidnightblue","night","nightblue","northernlightsblue","oakbrown","oceanblue","offwhite","oil","oldburgundy","oldlace","olive","olivedrab","olivegreen","orange","orangegold","orangered","orangesalmon","orangeyellow","orchid","orchidpurple","organicbrown","palebluelily","palegoldenrod","palegreen","palelilac","palesilver","paleturquoise","palevioletred","papayaorange","papayawhip","parchment","parrotgreen","pastelblue","pastelgreen","pastellightblue","pastelorange","pastelpink","pastelpurple","pastelred","pastelviolet","pastelyellow","peach","peachpuff","peagreen","pearl","periwinkle","peru","pigpink","pinegreen","pink","pinkbrown","pinkbubblegum","pinkcoral","pinkcupcake","pinkdaisy","pinklemonade","pinkplum","pinkrose","pinkviolet","pistachiogreen","platinum","platinumgray","platinumsilver","plum","plumpie","plumpurple","plumvelvet","powderblue","puce","pumpkinorange","purple","purpleamethyst","purpledaffodil","purpledragon","purpleflower","purplehaze","purpleiris","purplejam","purplelily","purplemaroon","purplemimosa","purplemonster","purplenavy","purplepink","purpleplum","purplesagebush","purplethistle","purpleviolet","ratgray","rebeccapurple","red","redblood","reddirt","redfox","redwine","rice","richlilac","robineggblue","roguepink","romansilver","rose","rosedust","rosegold","rosered","rosybrown","rosyfinch","rosypink","royalblue","rubberduckyyellow","rubyred","rust","saddlebrown","saffron","sage","sagegreen","saladgreen","salmon","sand","sandstone","sandybrown","sangria","sapphireblue","scarlet","schoolbusyellow","seablue","seafoamgreen","seagreen","seashell","seaturtlegreen","seaweedgreen","sedona","sepia","shamrockgreen","shockingorange","sienna","silkblue","silver","silverpink","skyblue","skybluedress","slateblue","slatebluegrey","slategranitegray","slategray","slategrey","slimegreen","smokeygray","snow","softivory","sonicsilver","springgreen","steelblue","stoplightgogreen","sunriseorange","sunyellow","tan","tanbrown","tangerine","taupe","teagreen","teal","thistle","tiffanyblue","tigerorange","tomato","tronblue","tulippink","turquoise","tyrianpurple","unbleachedsilk","valentinered","vampiregray","vanilla","velvetmaroon","venomgreen","violapurple","violet","violetred","water","watermelonpink","wheat","white","whitechocolate","whitesmoke","windowsblue","winered","wisteriapurple","wood","yellow","yellowgreen","yellowgreengrosbeak","yellowlawngreen","yelloworange","zombiegreen"};
	private static final	int colorInts[] = {11583258,6613382,15792383,7565166,7128087,10024214,6708510,16444375,65535,8388564,3442561,8551264,4936480,6710114,15328468,11715144,8993791,15794175,4744096,9812423,16428986,6042391,2842846,16114198,12735107,16286040,8684674,16211289,16494871,5011582,15313687,16119260,16770244,0,4000770,4274233,4998726,4603455,16772045,16512729,5576198,8271127,16365567,255,12046060,16834,5169900,1408492,1403335,10006471,8113333,7847879,3182791,2839678,6659783,9366508,6906092,3954267,2049532,3174143,4441819,9055202,3419518,5766911,15116780,15036052,16374564,11904578,592383,720895,16633879,6749952,14193135,12788040,1668306,16004095,16736031,6950317,1499893,13467442,10824234,8608827,15637069,14853999,11508576,9175066,14596231,12657255,3714284,6266528,14912174,12687979,7898731,2692853,16772864,16754223,13012503,6446429,10947882,15587956,16218273,16285719,5303276,12449046,16246734,3418156,8388352,12731969,9782581,12798508,12655383,13789470,4128783,12945687,8662478,7170408,4104277,8386,7294519,8892359,16282673,13083415,12088115,13331793,16744272,11525356,6591981,16775388,16774016,16514041,16572415,10420239,16777164,14423100,14825708,9532140,6075391,65535,9619399,12084480,139,2704987,6636321,12657283,3878703,35723,2441495,12092939,11119017,25600,11119017,16146603,12433259,4301591,9109643,3248238,8550457,5597999,16747520,10040012,15160448,4915536,9109504,15308410,9419919,9060631,2832470,4734347,2439228,2439228,52945,9699539,9142272,8571647,287495,14644180,16763812,16716947,3539263,8389911,16497593,3906716,1193046,3172180,49151,212542,4771021,16170496,15122307,7977708,1383309,15583663,6908265,6908265,14889373,7577964,2003199,8764261,16428990,7011218,11664151,8344157,5146997,165,3450223,6373457,16775651,10157823,5294200,6290199,5149272,13153632,6716454,16190746,11674146,16132119,16361392,16775920,2263842,8806542,10077838,16711935,14474460,16316671,13221474,3574721,16766720,15384855,14329120,15983555,16768768,8617596,6183552,14432287,8421504,4011573,11974324,6051928,13750478,6192510,5261899,32768,5030935,3177854,6988065,9028444,4890668,7125820,11922090,11403055,8421504,13230060,2897209,15100972,15590005,9336344,6388824,13033215,13918975,15794160,16066695,16738740,8382487,5678572,10268785,13458524,4915330,4013114,5396829,16777200,6224750,10632172,10538988,4638663,6385022,3439660,5031250,15787660,12947598,1388926,14950935,15132410,14935290,16773365,15457762,9862070,8190976,16775885,9699304,11393254,11887901,14322279,15761536,14745599,11395071,13151615,16448210,13882323,9498256,13882323,12844472,16701617,16758465,8677335,7507918,16764107,16502733,14416347,16752762,16356971,2142890,8900346,13434879,7564031,7833753,7833753,11587550,16777207,16777184,13148872,65280,3329330,3601791,16445670,12879763,8337644,14949143,15907686,4440007,16711935,11202769,12599296,16744512,5664126,8388608,14725375,9527149,6737322,205,3437109,12211667,9662683,3978097,8087790,64154,286559,4772300,13047173,13938487,12371660,3914239,2824983,1644912,5323548,16710911,4109449,16121850,10026904,6581630,16770273,16770229,4799782,16767832,16768685,128,5892119,1411583,1504553,16738048,16070058,160,788746,1383252,7915463,8414487,2844140,16314595,3879217,4403246,16643558,8421376,7048739,12236908,16753920,13934615,16729344,12874833,16756290,14315734,11552949,14940582,13626604,15657130,10025880,14471423,13222075,11529966,14381203,15034135,16773077,16777154,1223979,11849708,7855479,14014186,16300171,16688042,15901416,16151168,13799868,16447620,16770484,16767673,5427223,16641780,15323116,13468991,16635876,3701828,16761035,12878217,16768989,15168625,14966429,15178147,14952572,12139407,15180208,13247083,10338825,15066338,7960953,13553358,14524637,8193345,5781337,8193362,11591910,8346200,16282135,8388736,7089607,11551231,12816071,10963655,5126270,5708670,6957182,5573173,8455489,10386431,4594558,5132672,13723015,9319919,8019399,13810131,9255113,7175053,6697881,16711680,6684672,8344087,12802071,10027026,16446959,11953874,12447231,12658793,8620438,15248810,10055792,15517120,12721750,12357519,8343122,11764865,4286945,16766977,16130583,12804673,9127187,16496919,12368010,8686457,10602805,16416882,12759680,7892319,16032864,8271895,2446535,16720896,15246103,12771327,4106655,3050327,16774638,4427136,4422679,13395456,8341036,3439639,15031100,10506797,4754119,12632256,12889773,8900331,6723839,6970061,7568545,6648707,7372944,7372944,12380500,7499373,16775930,16445661,7697781,65407,4620980,5761380,15103057,16771196,13808780,15525302,15174241,4734002,13433693,32896,14204888,8509648,13140289,16737095,8257022,12737148,4251856,12868332,16768458,15029329,5656657,15984043,8271181,7506944,8280190,15631086,16135562,15463674,16542853,16113331,16777215,15591126,16119285,3505863,10027026,13020871,9858867,16776960,10145074,14873878,8910615,16756290,5555569};
	private static final	int csize = colorNames.length;

//--------------------------------------------
	public static Bitmap getBitMap(int index)		// get Bitmap from BitmapList
	{												// null => error
		if (index < 0 || index >= Run.BitmapList.size()) return null;
		Bitmap bmp = Run.BitmapList.get(index);
		if (bmp == null || bmp.isRecycled()) return null;
		return bmp;
	}//_getBitMap
//--------------------------------------------
	public static Bitmap[] getAnim (int index)	// get Anim from AniList
	{											// null => error
		if (index < 1 || index >= Run.AnimList.size()) return null;
		Bitmap[] farray = Run.AnimList.get(index);
		return farray;							// could be null
	}//_getAnim
//--------------------------------------------
	public static Integer findColor (String s)	// find a color string
											// 		string "#RRGGBB"
											// or	string "#AARRGGBB"
											// or 	string "color_name {<.|#>alpha>}"
		// not supported yet -->				// or   string ".r.g.b"
											// return null if error
	{
		int alpha = 0xFF000000;				// default solid
		int len = s.length();
		int found = 0, i = 0;
		String num = "";
		boolean err = false;

		if (len < 1) return null;
		if (s.charAt(0) == '#')				// -humpty 0330 if this is a hex color
		{
			try	{ found = Color.parseColor(s);}
			catch (IllegalArgumentException ex) {err=true;}
			if (err) return null;			// hex color not found
			return (Integer) found;			// found hex color
		}
		if ( (i=s.lastIndexOf('#')) > 0)	// hex aplha ?
		{
			num = s.substring(i+1);
			try	{alpha = Integer.parseInt (num,16);}
				catch (NumberFormatException ex) {return null;}
			alpha <<= 24;
			s = s.substring(0,i);			// cut off aplha
		}   
		else 
		if ( (i=s.lastIndexOf('.')) > 0)	// dec alpha ?
		{
			num = s.substring(i+1);
			try	{alpha = Integer.parseInt (num);}
				catch (NumberFormatException ex) {return null;}
			alpha <<= 24;
			s = s.substring(0,i);			// cut off aplha
		}

		i =	Basic.bSearch (colorNames, s);
		if (i<0) return null;				// not found

		found = alpha | colorInts[i];
		return (Integer) found;
	}//_findColor
//--------------------------------------------
										// get color string to array
	public static boolean color2Array (String s, int[] args)
	{
		Integer f_Int = findColor(s);
		if ((f_Int) == null) return false;
		int color = (int) f_Int;
		args[0] = 255 & (color >>> 24);
		args[1] = 255 & (color >>> 16);
		args[2] = 255 & (color >>> 8);
		args[3] = 255 & (color);
		return true;
	}//color2Array
//--------------------------------------------
}//_GR
