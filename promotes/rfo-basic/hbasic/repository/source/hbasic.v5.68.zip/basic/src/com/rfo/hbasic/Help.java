/****************************************************************************************************

BASIC! is an implementation of the Basic programming language for
Android devices.

Copyright (C) 2010 - 2014 Paul Laughton

This file is part of BASIC! for Android

    BASIC! is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    BASIC! is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with BASIC!.  If not, see <http://www.gnu.org/licenses/>.

    You may contact the author or current maintainers at http://rfobasic.freeforums.org

*************************************************************************************************/

package com.rfo.hbasic;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import com.rfo.hbasic.Basic.ColoredTextAdapter;
import com.rfo.hbasic.Basic.TextStyle;

import android.app.Activity;
import android.content.res.Configuration;
import android.content.Context;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Build;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;


// Called from Editor when user selected Menu->Commands
// Displays command list residing in f01_commands.bas

public class Help extends Activity
{
	private ListView lv;
	private Basic.mOutputArray<String> output = new Basic.mOutputArray<String>();
	private static final String Chars = "abcdefghijklmnopqrstuvwxyz";
	private InputMethodManager IMM=null;
	private boolean showKB = true;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setRequestedOrientation(Settings.getScreenOrientation(this));

		TextStyle style = new TextStyle(Basic.defaultTextStyle, Typeface.MONOSPACE);
		ColoredTextAdapter AA = new ColoredTextAdapter(this, output, style);

		setContentView(R.layout.help);
		lv = (ListView)findViewById(R.id.commands); 
		lv.setAdapter(AA);
		lv.setTextFilterEnabled(false);
		lv.setBackgroundColor(AA.getBackgroundColor());
		lv.setFastScrollEnabled(true);	// -humpty 0313 fast scroll if list is 4x+ screenheight

		Astyle.SetTitle (this, getResources().getString(R.string.help_name));

		String commandFile = "f01_commands.bas";
		InputStream inputStream = null;
		try { inputStream = Basic.streamFromResource(Basic.SOURCE_SAMPLES_PATH, commandFile); }
		catch (Exception ex) { }

		if (inputStream != null) {
			InputStreamReader inputreader = new InputStreamReader(inputStream);
			BufferedReader buffreader = new BufferedReader(inputreader, 8192);
			String line;

			try {
				while ((line = buffreader.readLine()) != null) {// Read one line at a time
					output.add(line);
				}
			} catch (IOException e1) {
				output.add("Error reading command list " + commandFile);
				Basic.closeStreams(buffreader, null);
			}
		} else {
			output.add("Command list " + commandFile + " not found");
		}
		lv.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
																// If a line is clicked on
				String command = output.get(position);			// Get the command
				int index = command.lastIndexOf (",");			// trim off the page number
				if (index >= 0) command = command.substring(0, index);

				ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
//				clipboard.setText(command);						// Put the user expression into the clipboard
				ClipData clip = ClipData.newPlainText("clipboard", command);
				clipboard.setPrimaryClip(clip);
				finish();										// Exit back to Editor
			}
		});
		lv.setFocusable (true);
		lv.setFocusableInTouchMode (true);
		IMM = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
	}//_onCreate

	@Override
	public void onConfigurationChanged(Configuration newConfig)
	{
		super.onConfigurationChanged(newConfig);
		IMM.hideSoftInputFromWindow(lv.getWindowToken(), 0);
	}//_onConfigurationChanged

	@Override
	public void onWindowFocusChanged (boolean hasFocus)
	{
		super.onWindowFocusChanged(hasFocus);
		if (!hasFocus || !showKB) return;
		lv.requestFocus();
		lv.postDelayed(new Runnable()
		{
		 @Override
		 public void run()
		 {
			if (lv==null) return;
			IMM.showSoftInput(lv, InputMethodManager.SHOW_IMPLICIT);
		 }//_run
		},100);//_postDelayed
		showKB=false;			// only show once
	}//_onWindowFocusChanged

	@Override
	public boolean onKeyUp(int keyCode, KeyEvent event) {
		
		int n;
		char theChar;
//		int index = 0;

		if (keyCode >=29 && keyCode <= 54){
			n = keyCode -29;
			theChar = Chars.charAt(n);
			int z = output.size();
			for (int i = 0; i < z; ++i)
			{
				String line = output.get(i);
				char c = line.charAt(0);
				c = Character.toLowerCase(c);
								// goto char or nearest
				if ( (c == theChar) || (c>theChar) || i==z-1 )
				{
					lv.setSelection(i);
//					lv.smoothScrollToPosition(i);
					break;
				}// if found
//				index = index + line.length();
			}//_for
		}//_if
		return super.onKeyUp(keyCode, event);
	}//_onKeyUp
}//_Help
