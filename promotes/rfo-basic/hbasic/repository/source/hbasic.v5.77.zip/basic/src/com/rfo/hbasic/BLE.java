/*
	Bluetooth Low Energy (BLE) support

	from: grauBasic	https://grauonline.de/wordpress/?page_id=2673
	ack:  greymfm76	https://www.tapatalk.com/groups/rfobasic/bluetooth-low-energy-ble-support-t5472.html#p39432
	Modified by humpty Oct 2026 - Added teasers.
*/

package com.rfo.hbasic;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;

import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanRecord;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.ParcelUuid;
import android.util.Log;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class BLE
{
    private Activity mActivity;
    private static final String TAG = "BLE> ";
	private boolean DEBUG = false;

    private static final int REQUEST_ENABLE_BT = 1;
    private static final long SCAN_PERIOD = 10000;
    private static String NOTIFICATION_UUID = "00002902-0000-1000-8000-00805f9b34fb";

    public static final int STATE_DISCONNECTED = 0;
    public static final int STATE_CONNECTING   = 2;
    public static final int STATE_DISCOVERING  = 3;
    public static final int STATE_CONNECTED    = 4;

	public static String mErrorMsg="";
    private boolean mScanning = false;
    private int mState = STATE_DISCONNECTED;
    private BluetoothGatt mGatt = null;
    private List<BluetoothGattService> mServiceList = new ArrayList<BluetoothGattService>();
    private List<BluetoothGattCharacteristic> mCharacteristicList = new ArrayList<BluetoothGattCharacteristic>();

    private byte[] mMsgReceived;
	private final Object msgLock = new Object(); 

    private final List< BluetoothDevice>mBLEDevices = new ArrayList<BluetoothDevice>();
    private List<Integer>mRSSI = new ArrayList<Integer>();
	private List<String[]> mTeasers = new ArrayList<>();

    private BluetoothAdapter mBluetoothAdapter = null;
    private BluetoothManager mBluetoothManager = null;
    private BluetoothDevice mBLEDevice = null;

	public	int		mTimeout = 500;			// ms. 0=>off
	private boolean CH_read = false;		// for read sync
	private boolean CH_written = false;		// for write sync
	private boolean NOTIFY_ack = false;		// for notify sync


//    private Handler mHandler = null;

    public BLE(Activity activity)
	{
		mErrorMsg = "";
        mActivity = activity;
        debugOut ("new BLE>  (open)");

        if (!mActivity.getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE))
		{	// Get a newer device
			errorOut ("BLE.Open> No BLE Support.");
            return;
        }
        if (mBluetoothManager == null)
		{
            mBluetoothManager = (BluetoothManager) mActivity.getSystemService(Context.BLUETOOTH_SERVICE);
            if (mBluetoothManager == null)
			{
				errorOut("BLE.Open> Unable to initialize BluetoothManager.");
                return;
            }
        }
        mBluetoothAdapter = mBluetoothManager.getAdapter();
        if (mBluetoothAdapter == null)
		{
			errorOut ("BLE.Open> Unable to obtain a BluetoothAdapter.");
            return;
        }
        if (!mBluetoothAdapter.isEnabled())			// (should not happen) but what the heck..
		{
            requestBluetoothEnable();
            return;
        }
    }//_BLE constructor

    public void onActivityResult(int requestCode, int resultCode, Intent data)
	{
        if (requestCode == REQUEST_ENABLE_BT) {
            if (resultCode == mActivity.RESULT_OK) {
                //scan(true);
            }
        }
    }

    public String getConnectedDeviceName()
	{
        if (mBLEDevice == null) return "";
        return mBLEDevice.getName();
    }

    public String getConnectedDeviceAddress()
	{
        if (mBLEDevice == null) return "";
        return mBLEDevice.getAddress();
    }

    private void requestBluetoothEnable()
	{
        Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        mActivity.startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        debugOut ("requestBluetoothEnable> New BLE without bt_enabled ? Requested again.");
    }

    public void scan(final boolean enable)
	{
        debugOut ("scan> mScanning = "+mScanning + " enable = " + enable);

        if (!  (((!mScanning) && (enable))  || ((mScanning) && (!enable)))   ) return;

        mActivity.runOnUiThread(new Runnable()
		{
            public void run() {
//                mHandler = new Handler();
                scanLeDevice(enable);
            }
        });
    }//_scan

    private void scanLeDevice(final boolean enable)
	{
		BluetoothLeScanner scanner = mBluetoothAdapter.getBluetoothLeScanner();

        if (enable)
		{
            // Stops scanning after a pre-defined scan period.
			synchronized (mBLEDevices)
			{
				mBLEDevices.clear();
				mRSSI.clear();
				mTeasers.clear();
			}
            /*mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (mScanning){
                        mScanning = false;
                        debugOut ("scanLeDevice> scanning stopped");
                        mBluetoothAdapter.stopLeScan(mLeScanCallback);
                    }
                }
            }, SCAN_PERIOD);*/

//			mBluetoothAdapter.startLeScan(mLeScanCallback);
			scanner.startScan(mScanCallback);			// >= Lollipop
			mScanning = true;
            debugOut ("scanLeDevice> scanning started");
        }//_if
		else
		{
//			mBluetoothAdapter.stopLeScan(mLeScanCallback);
			scanner.stopScan(mScanCallback);
            mScanning = false;
            debugOut ("scanLeDevice> scanning stopped");
        }//_else
    }//_scanLeDevice

    // Device scan callback.
//    private BluetoothAdapter.LeScanCallback mLeScanCallback =
//            new BluetoothAdapter.LeScanCallback() {

//                @Override
//                public void onLeScan(final BluetoothDevice device, final int rssi, byte[] scanRecord) {
//                    mActivity.runOnUiThread(new Runnable() {
//                        @Override
//                        public void run() {
//                            int idx = findDeviceAddress(device.getAddress());
//                            if (idx == -1){
//                                debugOut ("device found: "+device.getName() + " " + device.getAddress() + " rssi="+rssi);
//                                mBLEDevices.add(device);
//                                mRSSI.add(new Integer(rssi));
//                            } else {
//                                mRSSI.set(idx, new Integer(rssi));
//                            }
//                        }
//                    });
//                }
//            };

//android.bluetooth.le.ScanCallback							// >= Lollipop only
    private ScanCallback mScanCallback = new ScanCallback()
	{	@Override
		public void onScanResult(int callbackType, ScanResult result)
		{
			final String[] teasers;
			ScanRecord			record = result.getScanRecord();
			List<ParcelUuid>	serviceUuids = record.getServiceUuids();
			if (serviceUuids != null)
			{
				int size = serviceUuids.size();
				teasers = new String[size];
				for (int i=0; i<size; i++)			// get teasers
					teasers[i] = serviceUuids.get(i).getUuid().toString();
			}
			else teasers = new String[0];

			final BluetoothDevice device = result.getDevice();
			final int rssi = result.getRssi();

			mActivity.runOnUiThread(new Runnable()
			{
			@Override
			public void run()
			{
			synchronized (mBLEDevices)
			{
				int idx = findDeviceAddress(device.getAddress());	// (re-entrant)
				if (idx == -1)							// add new device
				{
					debugOut ("mScanCallback> new device found: "+device.getName() + " " + device.getAddress() + " rssi="+rssi);
					mBLEDevices.add(device);
					mRSSI.add(new Integer(rssi));
					mTeasers.add (teasers);
					if (DEBUG && teasers.length>0)
					{
						debugOut ("mScanCallback> found teasers> ");
						for (String s : teasers) {debugOut ("mScanCallback> "+s);};
					}
				}//_if new
				else // not new
				{
					mRSSI.set(idx, new Integer(rssi));	// update signal strength
				}//_else
			}//_sync
			}//_run
			});//_runnable
		}//_onScanResult

// 		@Override
// 		public void onScanFailed(int errorCode)
// 		{
// 			super.onScanFailed(errorCode);
// 			// Safely handle errors (e.g., SCAN_FAILED_ALREADY_STARTED)
// 		}
	};//_mScanCallback

    public ArrayList<String> getDevices()
	{
		ArrayList devices = new ArrayList<String>();
		synchronized (mBLEDevices)
		{
			for (BluetoothDevice dev : mBLEDevices)
			{
				devices.add(dev.getAddress());
			}//_for
		}//_sync
        return devices;
    }//_getDevices

    public boolean connect(String address)
	{
		mErrorMsg = "";
//		disconnect();					// -humpty - don't use old connections
		if (mState != STATE_DISCONNECTED)
			return errorOut ("BLE.Connect> Bad previous state. Use BLE.CLOSE");

		if (!mBluetoothAdapter.checkBluetoothAddress (address))
			return errorOut ("BLE.Connect> Bad bluetooth Address format.");

        debugOut ("connect> connecting to "+ address);

		try	{ mBLEDevice = mBluetoothAdapter.getRemoteDevice(address); }
		catch (Exception e)
		{
			mBLEDevice = null;
			return errorOut ("BLE.Connect> Connect error: " + e);
		}
        //int idx = findDeviceAddress(address);
        if (mBLEDevice == null)
			return errorOut ("BLE.Connect> Error connecting to "+address);

//		if (mGatt == null){
			mGatt = mBLEDevice.connectGatt(mActivity, false, mGattCallback);
			if (mGatt == null)
				return errorOut ("BLE.Connect> Could not intiate connection.");
			mState = STATE_CONNECTING;
//		}
//		else {
//			if (mGatt.connect()){
//                mState = STATE_CONNECTING;
//			} else close();
//		}
		return true;	// ok
    }//_connect

    public void disconnect()
	{
//         if (mState == STATE_DISCONNECTED) return;
        mState = STATE_DISCONNECTED;
//         mServiceList = mServiceList = new ArrayList<BluetoothGattService>();
		mServiceList.clear();
        mCharacteristicList.clear();
		mTeasers.clear();
		debugOut ("disconnect> disconnected");

		synchronized (this)
		{
			if (mGatt != null)
			{
				mGatt.disconnect();
				/*mActivity.runOnUiThread(new Runnable() {
					@Override
					public void run() {
						Toast.makeText(mActivity.getApplicationContext(), "BT device disconnected", Toast.LENGTH_LONG).show();
					}
				});*/
			}
		}//_sync
		mBLEDevice=null;
//      close();				// don't recurse
    }//_disconnect

	public void close()			// humpty - do most of this in disconnect()
	{
		disconnect();
//         if (mGatt == null) return;
//         debugOut ("close> BLE close");
//         mGatt.close();
//         mGatt = null;
		scan (false);
	}//_close

    public int getState()
	{
        return mState;
    }//_getState

    public String getStateAsString(){
        String st = "";								// string representation of state
        switch (mState) {
            case STATE_DISCONNECTED: st = "Disconnected";	break;
            case STATE_CONNECTING:	 st = "Connecting";	    break;
            case STATE_DISCOVERING:	 st = "Discovering";    break;
            case STATE_CONNECTED:	 st = "Connected";      break;
            default:									    break;
        }
        return st;
    }//_getStateAsString

    public ArrayList<String> getServicesUUID(){
        ArrayList services = new ArrayList<String>();
        for (BluetoothGattService service : mServiceList) {
            services.add(service.getUuid().toString());
        }
        return services;
    }//_getServicesUUID

    public ArrayList<String> getCharacteristicsUUID(String serviceUUID)
	{
        debugOut ("getCharacteristicsUUID> for service "+serviceUUID);

        ArrayList services = new ArrayList<String>();
        ArrayList list = new ArrayList<String>();
        for (BluetoothGattService service : mServiceList) {
            if (uuidMatches(service.getUuid().toString(), serviceUUID)) {
                List<BluetoothGattCharacteristic> chs = service.getCharacteristics();
                for (BluetoothGattCharacteristic ch : chs) {
                    debugOut ("getCharacteristicsUUID> "+ch.getUuid().toString());
                    list.add(ch.getUuid().toString());
                }
                return list;
            }
        }
        return list;
    }//_getCharacteristicsUUID

    public int findDeviceAddress(String address)
	{
		synchronized (mBLEDevices)						// most probably re-entrant
		{
			int idx = 0;
			for (BluetoothDevice dev: mBLEDevices)
			{
				if (dev.getAddress().equals(address)) {
					return idx;
				}
				idx++;
			}//_for
		}//_sync
        return -1;
    }//_findDeviceAddress

    public BluetoothGattCharacteristic findCharacteristicUUID(String uuid)
	{
        for (BluetoothGattCharacteristic ch: mCharacteristicList) {
            if (uuidMatches(ch.getUuid().toString(), uuid)) {
                return ch;
            }
        }
        return null;
    }//_BluetoothGattCharacteristic

    public String getDeviceName(String address)
	{
		String name="";
		synchronized (mBLEDevices)
		{
			int idx = findDeviceAddress(address);
			if (idx == -1)
			{
				debugOut ("getDeviceName> Error - no such device address");
				return "";
			}
			name = mBLEDevices.get(idx).getName();
			if (name==null) name = "";
		}//_sync
       	return name;
    }//_getDeviceName

    public int getDeviceRSSI(String address)
	{
		int rssi = 0;
		synchronized (mBLEDevices)
		{
			int idx = findDeviceAddress(address);
			if (idx == -1)
			{
				debugOut ("getDeviceRSSI> Error - no such address");
				return 0;
			}
			rssi = mRSSI.get(idx).intValue();
		}//_sync
        return rssi;
    }//_getDeviceRSSI

    public String[] getTeasers(String address)	// get teasers for device
	{
		String[] teasers = null;
		synchronized (mBLEDevices)
		{
			int idx = findDeviceAddress(address);
			if (idx == -1) debugOut ("getTeaser> Error - no such device address");
			else teasers = mTeasers.get(idx);
		}//_sync
		if (teasers==null) teasers=new String[]{""};
        return teasers;
    }//_getTeasers

	public int getProps (String characteristicUUID)
	{
		mErrorMsg = "";						// assume no errors

        BluetoothGattCharacteristic ch = findCharacteristicUUID(characteristicUUID);
        if (ch == null)
		{
			errorOut ("BLE.Properties> no such characteristic");
			return 0;
		}
		return ch.getProperties();
	}//_getProps

    public boolean write(String characteristicUUID, String value)
	{													// true => ok
		mErrorMsg = "";
        byte[] data = new byte[value.length()];
        for (int i=0; i < value.length(); i++) data[i] = ((byte)value.charAt(i));

		if (DEBUG)
		{
			StringBuilder sb = new StringBuilder();
			for(byte byteChar : data)  sb.append(String.format("%02X ", byteChar & 0xFF));
			debugOut ("write> "+characteristicUUID + ": " +sb.toString());
		}
        if ((mState != STATE_CONNECTED) || (mGatt == null))
			return errorOut ("BLE.Write> not connected");

        BluetoothGattCharacteristic ch = findCharacteristicUUID(characteristicUUID);
        if (ch == null)
			return errorOut ("BLE.Write> no such characteristic");

		int rc = -1;					// assume failed
		if (Build.VERSION.SDK_INT >= 33)
		{
			rc = mGatt.writeCharacteristic (ch, data,	// pass isolated copy
								BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
		}
		else	// Api < 33
		{
			ch.setValue(data);
			if (mGatt.writeCharacteristic(ch)) rc = 0;
		}
		if (rc!=0) return errorOut ("BLE.Write> Error on write"+" code "+rc); // failure code
		// no error on request
									// sync a timeout to avoid race conflict ?
		if (mTimeout > 0)		// +ve timeout=> sync else <0 => async
		{
			CH_written = false;
			int tries = mTimeout/100;
			for (int t=0; t<tries; t++)
			{
				if (CH_written) {debugOut("BLE.Write> confirmed after "+t);break;}
				try { Thread.sleep(100); } catch(InterruptedException e) {}
			}
			if (!CH_written) return errorOut ("BLE.Write> timed out.");
		}//_if sync
		// else async has no errors
		return true;	// success
    }//_write

    public boolean requestRead(String characteristicUUID)
	{
        debugOut ("requestRead> "+characteristicUUID);

		mErrorMsg = "";
		synchronized (msgLock) { mMsgReceived = null; }

        if ((mState != STATE_CONNECTED) || (mGatt == null))
			return errorOut ("BLE.Read.Request> not connected");

        BluetoothGattCharacteristic ch = findCharacteristicUUID(characteristicUUID);
        if (ch == null)
			return errorOut("BLE.Read.Request> no such characteristic");

		int properties = ch.getProperties();
		if ((properties & BluetoothGattCharacteristic.PROPERTY_READ) == 0)
			return errorOut("BLE.Read.Request> read property not supported");

        if (!mGatt.readCharacteristic(ch))
			return errorOut("BLE.Read.Request> Error initiating request");
		// no error on request
									// sync a timeout to avoid race conflict ?
		if (mTimeout > 0)		// +ve timeout=> sync else <0 => async
		{
			CH_read = false;
			int tries = mTimeout/100;
			for (int t=0; t<tries; t++)
			{
				if (CH_read) {debugOut("requestRead> confirmed after "+t);break;}
				try { Thread.sleep(100); } catch(InterruptedException e) {}
			}
			if (!CH_read) return errorOut ("BLE_requestRead> timed out.");
		}//_if sync
		// else async has no errors
		return true;
    }//_requestRead

    public boolean enableCharacteristicNotification(String characteristicUUID, boolean enable)
	{
		mErrorMsg = "";
        debugOut ("BLE.Notify> " + enable + " " + characteristicUUID);

        if ((mState != STATE_CONNECTED) || (mGatt == null))
			return errorOut ("BLE.Notify> not connected");

        BluetoothGattCharacteristic ch = findCharacteristicUUID(characteristicUUID);
        if (ch == null)
			return errorOut ("BLE.Notify> no such characteristic");

													// notify Android
        boolean characteristicWriteSuccess = mGatt.setCharacteristicNotification(ch, enable);

        if (!characteristicWriteSuccess)
			return errorOut ("BLE.Notify> could not set notification");

													// notify device (push, no ack)
		byte[] payload = enable	?BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
							   	:BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE //stop
								;
		BluetoothGattDescriptor descriptor = ch.getDescriptor(UUID.fromString(NOTIFICATION_UUID));
		if (descriptor == null)
			return errorOut ("BLE.Notify> could not get descriptor");

		int rc = -2;			// assume the worse
		if (Build.VERSION.SDK_INT >= 33)
			rc = mGatt.writeDescriptor(descriptor, payload);
		else
		{
			descriptor.setValue(payload);
			if (mGatt.writeDescriptor(descriptor)) rc=0;
		}
		if (rc!=0) return errorOut ("BLE.Notify> writeDescriptor error code: "+rc); // failure code

		if (mTimeout > 0)		// +ve timeout=> sync else <0 => async
		{
			NOTIFY_ack = false;
			int tries = mTimeout/100;
			for (int t=0; t<tries; t++)
			{
				if (NOTIFY_ack) {debugOut("BLE.Notify> confirmed after "+t);break;}
				try { Thread.sleep(100); } catch(InterruptedException e) {}
			}
			if (!NOTIFY_ack) return errorOut ("BLE.Notify> timed out.");
		}//_if sync
		return true;						// success
    }//_enableCharacteristicNotification

    public String read()
	{
        String s = "";
		synchronized (msgLock)
		{
			if (mMsgReceived != null)
			{
				for(byte byteChar : mMsgReceived)  s += (char)(byteChar & 0xFF);
				mMsgReceived = null;
			}
		}//_sync
        return s;
    }//_read


    private void readCharacteristic (BluetoothGattCharacteristic characteristic)
	{												// deprecated Api 33+
        debugOut ("readCharacteristic (old)> reading..");	// for old devices only
		if (characteristic == null) return;

//        mMsgReceived = characteristic.getValue();
		byte[] rawValue = characteristic.getValue();	// always make a copy
		if (rawValue == null) return;					// allowed is rawValue.length == 0
		synchronized (msgLock)
		{
			mMsgReceived = Arrays.copyOf(rawValue, rawValue.length);	// get it
		}
/*------
        StringBuilder sb = new StringBuilder();
        if (mMsgReceived != null && mMsgReceived.length > 0)
		{
			for(byte byteChar : mMsgReceived)  sb.append(String.format("%02X ", byteChar & 0xFF));
        }
        debugOut ("readCharacteristic> received "+characteristic.getUuid().toString() +": "+sb.toString());
-------*/
    }//_readCharacteristic

    // If manually filtering, substring to match:
    // 0000XXXX-0000-0000-0000-000000000000
    private boolean uuidMatches(String uuidString, String... matches)
	{
        for (String match : matches) {
            if (uuidString.equalsIgnoreCase(match)) {
                return true;
            }
        }

        return false;
    }//_uuidMatches

// ----------------------------------------------------------------------------

    private final BluetoothGattCallback mGattCallback = new BluetoothGattCallback()
	{
        @Override
        public void onConnectionStateChange (BluetoothGatt gatt, int status, int newState)
		{
            debugOut ("onConnectionStateChange newState: " + newState);

            if (status == BluetoothGatt.GATT_FAILURE) {
                debugOut ("Connection Gatt failure status " + status);
                disconnect();
                return;
            }
			else if (status != BluetoothGatt.GATT_SUCCESS)
			{
                // handle anything not SUCCESS as failure
                debugOut ("Connection GATT not success status " + status);
                disconnect();
                return;
            }

            if (newState == BluetoothProfile.STATE_CONNECTED)
			{
                debugOut ("Connected to device " + gatt.getDevice().getAddress());
                mState = STATE_DISCOVERING;
                gatt.discoverServices();
            }
			else if (newState == BluetoothProfile.STATE_DISCONNECTED)
			{
				synchronized (this)
				{
					debugOut ("Disconnected from device");
					if (mGatt != null)
					{
						mGatt.close();
						mGatt = null;
					}
				}//_sync
            }//_else if STATE_DISCONNECTED
        }//_onConnectionStateChange

        @Override
        public void onServicesDiscovered (BluetoothGatt gatt, int status)
		{

            if (status != BluetoothGatt.GATT_SUCCESS)
			{
                debugOut ("Device service discovery unsuccessful, status " + status);
                disconnect();
                return;
            }
            mServiceList = gatt.getServices();
            mCharacteristicList.clear();
            for (BluetoothGattService service : mServiceList)
			{
                String uuid = service.getUuid().toString();
                debugOut ("Service discovered: "+ uuid);

                List<BluetoothGattCharacteristic> chs = service.getCharacteristics();
                for (BluetoothGattCharacteristic ch : chs)
				{
                    debugOut ("Characteristic: "+ch.getUuid().toString());
                    mCharacteristicList.add(ch);
                }
            }
            mState = STATE_CONNECTED;
        }//_onServicesDiscovered

        @Override
        public void onCharacteristicWrite (	BluetoothGatt gatt,
											BluetoothGattCharacteristic characteristic,
											int status)
		{
            if (status == BluetoothGatt.GATT_SUCCESS)
			{
                //debugOut ("Characteristic written successfully");
                //if (uuidMatches(characteristic.getUuid().toString(), RBLE_AUTH_UUID_V_3_5)){
                //    gatt.readCharacteristic(characteristic);
                //}
                debugOut ("Characteristic write Success, status: " + status);
				CH_written = true;
            }
			else
			{
                debugOut ("Characteristic write unsuccessful, status: " + status);
                //disconnect();
            }
        }//_onCharacteristicWrite

        @Override
        public void onCharacteristicRead (	BluetoothGatt gatt,
											BluetoothGattCharacteristic characteristic,
											int status)
		{									// deprecated Api 33+
			debugOut ("onCharacteristicRead (old)> status: " + status);
			if (Build.VERSION.SDK_INT >= 33) return;	// don't duplicate

            if (status == BluetoothGatt.GATT_SUCCESS)
			{
                // debugOut ("onCharacteristicRead> success :" + characteristic.toString());
                readCharacteristic(characteristic);		// deprecated
                //if (uuidMatches(characteristic.getUuid().toString(), RBLE_AUTH_UUID_V_3_5)) {
				CH_read = true;
            }
//			else
//			{
                // Trying to read from the Time Characteristic? It doesnt have the property or permissions
                // set to allow this. Normally this would be an error and you would want to:
                // disconnectGattServer();
//            }
        }//_onCharacteristicRead

        @Override
        public void onCharacteristicChanged (BluetoothGatt gatt,
									BluetoothGattCharacteristic characteristic)
									// deprecated Api 33+
		{
            debugOut ("onCharacteristicChanged (old)> " + characteristic.getUuid().toString());
			if (Build.VERSION.SDK_INT >= 33) return;	// don't duplicate
            readCharacteristic(characteristic);		// deprecated
        }//_onCharacteristicChanged

        @Override
        public void onReadRemoteRssi (BluetoothGatt gatt, int rssi, int status)
		{
            super.onReadRemoteRssi(gatt, rssi, status);
            debugOut ("RSSI " + rssi);
        }
//-------
// Api 33+ ONLY
		@Override
		public void onCharacteristicRead (BluetoothGatt gatt,
									BluetoothGattCharacteristic characteristic,
									byte[] value,		// (safe copy)
									int status)
		{
			debugOut ("onCharacteristicRead (safe)> status: " + status);
			if (value == null) return;
			synchronized (msgLock) { mMsgReceived = value; }
			CH_read = true;
		}//_ api33+ onCharacteristicRead

		@Override
		public void onCharacteristicChanged (BluetoothGatt gatt,
									BluetoothGattCharacteristic characteristic,
									byte[] value)		// (safe copy)
		{
            debugOut ("onCharacteristicChanged (safe)> "+characteristic.getUuid().toString() );
			if (value == null) return;
			synchronized (msgLock) { mMsgReceived = value; }
		}//_ api33+ onCharacteristicChanged

		@Override
		public void onDescriptorWrite (	BluetoothGatt gatt,
										BluetoothGattDescriptor descriptor,
										int status)
		{
			if (status == BluetoothGatt.GATT_SUCCESS)
			{
				NOTIFY_ack = true;
			}
		}//_onDescriptorWrite

	};//_mGattCallback
// ----------------------------------------------------------------------------
	private void debugOut(String s)
	{
		if (!DEBUG) return;
		Log.d (TAG, s);
	}
	private boolean errorOut(String s)
	{
		mErrorMsg = s;
		debugOut (mErrorMsg);
		return false;			// convenience for caller
	}
}//_BLE class
