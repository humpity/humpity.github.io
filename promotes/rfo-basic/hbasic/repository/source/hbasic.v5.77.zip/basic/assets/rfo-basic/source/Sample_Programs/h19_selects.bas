!!
 - v1.00 -humpty: Nov-2026

 This program demonstrates
 the SELECT family of full
 screen dialogs and also
 DIALOG.SET.
!!
dialog.set "title_align center"
array.load c$[],"blue","green","red","pink","orange","purple","black"
array.load a$[],"left","center","right"
array.load f$[],"monospace","serif","sans-serif"
array.load s$[]~
""~
"Select"~
"Select.Multi"~
"Select.File"~
"Select.MultiFile"~
"window_BG"~
"highColor"~
"title_align"~
"title_font"~
"text_Align"~
"Quit"~
""~
"____Results____ "~
""~        % row 14 is output
""
ia=2: xa=1 : out=14
do
    s=1
    select rc, s$[],"Tap line for Demo",""
    sw.begin rc
    sw.case ++s
        Select c ,c$[], "Select",""
        if c>0 then c$=c$[c] else c$=""
        s$[out] = c$
        sw.break
    sw.case ++s    % Select Multi
        undim m$[]
        array.copy c$[],m$[]
        Select.Multi m ,m$[]
        m$=""
        for i=1 to m: m$+=m$[i]+",":next
        s$[out] = m$
        sw.break
    sw.case ++s    % File
        p$=""
        Select.File f ,p$
        s$[out] = p$
        sw.break
    sw.case ++s    % Multi File
        undim m$[]
        Select.MultiFile m ,p$, m$[]
        m$=""
        for i=1 to m: m$+=m$[i]+" ":next
        s$[out] = m$
        sw.break
    sw.case ++s
        c++: if c>7 then c=1
        dialog.set "window_BG "+c$[c]
        sw.break
    sw.case ++s
        h++: if h>6 then h=1
        dialog.set "highColor "+c$[h]
        sw.break
    sw.case ++s
        ia++: if ia>3 then ia=1
        dialog.set "title_align "+a$[ia]
        sw.break
    sw.case ++s
        f++: if f>3 then f=1
        dialog.set "title_font "+f$[f]
        sw.break
    sw.case ++s
        xa++: if xa>3 then xa=1
        dialog.set "text_align "+a$[xa]
        sw.break
    sw.case ++s
        rc=0
    sw.end
until rc =0

