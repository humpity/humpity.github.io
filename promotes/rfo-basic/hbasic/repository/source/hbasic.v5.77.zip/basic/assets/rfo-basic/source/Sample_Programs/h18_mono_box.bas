!!
 - v1.00 -humpty: Nov-2026

 This program demonstrates
 console loading of a mono 
 fixed width font that covers 
 the CP437 IBM font block and 
 unicode block U+2500-U+257F
 for Box Drawing.

!!
console.title "IBM Box Drawing",,,,2

gosub init

x=2 : y=3 : w=10 : h=5

drawFrame(x,y,w,h, "┌┐└┘──││")
?.at y+2,x+2; "Single"

x+=w+2
drawFrame(x,y,w,h, "╔╗╚╝══║║")
?.at y+2,x+2; "Double"

x-=w+2 : y+=h+1
drawFrame(x,y,w,h, "┏┓┗┛━━┃┃")
?.at y+2,x+2; "Heavy"

x+=w+2
drawFrame(x, y, w, h, "▄▄▀▀▄▀██")
?.at y+2,x+2; "Blocks"

x-=w+2 : y+=h+1
drawFrame(x,y,w,h, "┌╖╘╝─═│║")
?.at y+2,x+2; "Shadow"

x+=w+2
drawFrame(x, y, w, h, "╔╕╙┘═─║│")
?.at y+2,x+2; "Reverse"

END
%------------------------
init:
    .cs "wrap off, spacing 0"
    .cs "dividers off"

    FONT.LOAD fptr, "boxblue.ttf"

    IF fptr < 0 THEN GOTO LOAD_ERROR
    ? "Loaded Font: ";fptr
    .cs "FONT "+int$(fptr)  % use font

    %------------------------
    fn.def drawFrame(l,t,w,h, s$)

        r = l+w-1: b = t+h-1
        if l>=r | t>=b-1  then fn.rtn -1

        for row = t to b        % clear area
            for col = l to r
                ?.at row,col;" "
            next
        next

        tl$=mid$(s$,1,1):tr$=mid$(s$,2,1)
        bl$=mid$(s$,3,1):br$=mid$(s$,4,1)
        ht$=mid$(s$,5,1):hb$=mid$(s$,6,1)
        vl$=mid$(s$,7,1):vr$=mid$(s$,8,1)

        ?.at t,l;tl$        % corners
        ?.at t,r;tr$
        ?.at b,l;bl$
        ?.at b,r;br$
        for i=l+1 to r-1    % horizontals
            ?.at t,i;ht$
            ?.at b,i;hb$
        next
        for i=t+1 to b-1    % verticals
            ?.at i,l;vl$
            ?.at i,r;vr$
        next
        fn.rtn 0
    fn.end
RETURN %_init
%------------------------
LOAD_ERROR:
? "Could not load font."
? getError$()
END


