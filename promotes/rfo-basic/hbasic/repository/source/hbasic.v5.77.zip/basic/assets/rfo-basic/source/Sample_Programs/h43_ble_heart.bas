!!
 ----- Heart rate sensor (BLE) -----
        via teaser scan

 (Modified from Grau Basic!
  original f43_ble_heart.bas)

 for hBasic v5.70+
 - v1.00 -humpty: Nov-2026

 This program scans for a
 heart rate service teaser.

 If found, it will enable 
 notifications to get  5 
 readings, do a write test 
 and a one-shot read test.

 (To simulate a teaser, you
  can run nRF Connect app
  on another device.
  Configure gatt-server to
  add a Heart Rate. Add an
  Advertiser with service
  UUID 180d in Advertising
  data.)
!!
% Heart Rate Official Registered Codes
svdata$ = "0000180d-0000-1000-8000-00805f9b34fb" % service
chnoti$ = "00002a37-0000-1000-8000-00805f9b34fb" % measurement
chread$ = "00002a38-0000-1000-8000-00805f9b34fb" % sensor location
chwrite$ = "00002a39-0000-1000-8000-00805f9b34fb" % control reg

console.screen  scrW,scrH
if device$("location")="Off" then ?"Please turn on Location" : END

BLE.OPEN
if getError$()<>"" then goto doError

BLE.SCAN 1
tout = 20 : poll$ = "-\\|/"
last = 1
print "Scanning devices.."
do
    BLE.DEVICES dl$[] : array.length dlen,dl$[]
    chk$ = dl$[1] : if chk$="" then dlen=0

    p$ = mid$(poll$,1+mod(poll++,4),1)
    print.at 1,scrW-5; using$(,"%3d",int(dlen));" ";p$

    for i=last to dlen
        dev$ = dl$[i]
        if dev$="" then f_n.continue
        BLE.RSSI dev$, rssi
        BLE.NAME dev$, name$
        BLE.TEASERS dev$,t$[] : array.length tlen,t$[]
        for j=1 to tlen
            if t$[j]=svdata$ then
                print "Found Heart Rate teaser"
                print name$;"\n";dev$; " rssi=" ; rssi
                d_u.break   % found
            endif
        next j
    next i
    last = dlen+1
    pause 1000
    if --tout < 0 then
        print "Timed Out"
        print "No Heart Rate teasers found."
        BLE.SCAN 0
        END
    endif
until 0
BLE.SCAN 0
!----------------------------
            % connect to device
tout = 20
st$ = "Disconnected"
do
    if  st$ = "Disconnected"
        BLE.CONNECT dev$
        if getError$()<>"" then goto doError
    endif

    if --tout < 0 then print "Stop. Timed out.":END
    pause 500

    BLE.STATUS st$
    if st$ <> last$
        last$ = st$
        print st$
    endif
until st$ = "Connected"
!----------------------------
    % setup for continuous data

BLE.NOTIFY chnoti$, 1
if getError$()<>"" then goto doError    % report error
PAUSE 1000          % needs about 1 or 2 secs
print "Notify On"
for i=1 to 5                % poll 5 times
    pause 1000
    BLE.READ data$
    if data$ <> ""
      ! ------ parse data -------
      rate = ascii(data$, 2)
      print "  data=" ; rate
    else
        print "  <empty>"
    endif
next
BLE.NOTIFY chnoti$, 0   % stop continuous
print "Notify Off"
!----------------------------
    % setup for one time write
print "Write> energy counter reset"
byte = 1

BLE.WRITE chwrite$, chr$(byte)
if getError$()<>"" then goto doError    % report error

!----------------------------
    % setup for one time read

print "Read Request> body sensor pos"

BLE.READ.REQUEST chread$
if getError$()<>"" then goto doError    % report error

BLE.READ v$
print "Read> ";
v=ascii(v$)     % empty string is always 256
if v=256 then print "(empty)" else print v
goto onBackKey
!----------------------------
        % be sure to stop any data
doError:
    PRINT "Error> ";getError$()
onBackKey:
    BLE.notify chnoti$, 0
    BLE.CLOSE
END
