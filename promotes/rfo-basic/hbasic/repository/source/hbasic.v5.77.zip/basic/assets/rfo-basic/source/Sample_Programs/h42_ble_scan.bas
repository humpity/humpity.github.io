!!
 ----- BLE scanner -----

 (Modified from Grau Basic!
  original f42_ble_scan.bas)

 for hBasic v5.70+
 - v1.00 -humpty: Nov-2026

 This program scans for
 Bluetooth Low Energy devices
 and displays them with constant
 update and navigation.
 A selected device will be
 connected, to list services
 and characteristics.
!!

console.orient 1
.cs "textsize 18, wrap off"
.cs "font monospace"
console.screen  scrW,scrH
cen=ceil(scrW/2)            % center
        %   nrows = devices per page.
nrows=6 : last=nrows+1: offset=0
poll$ = "-\\|/"
!---------------------------
if device$("location")="Off" then ?"Please turn on Location" : END

BLE.OPEN
if getError$()<>"" then goto doError

print "Scanning..":print.at 1,scrW-11;"found:"
BLE.SCAN 1                  % turn on scanning

print.at last+1,cen-2; "Next"
print.at last+2,cen-2; "Prev"
print.at last+3,cen-2; "Quit"
again:
    touched=0 : poll=0 : tout=20
    do
        pause 100 : t++     % want sensitive touch
        if t<10 | touched then d_u.continue
        gosub scan          % every 10*100 ms

        if --tout < 0 & dlen=0 then
            print "Timed Out.  No devices found."
            BLE.SCAN 0
            END
        endif
        p$ = mid$(poll$,1+mod(poll++,4),1)
        t=0                 % reset poll
    until touched           % get line

    t=10                    % bypass poll
    sw.begin line           % process touch
    sw.case last+1          % Next Page
        offset+=nrows
        if offset > dlen-1 then offset=0
        sw.break
    sw.case last+2          % Prev Page
        offset-=nrows
        if offset<0 & offset>nrows*-1 then offset=0
        if offset<0 then offset=dlen+offset
        sw.break
    sw.case last+3          % Quit
        clr 1:?.at 1,1; "Quit"
        end
    sw.default              % user clicked device list
        i = offset+line-1
        if i > dlen then sw.break   % out of range
        dev$=dl$[offset+line-1]     % get device address
        if dev$="" then sw.break    % ignore blanks

        BLE.SCAN 0          % turn off scanning
        gosub connect       % connect to device
        gosub show          % show results
REM     console.save "dump.txt" % Save to a file
        END                 % DONE
    sw.end
goto again
end
!---------------------------
scan:
    BLE.DEVICES dl$[] : array.length dlen,dl$[]
    chk$=dl$[1] : if chk$="" then dlen=0
    print.at 1,scrW-5; using$(,"%3d",int(dlen));" ";p$

    for row=1 to nrows
     i=offset+row
     if i>dlen then d$="" else d$=dl$[i]
     if d$<> "" then
        BLE.RSSI d$, rssi
        BLE.NAME d$, n$
        r$=using$ (, "%4d", int(rssi))
        i$=using$ (, "%-4d", int(i))
     else
        i$="":r$="":n$=""
     endif
     clr row+1
     print.at row+1,1; i$;n$;"\n";"    ";d$;" ";r$
    next
return
!---------------------------
connect:                % do connection
    tout = 20
    st$ = "Disconnected"
    BLE.NAME dev$, n$
    print n$;"\n";dev$; " rssi=" ; rssi
    do
        % Connect only if Disconnected
        if st$ = "Disconnected" then
            BLE.CONNECT dev$
            if getError$()<>"" then goto doError
        endif

        if --tout < 0 then print "\nStop. Timed out.":END
        pause 500

        BLE.STATUS st$
        if st$ <> last$ then
            print
            last$=st$
            print st$;" ";
        else
            print ".";
        endif
    until st$ = "Connected"
    print
return %_connect
!---------------------------
show:       % show services and characteristics

    .cs "textsize 16, font serif"
    BLE.SERVICES sv$[]
    array.length svlen,sv$[]
    for i=1 to svlen
        print "sv " ; sv$[i];

        BLE.CHARACTERISTICS sv$[i], ch$[]
        array.length chlen,ch$[]
        for j=1 to chlen
            print "\n  ch " ; ch$[j];
        next j
        print
    next i
    .cs "textsize 18, font monospace"
return %_show
!---------------------------
                % get touched line
onConsoleTouch:
    console.line.touched line
    console.line.text line,lin$
                % ignore status line
    if line=1 then ConsoleTouch.resume
                % blink
    .cs "textcolor white, backcolor black"
    clr line : ?.at line,1;lin$
    pause 130
    .cs "textcolor black, backcolor white"
    clr line : ?.at line,1;lin$
    touched = 1
ConsoleTouch.resume
!---------------------------
doError:
    PRINT "Error> ";getError$()
onBackKey:
    BLE.CLOSE
END
