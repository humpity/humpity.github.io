** Due to access problems, HEW will no longer be maintained here **

Please goto :
HEW framework: http://humpty.drivehq.com/promotes/rfo-basic/hew/hew.html

All the latest versions of code are at the HEW website;
http://humpty.drivehq.com/promotes/rfo-basic/hew/hew.html

------------------------------------
Jun 2014
	btm_demo.zip
		Demo to show botmenu widget.
		6 pane bottom popup menu.
		Test HEW modules.

extract the zip file into rfo-basic/source and run btm_demo.bas
------------------------------------
Sep 2014
	txtscroll widget
	Text pane with smooth vertical scrolling.
	tsdemo1000.apk	
Nov 2014
	tsdemo2200.apk
Dec 2014
	terminal_demo.zip	

If APKs only, rename and unpack to get the source code.
