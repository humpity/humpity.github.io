# removes all entries from fluxbox menu, preserving top level.
# batch files should use -n switch to stop the restart.

APP_NAME=menjob

# if called from elsewhere, make sure we start here
ME=`readlink -f $0`; MYDIR=`dirname $ME`; cd $MYDIR

# using fluxtool to remove
./fluxtool $APP_NAME -d -p

# restart fluxbox if not called from batch
if [ "$1" != "-n" ]; then
 ./fluxtool -r
fi
