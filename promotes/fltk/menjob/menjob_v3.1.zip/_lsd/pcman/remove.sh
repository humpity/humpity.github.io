# removes icon from pcman. 

APP_NAME=menjob

# if called from elsewhere, make sure we start here
ME=`readlink -f $0`; MYDIR=`dirname $ME`; cd $MYDIR

# easy, just remove the .desktop from $HOME/Desktop

rm -f $HOME/Desktop/$APP_NAME.desktop

if [ -f $HOME/Desktop/$APP_NAME.desktop ]; then
 echo no success.
else
 echo desktop item removed.
fi

# restart not needed
