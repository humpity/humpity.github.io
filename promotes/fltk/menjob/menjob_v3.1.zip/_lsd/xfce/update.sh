# xfce updater

APP_NAME=menjob
APP_EXEC=../../$APP_NAME
APP_ICON=$APP_NAME.xpm

# if called from elsewhere, make sure we start here
ME=`readlink -f $0`; MYDIR=`dirname $ME`; cd $MYDIR

# using xfcetool to update xfce icons

./xfcetool $APP_NAME $APP_EXEC $APP_ICON

# xfce should not need restarting
