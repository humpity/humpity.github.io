# dfm updater
# batch files should use the -n switch to stop the restart

APP_NAME=menjob
APP_EXEC=../../$APP_NAME
APP_ICON=$APP_NAME.xpm

# if called from elsewhere, make sure we start here
ME=`readlink -f $0`; MYDIR=`dirname $ME`; cd $MYDIR

# use dfmtool to update the dfm window manager icons

./dfmtool $APP_NAME $APP_EXEC $APP_ICON

# restart dfm if not called from batch
if [ "$1" != "-n" ]; then
 ./dfmtool -r
fi
