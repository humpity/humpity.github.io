# remove links

APP_NAME=menjob

LINKS_DIR=$HOME/_links

# if called from elsewhere, make sure we start here
ME=`readlink -f $0`; MYDIR=`dirname $ME`; cd $MYDIR

# abort if link directory not there
if [ ! -s $LINKS_DIR ]; then echo cannot find $LINKS_DIR; exit; fi

echo removing $APP_NAME from $LINKS_DIR
rm -f $LINKS_DIR/$APP_NAME

if [ -f $LINKS_DIR/$APP_NAME ]; then
 echo no success.
else
 echo link removed.
fi
