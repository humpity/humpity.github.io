# create links

APP_NAME=menjob
APP_EXEC=../../$APP_NAME

LINKS_DIR=$HOME/_links

# if called from elsewhere, make sure we start here
ME=`readlink -f $0`; MYDIR=`dirname $ME`; cd $MYDIR

# create a links directory if not already there
if [ ! -s $LINKS_DIR ]; then mkdir $LINKS_DIR; fi

echo using lnktool to create links
./lnktool $APP_NAME $APP_EXEC $LINKS_DIR
