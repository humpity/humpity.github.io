# pcman updater

APP_NAME=menjob
APP_EXEC=../../$APP_NAME
APP_ICON=$APP_NAME.xpm

# if called from elsewhere, make sure we start here
ME=`readlink -f $0`; MYDIR=`dirname $ME`; cd $MYDIR

# using pcman_tool to update pcman icons

./pcman_tool $APP_NAME $APP_EXEC $APP_ICON

# pcman should not need restarting
