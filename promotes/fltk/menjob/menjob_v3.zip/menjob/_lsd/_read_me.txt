* Info
!===============

MenJOB

A batch Job Gui and script generator for MEncoder

Makes for easy encoding.

Version: 2.2
Author : humpty
Website: http://humpty.drivehq.com/promotes/fltk/menjob/menjob.html
License: binary is public domain

Requires: libfltk1.3
#===============
executables: menjob
@===============

_lsd/(installer)
	The (installer) directory contains utilities
	for desktop and system integration

	update.sh to update the integration.
        remove.sh to remove the integration.

	e.g 
	directory

	_lsd/links	adds symlinks to $HOME/_links
			You will need to add this to your PATH
			e.g in .bashrc or .profile
				PATH=$PATH:~/_links
			Other programs can then find your app easily.
	
	_lsd/dfm	updates icons for dfm window manager
	_lsd/idesk	updates icons for idesk
	_lsd/xfce	updates icons for xfce desktop
	_lsd/fluxbox	updates menus for fluxbox
	_lsd/pcman	updates menus for pcman file manger desktop icons
	_lsd/jwm	updates menus for jwm window manger menus
_end:
