# idesk updater
# batch files should use the -n switch to stop the restart

APP_NAME=menjob
APP_EXEC=../../$APP_NAME
APP_ICON=$APP_NAME.xpm

# if called from elsewhere, make sure we start here
ME=`readlink -f $0`; MYDIR=`dirname $ME`; cd $MYDIR

# using idktool to update idesk icons

./idktool $APP_NAME $APP_EXEC $APP_ICON

# restart idesk if not called from batch
if [ "$1" != "-n" ]; then
 ./idktool -r
fi
