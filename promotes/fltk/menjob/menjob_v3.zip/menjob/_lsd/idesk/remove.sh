# removes icon from idesk. 
# batch files should use -n switch to stop the restart.

APP_NAME=menjob

# if called from elsewhere, make sure we start here
ME=`readlink -f $0`; MYDIR=`dirname $ME`; cd $MYDIR

# easy, just remove the .lnk from $HOME/.idesktop

rm -f $HOME/.idesktop/$APP_NAME.lnk

if [ -f $HOME/.idesktop/$APP_NAME.lnk ]; then
 echo no success.
else
 echo idesktop item removed.
fi

# restart idesk if not called from batch
if [ "$1" != "-n" ]; then
 ./idktool -r
fi
