# fluxbox updater
# batch files should use the -n switch to stop the restart

APP_NAME=menjob
APP_EXEC=../../$APP_NAME
APP_MENU=/lsd/media/

# if called from elsewhere, make sure we start here
ME=`readlink -f $0`; MYDIR=`dirname $ME`; cd $MYDIR

# use fluxtool to update fluxbox menu

./fluxtool $APP_NAME $APP_EXEC $APP_MENU

# restart fluxbox if not called from batch
if [ "$1" != "-n" ]; then
 ./fluxtool -r
fi
